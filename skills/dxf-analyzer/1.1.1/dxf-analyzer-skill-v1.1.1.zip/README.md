# DXF Analyzer

Analizza file DXF (Drawing Exchange Format / AutoCAD) ed estrae tutte le informazioni strutturate: entità geometriche, layer, blocchi, metadati e statistiche.

## Funzionalità

- Supporta tutte le versioni DXF (R10 → R2018)
- Estrae: LINE, ARC, CIRCLE, LWPOLYLINE, POLYLINE, TEXT, MTEXT, INSERT, DIMENSION, HATCH, SPLINE, ELLIPSE, POINT, SOLID, LEADER e altri
- Legge layer (nome, colore ACI, linetype, stato on/frozen/locked)
- Estrae definizioni blocchi con conteggio entità interne
- Calcola bounding box e statistiche per tipo/layer
- **Salva sempre** un report JSON completo su file — lo stdout restituisce solo il sommario leggero

## Input

| Campo | Tipo | Richiesto | Descrizione |
|-------|------|:---------:|-------------|
| `file_path` | string (`format: file-ref`) | ✅ | `id` (uuid) del file `.dxf` allegato in chat: il backend autorizza il file e lo copia nel container di esecuzione. In alternativa un path relativo alla cartella uploads. **Mai path assoluti.** |
| `detail_level` | string | ❌ | `minimal` · `standard` (default) · `full` |
| `include_text` | boolean | ❌ | Includi testi (TEXT, MTEXT, quote) — default: `true` |

### `detail_level`

| Valore | Entità nel report | Velocità |
|--------|-------------------|----------|
| `minimal` | Nessuna (solo statistiche) | ⚡ massima |
| `standard` | fino a 2.000 | normale |
| `full` | fino a 10.000 | lenta su file grandi |

## Output

Lo script restituisce allo stdout un **sommario leggero** e salva il report completo su file:

```json
{
  "success": true,
  "file_name": "disegno.dxf",
  "file_size_mb": 1.24,
  "message": "Analisi completata. Report completo (disegno_analysis_3f8a1b2c4d5e.json): link per l'utente /api/files/raw?rel=skills-output/dxf-analyzer/disegno_analysis_3f8a1b2c4d5e.json ; per elaborarlo in sandbox aprilo da $SKILLS_OUTPUT_DIR/dxf-analyzer/disegno_analysis_3f8a1b2c4d5e.json",
  "report_rel": "dxf-analyzer/disegno_analysis_3f8a1b2c4d5e.json",
  "download_url": "skills-output/dxf-analyzer/disegno_analysis_3f8a1b2c4d5e.json",
  "statistics": { "total_entities": 148, "entity_counts": { "LINE": 72 } },
  "bounding_box": { "width": 5000.0, "height": 3500.0 },
  "metadata": { "dxf_version_name": "R2018", "units": "Millimetri", "...": "..." },
  "layers": [{ "name": "PARETI", "color": "Bianco/Nero", "on": true }],
  "blocks": [{ "name": "PORTA_90", "entity_count": 5 }]
}
```

| Campo | Uso |
|-------|-----|
| `download_url` | Path relativo a `uploads/` — il backend costruisce `/api/files/raw?rel=…` per il link all'utente |
| `report_rel` | Path relativo a `SKILLS_OUTPUT_DIR` — per rileggere il report dalla sandbox (`$SKILLS_OUTPUT_DIR/<report_rel>`) |

Lo stdout non contiene mai path assoluti del container di esecuzione (non esistono negli altri
ambienti). I campi essenziali (`message`, `report_rel`, `download_url`, `statistics`) precedono le
liste lunghe (`layers`, `blocks`), perché l'output persistito in chat viene troncato in coda.

Il report JSON salvato su file contiene anche l'array completo `entities` con le coordinate di ogni oggetto.

## Dipendenze

- `ezdxf>=1.3.0` (installato automaticamente al primo avvio)

## Versione

`1.1.1` — `file_path` diventa un `file-ref`: si passa l'`id` dell'allegato, non un path assoluto (il
backend autorizza e copia il file nel container). Lo stdout non espone più path assoluti (`report_path`
sostituito da `report_rel`, relativo a `SKILLS_OUTPUT_DIR`) e mette i campi essenziali prima delle liste
lunghe, così il link al report sopravvive al troncamento in coda dell'output persistito in chat.

`1.1.0` — Salvataggio automatico report JSON; stdout ridotto al sommario essenziale; filename con UUID hex (no timestamp) per prevenire allucinazioni LLM.

## Network

Nessuna connessione esterna. La skill opera in locale e/o tramite il backend interno (`BACKEND_INTERNAL_URL`, sempre raggiungibile e non soggetto all'allowlist egress).
