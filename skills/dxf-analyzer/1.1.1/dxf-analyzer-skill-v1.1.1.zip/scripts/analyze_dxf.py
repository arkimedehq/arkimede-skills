#!/usr/bin/env python3
"""
DXF Analyzer — estrae tutte le informazioni strutturate da un file DXF.
Dipendenza: ezdxf>=1.3.0

Protocollo: legge JSON da stdin, scrive JSON su stdout.
Input:  { file_path, detail_level?, include_text?, save_report?, _config? }
Output: { success, metadata, layers, blocks, entities, statistics, [report_rel, download_url] }
"""
import sys
import json
import os
import math
import uuid

# ezdxf è installato in PYTHONPATH (.deps/python)
try:
    import ezdxf
    from ezdxf.math import Vec3
    from ezdxf import units
except ImportError as e:
    print(json.dumps({"success": False, "error": f"ezdxf non installato: {e}"}))
    sys.exit(1)


# ─── Helpers ────────────────────────────────────────────────────────────────

def pt(vec) -> dict:
    """Converte un vettore 2D/3D in dizionario."""
    if vec is None:
        return None
    try:
        return {"x": round(float(vec.x), 6), "y": round(float(vec.y), 6), "z": round(float(vec.z), 6)}
    except Exception:
        try:
            return {"x": round(float(vec[0]), 6), "y": round(float(vec[1]), 6)}
        except Exception:
            return str(vec)


def color_str(color_index: int) -> str:
    """Mappa ACI (AutoCAD Color Index) → nome colore comune."""
    ACI = {
        0: "ByBlock", 1: "Rosso", 2: "Giallo", 3: "Verde",
        4: "Ciano", 5: "Blu", 6: "Magenta", 7: "Bianco/Nero",
        8: "Grigio scuro", 9: "Grigio chiaro", 256: "ByLayer",
    }
    return ACI.get(color_index, f"ACI-{color_index}")


def safe_str(val) -> str:
    if val is None:
        return ""
    return str(val).strip()


def round6(v) -> float:
    try:
        return round(float(v), 6)
    except Exception:
        return v


# ─── Estrazione entità ───────────────────────────────────────────────────────

def extract_line(e, detail: str) -> dict:
    d = {
        "type": "LINE",
        "layer": safe_str(e.dxf.layer),
        "start": pt(e.dxf.start),
        "end":   pt(e.dxf.end),
    }
    if detail == "full":
        try:
            length = e.dxf.start.distance(e.dxf.end)
            d["length"] = round6(length)
        except Exception:
            pass
        d["color"] = color_str(e.dxf.get("color", 256))
        d["linetype"] = safe_str(e.dxf.get("linetype", "ByLayer"))
    return d


def extract_arc(e, detail: str) -> dict:
    d = {
        "type": "ARC",
        "layer": safe_str(e.dxf.layer),
        "center": pt(e.dxf.center),
        "radius": round6(e.dxf.radius),
        "start_angle": round6(e.dxf.start_angle),
        "end_angle":   round6(e.dxf.end_angle),
    }
    if detail in ("standard", "full"):
        angle_span = e.dxf.end_angle - e.dxf.start_angle
        if angle_span < 0:
            angle_span += 360
        d["arc_length"] = round6(math.radians(angle_span) * e.dxf.radius)
    if detail == "full":
        d["color"] = color_str(e.dxf.get("color", 256))
    return d


def extract_circle(e, detail: str) -> dict:
    d = {
        "type": "CIRCLE",
        "layer": safe_str(e.dxf.layer),
        "center": pt(e.dxf.center),
        "radius": round6(e.dxf.radius),
    }
    if detail in ("standard", "full"):
        d["circumference"] = round6(2 * math.pi * e.dxf.radius)
        d["area"] = round6(math.pi * e.dxf.radius ** 2)
    if detail == "full":
        d["color"] = color_str(e.dxf.get("color", 256))
    return d


def extract_lwpolyline(e, detail: str) -> dict:
    d = {
        "type": "LWPOLYLINE",
        "layer": safe_str(e.dxf.layer),
        "closed": e.is_closed,
        "vertex_count": len(e),
    }
    if detail in ("standard", "full"):
        verts = []
        for v in e.vertices():
            verts.append({"x": round6(v[0]), "y": round6(v[1])})
        d["vertices"] = verts
    if detail == "full":
        d["color"] = color_str(e.dxf.get("color", 256))
        d["elevation"] = round6(e.dxf.get("elevation", 0))
    return d


def extract_polyline(e, detail: str) -> dict:
    verts = list(e.vertices)
    d = {
        "type": "POLYLINE",
        "layer": safe_str(e.dxf.layer),
        "closed": bool(e.is_closed),
        "vertex_count": len(verts),
        "is_3d": e.is_3d_polyline,
    }
    if detail in ("standard", "full"):
        pts = []
        for v in verts:
            pts.append(pt(v.dxf.location))
        d["vertices"] = pts
    return d


def extract_text(e, detail: str, include_text: bool) -> dict:
    d = {
        "type": "TEXT",
        "layer": safe_str(e.dxf.layer),
        "height": round6(e.dxf.get("height", 0)),
        "insert": pt(e.dxf.insert),
    }
    if include_text:
        d["text"] = safe_str(e.dxf.text)
    if detail in ("standard", "full"):
        d["rotation"] = round6(e.dxf.get("rotation", 0))
        d["style"] = safe_str(e.dxf.get("style", "Standard"))
    if detail == "full":
        d["color"] = color_str(e.dxf.get("color", 256))
        d["halign"] = e.dxf.get("halign", 0)
        d["valign"] = e.dxf.get("valign", 0)
    return d


def extract_mtext(e, detail: str, include_text: bool) -> dict:
    d = {
        "type": "MTEXT",
        "layer": safe_str(e.dxf.layer),
        "char_height": round6(e.dxf.get("char_height", 0)),
        "insert": pt(e.dxf.insert),
    }
    if include_text:
        try:
            d["text"] = safe_str(e.plain_mtext())
        except Exception:
            d["text"] = safe_str(e.dxf.get("text", ""))
    if detail in ("standard", "full"):
        d["rotation"] = round6(e.dxf.get("rotation", 0))
        d["width"] = round6(e.dxf.get("width", 0))
        d["style"] = safe_str(e.dxf.get("style", "Standard"))
    return d


def extract_insert(e, detail: str) -> dict:
    d = {
        "type": "INSERT",
        "layer": safe_str(e.dxf.layer),
        "name": safe_str(e.dxf.name),
        "insert": pt(e.dxf.insert),
        "rotation": round6(e.dxf.get("rotation", 0)),
    }
    if detail in ("standard", "full"):
        d["x_scale"] = round6(e.dxf.get("xscale", 1))
        d["y_scale"] = round6(e.dxf.get("yscale", 1))
        d["z_scale"] = round6(e.dxf.get("zscale", 1))
    return d


def extract_dimension(e, detail: str, include_text: bool) -> dict:
    d = {
        "type": "DIMENSION",
        "layer": safe_str(e.dxf.layer),
        "dim_type": e.dimtype,
    }
    if include_text:
        try:
            d["measurement"] = round6(e.get_measurement())
        except Exception:
            pass
        try:
            d["text"] = safe_str(e.dxf.get("text", ""))
        except Exception:
            pass
    if detail in ("standard", "full"):
        try:
            d["defpoint"] = pt(e.dxf.defpoint)
        except Exception:
            pass
        d["dimstyle"] = safe_str(e.dxf.get("dimstyle", "Standard"))
    return d


def extract_hatch(e, detail: str) -> dict:
    d = {
        "type": "HATCH",
        "layer": safe_str(e.dxf.layer),
        "pattern_name": safe_str(e.dxf.get("pattern_name", "")),
        "solid_fill": e.dxf.get("solid_fill", 0) == 1,
        "path_count": len(e.paths),
    }
    if detail in ("standard", "full"):
        d["pattern_type"] = e.dxf.get("pattern_type", 0)
        d["pattern_scale"] = round6(e.dxf.get("pattern_scale", 1))
        d["pattern_angle"] = round6(e.dxf.get("pattern_angle", 0))
        try:
            d["area"] = round6(e.dxf.get("area", 0))
        except Exception:
            pass
    return d


def extract_spline(e, detail: str) -> dict:
    d = {
        "type": "SPLINE",
        "layer": safe_str(e.dxf.layer),
        "degree": e.dxf.degree,
        "control_point_count": e.dxf.n_control_points,
        "fit_point_count": e.dxf.n_fit_points,
        "closed": e.closed,
    }
    if detail == "full":
        d["control_points"] = [pt(p) for p in e.control_points]
    return d


def extract_ellipse(e, detail: str) -> dict:
    d = {
        "type": "ELLIPSE",
        "layer": safe_str(e.dxf.layer),
        "center": pt(e.dxf.center),
        "major_axis": pt(e.dxf.major_axis),
        "ratio": round6(e.dxf.ratio),
        "start_param": round6(e.dxf.start_param),
        "end_param":   round6(e.dxf.end_param),
    }
    if detail in ("standard", "full"):
        try:
            major_len = e.dxf.major_axis.magnitude
            minor_len = major_len * e.dxf.ratio
            d["major_radius"] = round6(major_len)
            d["minor_radius"] = round6(minor_len)
        except Exception:
            pass
    return d


def extract_point(e) -> dict:
    return {
        "type": "POINT",
        "layer": safe_str(e.dxf.layer),
        "location": pt(e.dxf.location),
    }


def extract_solid(e, detail: str) -> dict:
    d = {
        "type": "SOLID",
        "layer": safe_str(e.dxf.layer),
    }
    if detail in ("standard", "full"):
        for i in range(4):
            try:
                d[f"vtx{i}"] = pt(e.dxf.get(f"vtx{i}"))
            except Exception:
                pass
    return d


def extract_leader(e, detail: str, include_text: bool) -> dict:
    d = {
        "type": "LEADER",
        "layer": safe_str(e.dxf.layer),
        "vertex_count": len(e.vertices),
    }
    if detail in ("standard", "full") and e.vertices:
        d["start"] = pt(e.vertices[0])
        d["end"]   = pt(e.vertices[-1])
    return d


def extract_entities(msp_or_block, detail: str, include_text: bool, limit: int = 5000) -> list:
    """Itera sulle entità di un modelspace o blocco e le deserializza."""
    result = []
    count = 0
    for e in msp_or_block:
        if count >= limit:
            result.append({"type": "_TRUNCATED", "message": f"Troncato a {limit} entità"})
            break
        try:
            t = e.dxftype()
            if t == "LINE":
                result.append(extract_line(e, detail))
            elif t == "ARC":
                result.append(extract_arc(e, detail))
            elif t == "CIRCLE":
                result.append(extract_circle(e, detail))
            elif t == "LWPOLYLINE":
                result.append(extract_lwpolyline(e, detail))
            elif t == "POLYLINE":
                result.append(extract_polyline(e, detail))
            elif t == "TEXT":
                result.append(extract_text(e, detail, include_text))
            elif t == "MTEXT":
                result.append(extract_mtext(e, detail, include_text))
            elif t == "INSERT":
                result.append(extract_insert(e, detail))
            elif t == "DIMENSION":
                result.append(extract_dimension(e, detail, include_text))
            elif t == "HATCH":
                result.append(extract_hatch(e, detail))
            elif t == "SPLINE":
                result.append(extract_spline(e, detail))
            elif t == "ELLIPSE":
                result.append(extract_ellipse(e, detail))
            elif t == "POINT":
                result.append(extract_point(e))
            elif t == "SOLID":
                result.append(extract_solid(e, detail))
            elif t == "LEADER":
                result.append(extract_leader(e, detail, include_text))
            else:
                result.append({"type": t, "layer": safe_str(e.dxf.get("layer", "0"))})
        except Exception as ex:
            result.append({"type": "ERROR", "entity_type": e.dxftype() if hasattr(e, 'dxftype') else "?", "error": str(ex)})
        count += 1
    return result


# ─── Estrazione layer ────────────────────────────────────────────────────────

def extract_layers(doc) -> list:
    layers = []
    for layer in doc.layers:
        l = {
            "name": safe_str(layer.dxf.name),
            "color": color_str(layer.dxf.get("color", 7)),
            "color_index": layer.dxf.get("color", 7),
            "linetype": safe_str(layer.dxf.get("linetype", "Continuous")),
            "on": layer.is_on(),
            "frozen": layer.is_frozen(),
            "locked": layer.is_locked(),
        }
        try:
            l["lineweight"] = layer.dxf.get("lineweight", -3)
        except Exception:
            pass
        layers.append(l)
    return layers


# ─── Estrazione blocchi ──────────────────────────────────────────────────────

def extract_blocks(doc, detail: str, include_text: bool) -> list:
    blocks = []
    for block in doc.blocks:
        name = safe_str(block.name)
        if name.startswith("*Model_Space") or name.startswith("*Paper_Space"):
            continue
        b = {
            "name": name,
            "base_point": pt(block.block.dxf.base_point) if block.block else None,
            "entity_count": 0,
        }
        if detail in ("standard", "full"):
            entities = extract_entities(block, detail, include_text, limit=500)
            b["entity_count"] = len(entities)
            b["entities"] = entities
        else:
            b["entity_count"] = sum(1 for _ in block)
        blocks.append(b)
    return blocks


# ─── Estrazione metadati header ──────────────────────────────────────────────

def extract_metadata(doc) -> dict:
    hdr = doc.header
    meta = {
        "dxf_version": safe_str(doc.dxfversion),
        "dxf_version_name": {
            "AC1006": "R10", "AC1009": "R11/R12", "AC1012": "R13",
            "AC1014": "R14", "AC1015": "R2000", "AC1018": "R2004",
            "AC1021": "R2007", "AC1024": "R2010", "AC1027": "R2013",
            "AC1032": "R2018",
        }.get(doc.dxfversion, doc.dxfversion),
    }

    def hdr_get(var, default=None):
        try:
            return hdr.get(var, default)
        except Exception:
            return default

    insunits = hdr_get("$INSUNITS", 0)
    unit_names = {
        0: "Senza unità", 1: "Pollici", 2: "Piedi", 3: "Miglia",
        4: "Millimetri", 5: "Centimetri", 6: "Metri", 7: "Chilometri",
        8: "Microinch", 9: "Mils", 10: "Yard", 11: "Angstrom",
        12: "Nanometri", 13: "Micron", 14: "Decimetri", 15: "Decametri",
        16: "Ettometri", 17: "Gigametri", 18: "UA", 19: "Anni luce", 20: "Parsec",
    }
    meta["units"] = unit_names.get(insunits, f"Codice {insunits}")
    meta["units_code"] = insunits

    angbase = hdr_get("$ANGBASE", 0)
    angdir  = hdr_get("$ANGDIR", 0)
    meta["angle_base"]      = round6(angbase) if angbase is not None else 0
    meta["angle_direction"] = "Orario" if angdir == 1 else "Antiorario"

    try:
        meta["extmin"] = pt(hdr_get("$EXTMIN"))
        meta["extmax"] = pt(hdr_get("$EXTMAX"))
        meta["limmin"] = pt(hdr_get("$LIMMIN"))
        meta["limmax"] = pt(hdr_get("$LIMMAX"))
    except Exception:
        pass

    try:
        ltscale = hdr_get("$LTSCALE", 1.0)
        meta["linetype_scale"] = round6(ltscale)
    except Exception:
        pass

    try:
        meta["author"]  = safe_str(doc.metadata.get("Author", ""))
        meta["title"]   = safe_str(doc.metadata.get("Title", ""))
        meta["subject"] = safe_str(doc.metadata.get("Subject", ""))
    except Exception:
        pass

    return meta


# ─── Statistiche ─────────────────────────────────────────────────────────────

def compute_statistics(entities: list, layers: list, blocks: list) -> dict:
    counts = {}
    for e in entities:
        t = e.get("type", "UNKNOWN")
        counts[t] = counts.get(t, 0) + 1

    stats = {
        "total_entities": sum(v for k, v in counts.items() if not k.startswith("_")),
        "entity_counts": counts,
        "layer_count": len(layers),
        "block_definition_count": len(blocks),
    }

    layer_usage = {}
    for e in entities:
        l = e.get("layer", "0")
        layer_usage[l] = layer_usage.get(l, 0) + 1
    stats["entities_per_layer"] = dict(sorted(layer_usage.items(), key=lambda x: -x[1])[:20])

    return stats


# ─── Bounding box ─────────────────────────────────────────────────────────────

def compute_bounding_box(entities: list) -> dict:
    xs, ys = [], []

    def add(p):
        if p and isinstance(p, dict):
            if "x" in p: xs.append(p["x"])
            if "y" in p: ys.append(p["y"])

    for e in entities:
        t = e.get("type", "")
        if t == "LINE":
            add(e.get("start")); add(e.get("end"))
        elif t in ("ARC", "CIRCLE"):
            c = e.get("center", {})
            r = e.get("radius", 0)
            if c:
                xs += [c["x"] - r, c["x"] + r]
                ys += [c["y"] - r, c["y"] + r]
        elif t in ("TEXT", "MTEXT", "POINT", "INSERT"):
            add(e.get("insert") or e.get("location"))
        elif t in ("LWPOLYLINE", "POLYLINE"):
            for v in e.get("vertices", []):
                add(v)

    if not xs or not ys:
        return {}

    return {
        "min_x": round6(min(xs)), "min_y": round6(min(ys)),
        "max_x": round6(max(xs)), "max_y": round6(max(ys)),
        "width":  round6(max(xs) - min(xs)),
        "height": round6(max(ys) - min(ys)),
    }


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    data = json.load(sys.stdin)
    _config = data.get("_config", {})

    file_path    = data.get("file_path", "")
    detail_level = data.get("detail_level", "full")
    include_text = data.get("include_text", True)

    if not file_path:
        print(json.dumps({"success": False, "error": "file_path è obbligatorio"}))
        sys.exit(1)

    if not os.path.isfile(file_path):
        print(json.dumps({"success": False, "error": f"File non trovato: {file_path}"}))
        sys.exit(1)

    ext = os.path.splitext(file_path)[1].lower()
    if ext not in (".dxf",):
        print(json.dumps({"success": False, "error": f"Estensione non supportata: {ext}. Usa un file .dxf"}))
        sys.exit(1)

    if detail_level not in ("minimal", "standard", "full"):
        detail_level = "standard"

    file_size_mb = os.path.getsize(file_path) / (1024 * 1024)

    # ─── Caricamento DXF ───────────────────────────────────────────────────
    try:
        doc = ezdxf.readfile(file_path)
    except ezdxf.DXFStructureError as e:
        print(json.dumps({"success": False, "error": f"Struttura DXF non valida: {e}"}))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"success": False, "error": f"Errore lettura DXF: {e}"}))
        sys.exit(1)

    msp = doc.modelspace()

    entity_limit = {"minimal": 0, "standard": 2000, "full": 10000}[detail_level]

    # ─── Estrazione dati ───────────────────────────────────────────────────
    metadata   = extract_metadata(doc)
    layers     = extract_layers(doc)
    blocks     = extract_blocks(doc, detail_level, include_text)
    entities   = extract_entities(msp, detail_level, include_text, limit=entity_limit) if detail_level != "minimal" else []
    statistics = compute_statistics(entities, layers, blocks)
    bbox       = compute_bounding_box(entities) if entities else {}

    # Dati completi → vanno sempre su file
    full_result = {
        "success":      True,
        "file_name":    os.path.basename(file_path),
        "file_size_mb": round(file_size_mb, 3),
        "detail_level": detail_level,
        "metadata":     metadata,
        "layers":       layers,
        "blocks":       blocks,
        "entities":     entities,
        "statistics":   statistics,
        "bounding_box": bbox,
    }

    # ─── Salvataggio automatico su file ────────────────────────────────────
    skills_output_dir = os.environ.get("SKILLS_OUTPUT_DIR", "./skills-output")
    output_dir        = os.path.join(skills_output_dir, "dxf-analyzer")
    os.makedirs(output_dir, exist_ok=True)

    basename    = os.path.splitext(os.path.basename(file_path))[0]
    report_name = f"{basename}_analysis_{uuid.uuid4().hex[:12]}.json"
    report_path = os.path.join(output_dir, report_name)

    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(full_result, f, ensure_ascii=False, indent=2)

    # Percorso RELATIVO del report rispetto a SKILLS_OUTPUT_DIR. MAI stampare
    # path assoluti del container di esecuzione (/work/…): non esistono negli
    # altri ambienti (sandbox, backend) e mandano fuori strada l'agente.
    #   - link download utente:  /api/files/raw?rel=<download_url>
    #   - accesso dalla sandbox: $SKILLS_OUTPUT_DIR/<report_rel>
    report_rel   = os.path.relpath(report_path, skills_output_dir)
    download_url = f"skills-output/{report_rel}"

    # ─── Sommario leggero → stdout per l'LLM ───────────────────────────────
    # Solo i dati essenziali: l'LLM usa il report completo per approfondire.
    # Non include entities (potenzialmente migliaia di oggetti).
    blocks_summary = [{"name": b["name"], "entity_count": b["entity_count"]} for b in blocks]

    # I campi essenziali (message, report_rel, download_url, statistiche) vanno
    # PRIMA delle liste lunghe (layers, blocks): l'output persistito/replayato in
    # chat viene troncato in coda (~8KB) e il link al report deve sopravvivere.
    summary = {
        "success":      True,
        "file_name":    full_result["file_name"],
        "file_size_mb": full_result["file_size_mb"],
        "detail_level": detail_level,
        "message":      (
            f"Analisi completata. Report completo ({report_name}): "
            f"link per l'utente /api/files/raw?rel={download_url} ; "
            f"per elaborarlo in sandbox aprilo da $SKILLS_OUTPUT_DIR/{report_rel} "
            f"(NON usare path assoluti di questo container)."
        ),
        "report_rel":   report_rel,
        "download_url": download_url,
        "statistics":   statistics,
        "bounding_box": bbox,
        "metadata":     metadata,
        "layers":       layers,
        "blocks":       blocks_summary,
    }

    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success":   False,
            "error":     str(e),
            "traceback": traceback.format_exc(),
        }))
        sys.exit(1)
