# DXF Analyzer

Analizza file DXF (Drawing Exchange Format / AutoCAD) ed estrae tutte le informazioni strutturate: entità geometriche, layer, blocchi, metadati e statistiche.

## Funzionalità

- Supporta tutte le versioni DXF (R10 → R2018)
- Estrae: LINE, ARC, CIRCLE, LWPOLYLINE, POLYLINE, TEXT, MTEXT, INSERT, DIMENSION, HATCH, SPLINE, ELLIPSE, POINT, SOLID, LEADER e altri
- Legge layer (nome, colore ACI, linetype, stato on/frozen/locked)
- Estrae definizioni blocchi con conteggio entità interne
- Calcola bounding box e statistiche per tipo/layer
- **Salva sempre** un report JSON completo su file — lo stdout restituisce solo il sommario leggero

## Input

| Campo | Tipo | Richiesto | Descrizione |
|-------|------|:---------:|-------------|
| `file_path` | string | ✅ | Percorso assoluto al file `.dxf` (dal contesto allegato) |
| `detail_level` | string | ❌ | `minimal` · `standard` (default) · `full` |
| `include_text` | boolean | ❌ | Includi testi (TEXT, MTEXT, quote) — default: `true` |

### `detail_level`

| Valore | Entità nel report | Velocità |
|--------|-------------------|----------|
| `minimal` | Nessuna (solo statistiche) | ⚡ massima |
| `standard` | fino a 2.000 | normale |
| `full` | fino a 10.000 | lenta su file grandi |

## Output

Lo script restituisce allo stdout un **sommario leggero** e salva il report completo su file:

```json
{
  "success": true,
  "file_name": "disegno.dxf",
  "file_size_mb": 1.24,
  "metadata": { "dxf_version_name": "R2018", "units": "Millimetri", "...": "..." },
  "layers": [{ "name": "PARETI", "color": "Bianco/Nero", "on": true }],
  "blocks": [{ "name": "PORTA_90", "entity_count": 5 }],
  "statistics": { "total_entities": 148, "entity_counts": { "LINE": 72 } },
  "bounding_box": { "width": 5000.0, "height": 3500.0 },
  "download_url": "skills-output/dxf-analyzer/disegno_analysis_3f8a1b2c4d5e.json",
  "message": "Analisi completata. Report completo disponibile al download."
}
```

| Campo | Uso |
|-------|-----|
| `download_url` | Path relativo a `uploads/` — il backend costruisce `/api/files/raw?rel=…` |
| `report_path` | Percorso assoluto — inter-skill |

Il report JSON salvato su file contiene anche l'array completo `entities` con coordinate di ogni oggetto.

## Dipendenze

- `ezdxf>=1.3.0` (installato automaticamente al primo avvio)

## Versione

`1.1.0` — Salvataggio automatico report JSON; stdout ridotto al sommario essenziale; filename con UUID hex (no timestamp) per prevenire allucinazioni LLM; `file_path` allegato passato direttamente nel contesto messaggio.

## Network

Nessuna connessione esterna. La skill opera in locale e/o tramite il backend interno (`BACKEND_INTERNAL_URL`, sempre raggiungibile e non soggetto all'allowlist egress).
