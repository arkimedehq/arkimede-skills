---
name: dxf-analyzer
description: |
  Analizza file DXF (Drawing Exchange Format) di AutoCAD/CAD e ne estrae tutte le informazioni strutturate: entità geometriche (linee, archi, cerchi, polilinee, testi, blocchi, quotature, campiture), layer, blocchi, metadati del disegno e statistiche. Restituisce JSON con il dettaglio completo del file. Usala quando l'utente vuole capire il contenuto di un file DXF, estrarre misure, testi, layer o convertire il disegno in dati strutturati.
version: 1.1.0
author: info@rstonline.it
license: MIT
runtime:
  dependencies:
    python:
      - ezdxf>=1.3.0
  network: []
  config: []
  scripts:
    - filename: scripts/analyze_dxf.py
      language: python
      description: |
        Analizza un file DXF e ne estrae tutte le entità geometriche, layer, blocchi e metadati. Salva SEMPRE un report JSON completo su file e restituisce allo stdout solo il sommario essenziale (metadata, layers, blocks, statistics, bounding_box) con download_url per accedere al report completo. Il dettaglio del report varia in base a detail_level: "minimal" solo statistiche, "standard" entità principali + layer (default), "full" tutto incluse coordinate grezze di ogni entità.
      input_schema:
        type: object
        required:
          - file_path
        properties:
          file_path:
            type: string
            description: Percorso assoluto al file DXF da analizzare
          detail_level:
            type: string
            description: |
              Livello di dettaglio del report salvato: 'minimal' | 'standard' | 'full'. Se l'utente non specifica esplicitamente un livello, scegli tu in base al contesto: usa 'full' per analisi approfondite o quando l'utente vuole tutti i dati; usa 'standard' per una panoramica generale; usa 'minimal' per file molto grandi o quando servono solo statistiche. Il fallback del codice è 'full'.
            enum:
              - minimal
              - standard
              - full
          include_text:
            type: boolean
            description: 'Includere contenuto testuale (TEXT, MTEXT, quotature) — default: true'
---

# DXF Analyzer

> ⚠️ **Nome tool canonico:** `skill_dxf_analyzer_analyze_dxf_py`
>
> **NON chiamare mai** un tool con nomi come `dxf_analyzer`, `analyze_dxf` o `dxf` — usa sempre il nome esatto sopra.

## Quando usarla

Usa questa skill quando l'utente vuole:
- **Analizzare** il contenuto di un file `.dxf` (Drawing Exchange Format / AutoCAD)
- **Estrarre** entità geometriche: linee, archi, cerchi, polilinee, testi, blocchi, quotature, campiture
- **Leggere** i layer, blocchi, metadati e unità di misura di un disegno CAD
- **Ottenere statistiche** su un disegno (quante entità per tipo, per layer, bounding box)
- **Convertire** il contenuto DXF in dati strutturati (JSON) per elaborazioni successive
- **Cercare testi** o annotazioni nel disegno
- Verificare dimensioni, misure o scale prima di lavorare con il file

**Non** usarla per:
- Modificare o creare file DXF
- Convertire DXF in altri formati (PDF, SVG, PNG) — usa altre skill dedicate
- Aprire file diversi da `.dxf`

---

## Rete (network)

Nessuna connessione esterna: la skill opera in locale e/o via backend interno.

<!-- @tool: analyze_dxf.py -->
## `analyze_dxf.py` — Analisi file DXF

**Tool name (usa questo nome esatto):** `skill_dxf_analyzer_analyze_dxf_py`

### ⚠️ Come ottenere il `file_path`

Quando l'utente allega un file `.dxf` al messaggio, il sistema lo comunica nel contesto con questa sintassi:

```
[Allegati: drawing.dxf (id: uuid, file_path: /percorso/assoluto/drawing.dxf)]
```

**Usa SEMPRE il valore `file_path` da quella riga come parametro `file_path` della skill.**
Non inventare il percorso, non usare l'`id`, non chiamare altri tool per risolvere il path.

### Parametri

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `file_path` | string | ✅ | Valore `file_path` preso dall'allegato nel contesto (percorso assoluto) |
| `detail_level` | string | ❌ | `"minimal"` · `"standard"` · `"full"` — controlla il dettaglio del report salvato. **Se l'utente non specifica, scegli tu** (vedi sotto). Fallback codice: `"full"` |
| `include_text` | boolean | ❌ | Includere contenuti testuali — TEXT, MTEXT, quotature (default: `true`) |

### Scegliere il `detail_level`

**Se l'utente non indica esplicitamente un livello, scegli tu in base al contesto:**

| Quando usarlo | Livello |
|---|---|
| L'utente allega il file senza ulteriori indicazioni, oppure vuole un'analisi completa | `full` |
| L'utente vuole una panoramica rapida o il file è molto grande (>10 MB) | `standard` |
| L'utente vuole solo statistiche / conteggi senza coordinate | `minimal` |
| L'utente chiede un'analisi "leggera", "veloce" o "rapida" | `minimal` |
| L'utente specifica esplicitamente un livello | usa quello indicato |

- **`minimal`** — solo statistiche (layer, conteggi): velocissimo, per file molto grandi
- **`standard`** — entità + layer + blocchi con coordinate: per panoramiche generali
- **`full`** — tutto incluse coordinate grezze, campiture, attributi completi: default per analisi approfondite

---

## Output e risposta all'utente

Lo script **salva sempre** un report JSON completo su file e restituisce allo stdout solo il sommario essenziale (senza l'array `entities`, che può essere molto grande). Per dati più dettagliati usa il `download_url`.

### Sommario stdout

```json
{
  "success": true,
  "file_name": "disegno.dxf",
  "file_size_mb": 1.24,
  "detail_level": "full",

  "metadata": {
    "dxf_version": "AC1032",
    "dxf_version_name": "R2018",
    "units": "Millimetri",
    "units_code": 4,
    "angle_base": 0,
    "angle_direction": "Antiorario",
    "extmin": {"x": 0.0, "y": 0.0, "z": 0.0},
    "extmax": {"x": 1000.0, "y": 800.0, "z": 0.0},
    "author": "Mario Rossi",
    "title": "Pianta piano terra"
  },

  "layers": [
    {
      "name": "PARETI",
      "color": "Bianco/Nero",
      "color_index": 7,
      "linetype": "Continuous",
      "on": true,
      "frozen": false,
      "locked": false
    }
  ],

  "blocks": [
    {"name": "PORTA_90", "entity_count": 5},
    {"name": "FINESTRA_100", "entity_count": 3}
  ],

  "statistics": {
    "total_entities": 148,
    "entity_counts": {"LINE": 72, "ARC": 12, "CIRCLE": 8, "TEXT": 30, "INSERT": 20, "DIMENSION": 6},
    "layer_count": 8,
    "block_definition_count": 5,
    "entities_per_layer": {"PARETI": 72, "TESTI": 30, "ARREDI": 20}
  },

  "bounding_box": {
    "min_x": 0.0, "min_y": 0.0,
    "max_x": 5000.0, "max_y": 3500.0,
    "width": 5000.0, "height": 3500.0
  },

  "download_url": "skills-output/dxf-analyzer/disegno_analysis_3f8a1b2c4d5e.json",
  "report_path":  "/percorso/assoluto/uploads/skills-output/dxf-analyzer/disegno_analysis_3f8a1b2c4d5e.json",
  "message": "Analisi completata. Report completo (disegno_analysis_3f8a1b2c4d5e.json) disponibile al download."
}
```

---

## Come presentare i risultati all'utente

### Risposta tipo per analisi standard

```
**Analisi file DXF: {file_name}** ({file_size_mb} MB · DXF {dxf_version_name})

**Unità di misura:** {units}
**Dimensioni disegno:** {bounding_box.width} × {bounding_box.height} {units}

**Statistiche entità** ({total_entities} totali):
| Tipo | Conteggio |
|------|-----------|
| LINE | 72 |
| TEXT | 30 |
| ... |

**Layer** ({layer_count}):
- PARETI — Bianco/Nero · Continuous · attivo
- TESTI — Rosso · Continuous · attivo
- ...

**Blocchi definiti:** PORTA_90, FINESTRA_100, ...
```

### ⚠️ Regola critica sul download_url

Usa SEMPRE il campo `download_url` esattamente come restituito dalla skill — non modificarlo, non ricostruirlo:

✅ Corretto: `[Scarica report JSON](/api/files/raw?rel=skills-output%2Fdxf-analyzer%2Fdisegno_analysis_3f8a1b2c4d5e.json)`
❌ Sbagliato: inventare o modificare il nome del file

```
Il report completo è disponibile: [Scarica report JSON]({download_url})
```

---

## Note tecniche

- **Limite entità:** standard=2000, full=10000. File molto grandi → usa `minimal` poi `full` su sezioni specifiche.
- **Entità supportate:** LINE, ARC, CIRCLE, LWPOLYLINE, POLYLINE, TEXT, MTEXT, INSERT, DIMENSION, HATCH, SPLINE, ELLIPSE, POINT, SOLID, LEADER, e tutte le altre (tipo generico).
- **Blocchi:** le definizioni dei blocchi NON includono le istanze INSERT nel modelspace — quelle sono nelle `entities`.
- **Quotature:** `measurement` è il valore numerico misurato; `text` è il testo mostrato nel disegno (può essere override).
- **Timeout:** file DXF molto grandi possono richiedere 30-60 secondi. Se scade, usa `detail_level: "minimal"`.