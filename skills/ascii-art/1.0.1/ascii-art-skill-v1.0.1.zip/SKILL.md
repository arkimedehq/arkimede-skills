---
name: ascii-art
description: 'Genera arte ASCII in vari stili: banner testuali con centinaia di font (pyfiglet locale o API remota), fumetti con personaggi animaleschi (cowsay), cornici decorative (boxes), arte preconfezionata per soggetti comuni (ascii.co.uk), QR code e meteo in ASCII, conversione di immagini in ASCII art.'
version: 1.0.1
author: info@rstonline.it
license: MIT
runtime:
  dependencies:
    python:
    - pyfiglet>=1.0
    - requests>=2.31
    system:
      nix:
      - cowsay
      - boxes
      - jp2a
      - imagemagick
  network:
  - ascii.co.uk
  - asciified.thelicato.io
  - qrenco.de
  - wttr.in
  config: []
  scripts:
  - filename: scripts/banner.py
    language: python
    description: |
      Genera un banner testuale ASCII da un testo. Usa pyfiglet locale (571 font disponibili) o l'API asciified.thelicato.io come alternativa remota con font diversi. Se list_fonts=true restituisce l'elenco completo dei font invece del banner. Chiamalo quando l'utente chiede un banner, titolo o testo in stile ASCII art, oppure quando vuole sapere quali font sono disponibili.
    input_schema:
      type: object
      required:
      - text
      properties:
        text:
          type: string
          description: Testo da convertire in banner ASCII
        font:
          type: string
          description: 'Font da usare. Es: slant, doom, big, banner3, cyberlarge, 3-d, gothic, block, mini, digital'
          default: slant
        width:
          type: integer
          description: 'Larghezza massima in caratteri (default: 120)'
          default: 120
        list_fonts:
          type: boolean
          description: Se true restituisce la lista di tutti i font disponibili invece del banner
          default: false
        use_api:
          type: boolean
          description: Se true usa l'API remota asciified.thelicato.io invece di pyfiglet locale
          default: false
  - filename: scripts/cowsay.py
    language: python
    description: |
      Genera un fumetto ASCII con un animale o personaggio che dice o pensa un testo. Modalità cowsay (dire) o cowthink (pensare con fumetto tratteggiato). Ha oltre 50 personaggi: default (mucca), tux (pinguino), dragon, stegosaurus, moose, elephant, kitty, beavis.zen e molti altri. Se list_characters=true restituisce la lista completa dei personaggi. Chiamalo quando l'utente vuole un fumetto ASCII divertente.
    input_schema:
      type: object
      required:
      - text
      properties:
        text:
          type: string
          description: Testo da far dire o pensare al personaggio
        character:
          type: string
          description: 'Personaggio. Es: default, tux, dragon, stegosaurus, moose, elephant, kitty, beavis.zen'
          default: default
        think:
          type: boolean
          description: Se true usa cowthink (pensiero) invece di cowsay (parlato)
          default: false
        list_characters:
          type: boolean
          description: Se true restituisce la lista di tutti i personaggi disponibili
          default: false
  - filename: scripts/boxes.py
    language: python
    description: |
      Racchiude un testo in una cornice decorativa ASCII con 70+ stili disponibili. Con use_banner=true genera prima un banner pyfiglet e poi lo racchiude nella cornice. Design disponibili: stone, parchment, cat, dog, diamonds, unicornsay, c-cmt, html-cmt. Se list_designs=true restituisce la lista completa degli stili. Chiamalo quando l'utente vuole un testo in un riquadro decorativo ASCII.
    input_schema:
      type: object
      required:
      - text
      properties:
        text:
          type: string
          description: Testo da racchiudere nella cornice (testo semplice o multi-riga)
        design:
          type: string
          description: 'Stile della cornice. Es: stone, parchment, cat, dog, diamonds, unicornsay, c-cmt'
          default: stone
        use_banner:
          type: boolean
          description: Se true genera prima un banner pyfiglet con il testo, poi lo racchiude nella cornice
          default: false
        banner_font:
          type: string
          description: Font pyfiglet per il banner interno (usato solo se use_banner=true)
          default: slant
        list_designs:
          type: boolean
          description: Se true restituisce la lista di tutti gli stili di cornice disponibili
          default: false
  - filename: scripts/art_search.py
    language: python
    description: |
      Cerca arte ASCII preconfezionata su ascii.co.uk per un soggetto specifico. Restituisce 1-5 disegni ASCII pronti all'uso. Ha migliaia di soggetti disponibili. I soggetti vanno scritti in inglese (es. cat, dog, dragon, rocket, christmas). Chiamalo quando l'utente chiede arte ASCII di un animale, oggetto o tema, oppure vuole un disegno ASCII decorativo per un soggetto specifico.
    input_schema:
      type: object
      required:
      - subject
      properties:
        subject:
          type: string
          description: 'Soggetto da cercare in inglese. Es: cat, dog, dragon, car, rocket, christmas, halloween, skull'
        max_results:
          type: integer
          description: 'Numero massimo di risultati (1-5, default: 2)'
          default: 2
  - filename: scripts/utils.py
    language: python
    description: |
      Genera QR code in ASCII oppure mostra il meteo di una città in ASCII art. Modalità 'qr': converte qualsiasi testo o URL in un QR code testuale. Modalità 'weather': mostra le condizioni meteo di una città in ASCII art via wttr.in.
        weather_format 1=compatto con grafica, 2=esteso multi-giorno, 3=solo emoji/simboli.
      Chiamalo quando l'utente chiede un QR code o il meteo in formato ASCII/testuale.
    input_schema:
      type: object
      required:
      - mode
      properties:
        mode:
          type: string
          enum:
          - qr
          - weather
          description: '''qr'' per QR code ASCII, ''weather'' per meteo ASCII'
        text:
          type: string
          description: Testo o URL da codificare (obbligatorio per mode=qr)
        location:
          type: string
          description: 'Città o luogo per il meteo (obbligatorio per mode=weather). Es: Roma, London, Tokyo, Moon'
        weather_format:
          type: integer
          description: 'Formato meteo: 1=compatto (default), 2=esteso 3 giorni, 3=minimo solo simboli'
          default: 1
  - filename: scripts/image_ascii.py
    language: python
    description: |
      Converte un'immagine da URL in arte ASCII testuale tramite jp2a. Supporta JPEG direttamente; PNG e WebP vengono convertiti automaticamente con ImageMagick prima della conversione. Parametro width controlla la larghezza del risultato in caratteri. Con invert=true inverte i caratteri (utile per immagini su sfondo scuro). Chiamalo quando l'utente vuole convertire una foto o immagine in ASCII art.
    input_schema:
      type: object
      required:
      - url
      properties:
        url:
          type: string
          description: URL pubblico dell'immagine da convertire (JPEG, PNG, WebP, GIF, BMP, AVIF)
        width:
          type: integer
          description: 'Larghezza del risultato in caratteri (default: 100, range: 20-300)'
          default: 100
        invert:
          type: boolean
          description: Se true inverte la mappa dei caratteri (utile per immagini su sfondo scuro)
          default: false
        colors:
          type: boolean
          description: Se true abilita output ANSI colorato (richiede terminale compatibile)
          default: false
---

# ASCII Art Skill

Genera arte ASCII in tutte le sue forme: banner testuali, fumetti con animali, cornici decorative, ricerca di disegni preconfezionati, conversione di immagini, QR code e meteo ASCII.

---

## Quando usare questa skill

| Richiesta utente | Script da usare |
|---|---|
| "scrivi X a caratteri grandi", "banner con la parola X", "ASCII font" | `banner.py` |
| "mucca che dice X", "cowsay", "fumetto ASCII", "dragon / tux / moose che dice" | `cowsay.py` |
| "metti X in una cornice", "box ASCII", "decorazione testuale" | `boxes.py` |
| "disegno ASCII di un gatto / drago / natale", "cerca arte ASCII" | `art_search.py` |
| "QR code per questo URL", "meteo ASCII", "tempo che fa a Roma" | `utils.py` |
| "converti questa immagine in ASCII", "foto → ASCII art" | `image_ascii.py` |

---

## Script 1 — `banner.py` · Banner testuale ASCII

Genera un banner di testo in grandi caratteri ASCII usando pyfiglet (571 font disponibili offline).

### Input

| Campo | Tipo | Default | Descrizione |
|---|---|---|---|
| `text` | string | `"Hello"` | Testo da convertire in banner |
| `font` | string | `"slant"` | Nome del font pyfiglet |
| `width` | integer | `120` | Larghezza massima in caratteri |
| `list_fonts` | boolean | `false` | Se `true`, elenca tutti i font disponibili (ignora `text`) |
| `use_api` | boolean | `false` | Se `true`, usa l'API asciified.thelicato.io invece di pyfiglet locale |

### Font popolari

`slant`, `doom`, `big`, `banner3`, `cyberlarge`, `3-d`, `gothic`, `block`, `mini`, `digital`, `starwars`, `graffiti`, `larry3d`, `univers`, `isometric1`, `speed`, `epic`

### Output

```json
{
  "success": true,
  "banner": "   _____ _            __\n  / ___/(_)___ _____  / /_\n  \\__ \\/ / __ `/ __ \\/ __/\n ___/ / / /_/ / / / / /_\n/____/_/\\__, /_/ /_/\\__/\n       /____/\n",
  "font": "slant",
  "source": "slant",
  "message": "```\n...\n```"
}
```

### ⚠️ Rendering

Mostra sempre il campo `message` direttamente nella risposta — contiene il banner formattato in un blocco di codice.

---

## Script 2 — `cowsay.py` · Fumetti ASCII con animali

Genera fumetti ASCII stile cowsay. Supporta oltre 50 personaggi (mucca, Tux, drago, alce, elefante, fantasmi, pony...).

### Input

| Campo | Tipo | Default | Descrizione |
|---|---|---|---|
| `text` | string | `"Moo!"` | Testo da dire o pensare |
| `character` | string | `"default"` | Nome del personaggio (es. `tux`, `dragon`, `stegosaurus`) |
| `think` | boolean | `false` | Se `true`, usa cowthink (fumetto pensiero) invece di cowsay |
| `list_characters` | boolean | `false` | Se `true`, elenca tutti i personaggi disponibili |

### Personaggi notevoli

`default` (mucca), `tux` (pinguino Linux), `dragon`, `stegosaurus`, `moose`, `elephant`, `ghostbusters`, `skeleton`, `snowman`, `vader`, `kitty`, `hellokitty`, `sheep`, `turkey`, `turtle`

### Output

```json
{
  "success": true,
  "art": " _______\n< Hello >\n -------\n        \\   ^__^\n         \\  (oo)\\_______\n            (__)\\       )\\/\\\n                ||----w |\n                ||     ||\n",
  "character": "default",
  "mode": "cowsay",
  "message": "```\n...\n```"
}
```

### ⚠️ Rendering

Mostra sempre il campo `message` direttamente nella risposta.

---

## Script 3 — `boxes.py` · Cornici decorative ASCII

Racchiude testo in cornici ornamentali usando il tool `boxes` (70+ stili). Può generare prima un banner pyfiglet e poi racchiuderlo.

### Input

| Campo | Tipo | Default | Descrizione |
|---|---|---|---|
| `text` | string | `"Hello"` | Testo da racchiudere nella cornice |
| `design` | string | `"stone"` | Stile di cornice |
| `use_banner` | boolean | `false` | Se `true`, genera prima un banner pyfiglet del testo, poi lo racchiude |
| `banner_font` | string | `"slant"` | Font pyfiglet (usato solo se `use_banner=true`) |
| `list_designs` | boolean | `false` | Se `true`, elenca tutti gli stili disponibili |

### Stili notevoli

`stone`, `parchment`, `cat`, `dog`, `unicornsay`, `diamonds`, `simple`, `peek`, `scroll`, `spring`, `whirly`, `caml`, `columns`, `nuke`, `santa-clear`

### Output

```json
{
  "success": true,
  "art": "       _____\n      |     |\n      | Hi! |\n      |_____|\n",
  "design": "stone",
  "message": "```\n...\n```"
}
```

### ⚠️ Rendering

Mostra sempre il campo `message` direttamente nella risposta.

---

## Script 4 — `art_search.py` · Cerca arte ASCII preconfezionata

Recupera disegni ASCII preconfezionati da ascii.co.uk per soggetto. I soggetti vanno specificati **in inglese**.

### Input

| Campo | Tipo | Default | Descrizione |
|---|---|---|---|
| `subject` | string | `"cat"` | Soggetto da cercare **in inglese** (es. `cat`, `dragon`, `skull`) |
| `max_results` | integer | `2` | Numero massimo di risultati (1–5) |

### Soggetti di esempio

`cat`, `dog`, `dragon`, `skull`, `christmas`, `rocket`, `robot`, `butterfly`, `eagle`, `wolf`, `rose`, `beer`, `coffee`, `ghost`, `alien`, `shark`

### Output (successo)

```json
{
  "success": true,
  "subject": "cat",
  "count": 2,
  "results": ["  /\\_/\\  \n ( o.o ) \n  > ^ <\n", "..."],
  "message": "Trovati **2** disegni ASCII per \"**cat**\":\n\n```\n...\n```\n\n---\n\n```\n...\n```"
}
```

### Output (nessun risultato)

```json
{
  "success": false,
  "subject": "xyz",
  "error": "Nessuna arte ASCII trovata per \"xyz\". Prova un soggetto diverso..."
}
```

### ⚠️ Rendering

Mostra sempre il campo `message` direttamente nella risposta. Se `success=false`, comunica all'utente il messaggio di errore e suggerisci soggetti alternativi.

---

## Script 5 — `utils.py` · QR code e meteo ASCII

Due modalità in un unico script: generazione di QR code testuali e previsioni meteo in ASCII art.

### Input — modalità QR (`mode: "qr"`)

| Campo | Tipo | Default | Descrizione |
|---|---|---|---|
| `mode` | string | — | Deve essere `"qr"` |
| `text` | string | — | URL o testo da codificare nel QR (obbligatorio) |

### Input — modalità meteo (`mode: "weather"`)

| Campo | Tipo | Default | Descrizione |
|---|---|---|---|
| `mode` | string | — | Deve essere `"weather"` |
| `location` | string | — | Città o luogo (es. `"Roma"`, `"London"`, `"Moon"`) |
| `weather_format` | integer | `1` | Formato output: `1`=compatto, `2`=3 giorni esteso, `3`=emoji su una riga |

### Output (QR)

```json
{
  "success": true,
  "mode": "qr",
  "text": "https://example.com",
  "output": "█████████████...",
  "message": "QR code per `https://example.com`:\n\n```\n...\n```"
}
```

### Output (meteo)

```json
{
  "success": true,
  "mode": "weather",
  "location": "Roma",
  "format": 1,
  "output": "⛅ +22°C...",
  "message": "Meteo per **Roma**:\n\n```\n...\n```"
}
```

### ⚠️ Rendering

Mostra sempre il campo `message` direttamente nella risposta.

---

## Script 6 — `image_ascii.py` · Immagine → ASCII art

Scarica un'immagine da URL, la converte in JPEG se necessario (tramite ImageMagick), e la trasforma in ASCII art tramite jp2a.

**Formati supportati**: JPEG, PNG, WebP, GIF, BMP, TIFF, AVIF (tutto ciò che ImageMagick sa leggere).

### Input

| Campo | Tipo | Default | Descrizione |
|---|---|---|---|
| `url` | string | — | URL pubblico dell'immagine (obbligatorio) |
| `width` | integer | `100` | Larghezza output in caratteri (20–300) |
| `invert` | boolean | `false` | Se `true`, inverte chiari/scuri (utile per sfondi scuri) |
| `colors` | boolean | `false` | Se `true`, abilita output ANSI colorato (non funziona in tutti i terminali) |

### Output

```json
{
  "success": true,
  "url": "https://example.com/cat.png",
  "width": 100,
  "inverted": false,
  "converted": true,
  "art": "...",
  "message": "ASCII art da `https://example.com/cat.png` (larghezza 100):\n\n```\n...\n```"
}
```

### ⚠️ Rendering

Mostra sempre il campo `message` direttamente nella risposta.

### Limiti

- Dimensione massima immagine: **10 MB**
- Larghezza massima: 300 caratteri
- L'URL deve essere **pubblicamente accessibile** (no autenticazione)
- **Rete**: `url` è un dominio arbitrario, quindi NON è coperto dall'allowlist del tier `internet`
  (che vale solo per i domini dichiarati nel manifest). Questo script funziona solo su un deploy
  con tier di rete `open`. Gli altri script (`art_search`, `banner` remoto, `utils`) usano domini
  fissi e girano già sul tier `internet`.

---

## Note generali

### Regola di rendering (per tutti gli script)

Quando uno script restituisce un campo `message`, **visualizza sempre quel campo direttamente** nella risposta come testo Markdown. Non riformattare l'output, non aggiungere ulteriori blocchi di codice intorno al contenuto già formattato.

### Gestione errori

Se `success: false`, leggi il campo `error` e comunicalo all'utente in modo chiaro. Per `art_search.py`, suggerisci sempre soggetti alternativi in inglese.

### Accesso di rete

| Script | Rete richiesta | Domini |
|---|---|---|
| `banner.py` (pyfiglet locale), `cowsay.py`, `boxes.py` | nessuna | — |
| `art_search.py` | `internet` | `ascii.co.uk` |
| `banner.py` con `use_api=true` | `internet` | `asciified.thelicato.io` |
| `utils.py` (QR + meteo) | `internet` | `qrenco.de`, `wttr.in` |
| `image_ascii.py` | `open` | URL arbitrario |

I domini fissi sono dichiarati in `runtime.network`: su un deploy con tier `internet` (allowlist)
vengono raggiunti tramite il proxy. `image_ascii.py` scarica un URL arbitrario e richiede il tier `open`.

### Ordine di preferenza script

- Per arte testuale semplice → `banner.py`
- Per arte testuale + cornice → `boxes.py` con `use_banner: true`
- Per immagini reali → `image_ascii.py`
- Per disegni tematici → `art_search.py`
