#!/usr/bin/env python3
"""
art_search.py — Cerca arte ASCII preconfezionata su ascii.co.uk.

Il sito raccoglie migliaia di disegni ASCII per soggetto.
I soggetti vanno specificati in inglese (cat, dragon, skull, christmas, ecc.).

Input (stdin JSON):
  subject     — soggetto da cercare in inglese (obbligatorio)
  max_results — numero massimo di risultati da restituire (1-5, default: 2)
"""
import sys
import json
import html
import re

import requests

# Timeout generoso: ascii.co.uk può essere lento
_TIMEOUT = 15

# Regex per estrarre blocchi <pre>...</pre> (case-insensitive per sicurezza)
_PRE_RE = re.compile(r'<pre[^>]*>(.*?)</pre>', re.DOTALL | re.IGNORECASE)


def fetch_arts(subject: str, max_results: int) -> list[str]:
    url = f"https://ascii.co.uk/art/{requests.utils.quote(subject)}"
    resp = requests.get(
        url,
        timeout=_TIMEOUT,
        headers={'User-Agent': 'Mozilla/5.0 (compatible; personalAgent/1.0)'},
    )

    if resp.status_code == 404:
        return []
    resp.raise_for_status()

    matches = _PRE_RE.findall(resp.text)
    if not matches:
        return []

    results = []
    for raw in matches[:max_results]:
        # Decodifica entità HTML e rimuove tag residui
        cleaned = html.unescape(raw)
        cleaned = re.sub(r'<[^>]+>', '', cleaned)
        cleaned = cleaned.strip()
        if cleaned and len(cleaned) > 5:
            results.append(cleaned)

    return results


def main() -> None:
    data        = json.load(sys.stdin)
    subject     = data.get('subject', 'cat').strip()
    max_results = max(1, min(5, int(data.get('max_results', 2))))

    if not subject:
        raise ValueError('"subject" è obbligatorio')

    arts = fetch_arts(subject, max_results)

    if not arts:
        print(json.dumps({
            'success': False,
            'subject': subject,
            'error':   f'Nessuna arte ASCII trovata per "{subject}". '
                       f'Prova un soggetto diverso in inglese '
                       f'(es. cat, dog, dragon, skull, christmas, rocket).',
        }))
        return

    # Costruisce il messaggio con separatori
    blocks = [f'```\n{art}\n```' for art in arts]
    message = (
        f'Trovati **{len(arts)}** disegni ASCII per "**{subject}**":\n\n' +
        '\n\n---\n\n'.join(blocks)
    )

    print(json.dumps({
        'success': True,
        'subject': subject,
        'count':   len(arts),
        'results': arts,
        'message': message,
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success': False,
            'error':   str(e),
            'stack':   traceback.format_exc(),
        }))
        sys.exit(1)
