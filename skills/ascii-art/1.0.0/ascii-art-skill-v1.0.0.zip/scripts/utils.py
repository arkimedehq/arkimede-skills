#!/usr/bin/env python3
"""
utils.py — Utilità ASCII: QR code e meteo.

Modalità 'qr':
  Genera un QR code testuale tramite qrenco.de.
  Input: text (URL o qualsiasi stringa)

Modalità 'weather':
  Mostra le condizioni meteo in ASCII art tramite wttr.in.
  Input: location (es. "Roma", "London", "Tokyo", "Moon")
  Formati:
    1 = compatto con grafica ASCII (default)
    2 = esteso 3 giorni
    3 = simboli emoji su una riga

Input (stdin JSON):
  mode            — 'qr' | 'weather' (obbligatorio)
  text            — testo/URL per QR (obbligatorio se mode=qr)
  location        — città/luogo (obbligatorio se mode=weather)
  weather_format  — 1|2|3 (default: 1, solo per mode=weather)
"""
import sys
import json
from urllib.parse import quote as _url_quote

import requests

_TIMEOUT = 15
_HEADERS = {'User-Agent': 'curl/7.68.0'}   # wttr.in restituisce testo se User-Agent è curl


def generate_qr(text: str) -> str:
    url  = f"https://qrenco.de/{_url_quote(text)}"
    resp = requests.get(url, timeout=_TIMEOUT, headers=_HEADERS)
    resp.raise_for_status()
    return resp.text


def get_weather(location: str, fmt: int) -> str:
    # wttr.in accetta ?format=1/2/3 per output testuale
    url  = f"https://wttr.in/{_url_quote(location)}?format={fmt}"
    resp = requests.get(url, timeout=_TIMEOUT, headers=_HEADERS)
    resp.raise_for_status()
    return resp.text


def main() -> None:
    data   = json.load(sys.stdin)
    mode   = data.get('mode', '').strip().lower()

    if mode == 'qr':
        text = data.get('text', '').strip()
        if not text:
            raise ValueError('"text" è obbligatorio per mode=qr')

        output = generate_qr(text)
        print(json.dumps({
            'success': True,
            'mode':    'qr',
            'text':    text,
            'output':  output,
            'message': f'QR code per `{text}`:\n\n```\n{output}\n```',
        }))

    elif mode == 'weather':
        location = data.get('location', '').strip()
        if not location:
            raise ValueError('"location" è obbligatorio per mode=weather')

        fmt = max(1, min(3, int(data.get('weather_format', 1))))
        output = get_weather(location, fmt)

        print(json.dumps({
            'success':  True,
            'mode':     'weather',
            'location': location,
            'format':   fmt,
            'output':   output,
            'message':  f'Meteo per **{location}**:\n\n```\n{output}\n```',
        }))

    else:
        raise ValueError(f'mode non valido: "{mode}". Usa "qr" o "weather".')


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success': False,
            'error':   str(e),
            'stack':   traceback.format_exc(),
        }))
        sys.exit(1)
