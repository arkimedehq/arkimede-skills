#!/usr/bin/env python3
"""
boxes.py — Racchiude testo in cornici decorative ASCII tramite il tool `boxes`.

Stili notevoli (70+ disponibili):
  stone, parchment, cat, dog, unicornsay, diamonds, c-cmt, html-cmt,
  simple, peek, columns, scroll, spring, whirly, caml, ada-box, ada-cmt

Con use_banner=true: genera prima un banner pyfiglet, poi lo racchiude nella cornice.
Con list_designs=true: restituisce la lista completa degli stili disponibili.

Input (stdin JSON):
  text         — testo da racchiudere (obbligatorio)
  design       — nome stile cornice (default: "stone")
  use_banner   — se true genera prima un banner pyfiglet
  banner_font  — font pyfiglet per il banner (usato solo con use_banner=true)
  list_designs — se true elenca tutti gli stili disponibili
"""
import sys
import json
import subprocess


def get_available_designs() -> list[str]:
    """Recupera la lista degli stili tramite `boxes -l`."""
    try:
        result = subprocess.run(
            ['boxes', '-l'],
            capture_output=True, text=True, check=True,
        )
        designs = []
        for line in result.stdout.splitlines():
            stripped = line.strip()
            # Ogni riga che non inizia con spazio e non è vuota è un nome stile
            if stripped and not stripped.startswith(('(', 'author', 'keyword', 'tags', 'sample')):
                candidate = stripped.split()[0]
                if candidate.replace('-', '').replace('_', '').isalnum():
                    designs.append(candidate)
        return sorted(set(designs)) or _FALLBACK_DESIGNS
    except Exception:
        return _FALLBACK_DESIGNS


_FALLBACK_DESIGNS = [
    'ada-box', 'ada-cmt', 'boy', 'c-cmt', 'c-cmt2', 'caml', 'cat', 'columns',
    'diamonds', 'dog', 'face', 'girl', 'html-cmt', 'javadoc', 'lisp-cmt',
    'mouse', 'nuke', 'parchment', 'peek', 'pound-cmt', 'santa-clear',
    'scroll', 'shell', 'simple', 'spring', 'stark1', 'stark2', 'stone',
    'tex-box', 'tex-cmt', 'three-in-one', 'unicornsay', 'vim-cmt',
    'whirly', 'xes',
]


def apply_boxes(text: str, design: str) -> str:
    result = subprocess.run(
        ['boxes', '-d', design],
        input=text,
        capture_output=True, text=True,
    )
    if result.returncode != 0 or not result.stdout.strip():
        # Design non trovato → fallback a "simple"
        result = subprocess.run(
            ['boxes', '-d', 'simple'],
            input=text,
            capture_output=True, text=True, check=True,
        )
    return result.stdout


def main() -> None:
    data         = json.load(sys.stdin)
    text         = data.get('text', 'Hello')
    design       = data.get('design', 'stone')
    use_banner   = bool(data.get('use_banner', False))
    banner_font  = data.get('banner_font', 'slant')
    list_mode    = bool(data.get('list_designs', False))

    # ── Modalità lista stili ───────────────────────────────────────────────────
    if list_mode:
        designs = get_available_designs()
        print(json.dumps({
            'success': True,
            'designs': designs,
            'count':   len(designs),
            'message': f'Stili di cornice disponibili ({len(designs)}):\n\n' +
                       ', '.join(f'`{d}`' for d in designs),
        }))
        return

    # ── Generazione banner interno (opzionale) ─────────────────────────────────
    inner_text = text
    if use_banner:
        try:
            import pyfiglet
            inner_text = pyfiglet.figlet_format(text, font=banner_font, width=100)
        except pyfiglet.FontNotFound:
            inner_text = pyfiglet.figlet_format(text, width=100)

    # ── Applicazione cornice ───────────────────────────────────────────────────
    art = apply_boxes(inner_text, design)

    print(json.dumps({
        'success': True,
        'art':     art,
        'design':  design,
        'message': f'```\n{art}\n```',
    }))


if __name__ == '__main__':
    try:
        main()
    except FileNotFoundError:
        print(json.dumps({
            'success': False,
            'error':   'boxes non trovato nel PATH. '
                       'Verifica che la skill sia installata correttamente (dipendenza Nix: boxes).',
        }))
        sys.exit(1)
    except Exception as e:
        import traceback
        print(json.dumps({
            'success': False,
            'error':   str(e),
            'stack':   traceback.format_exc(),
        }))
        sys.exit(1)
