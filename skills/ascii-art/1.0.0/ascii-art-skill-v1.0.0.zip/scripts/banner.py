#!/usr/bin/env python3
"""
banner.py — Genera banner testuali in stile ASCII art.

Strategia:
  1. pyfiglet locale (571 font, nessuna rete)
  2. asciified.thelicato.io API (fallback o se use_api=true)
  3. pyfiglet con font 'standard' (ultimo fallback se font richiesto non esiste)

Input (stdin JSON):
  text        — testo da convertire (obbligatorio)
  font        — nome font (default: "slant")
  width       — larghezza max in caratteri (default: 120)
  list_fonts  — se true, elenca i font disponibili (ignora text)
  use_api     — se true, usa asciified API invece di pyfiglet locale
"""
import sys
import json
from urllib.parse import quote as _url_quote

import pyfiglet
import requests


def list_available_fonts() -> list[str]:
    return sorted(pyfiglet.FigletFont.getFonts())


def render_pyfiglet(text: str, font: str, width: int) -> tuple[str, str]:
    """Prova il font richiesto, poi 'standard' come fallback."""
    try:
        result = pyfiglet.figlet_format(text, font=font, width=width)
        return result, font
    except pyfiglet.FontNotFound:
        result = pyfiglet.figlet_format(text, font='standard', width=width)
        return result, 'standard (font richiesto non trovato)'


def render_api(text: str, font: str) -> tuple[str, str] | tuple[None, None]:
    """Chiama asciified.thelicato.io. Restituisce (banner, fonte) o (None, None) se fallisce."""
    try:
        url = f"https://asciified.thelicato.io/api/v2/ascii?text={_url_quote(text)}&font={font}"
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200 and resp.text.strip():
            return resp.text, f'asciified-api (font: {font})'
    except Exception:
        pass
    return None, None


def main() -> None:
    data      = json.load(sys.stdin)
    text      = data.get('text', 'Hello')
    font      = data.get('font', 'slant')
    width     = int(data.get('width', 120))
    list_mode = bool(data.get('list_fonts', False))
    use_api   = bool(data.get('use_api', False))

    # ── Modalità lista font ────────────────────────────────────────────────────
    if list_mode:
        fonts = list_available_fonts()
        print(json.dumps({
            'success': True,
            'fonts':   fonts,
            'count':   len(fonts),
            'message': f'Sono disponibili **{len(fonts)} font** pyfiglet.\n\n'
                       f'Esempi popolari: slant, doom, big, banner3, cyberlarge, '
                       f'3-d, gothic, block, mini, digital, starwars, graffiti.\n\n'
                       f'Lista completa: ' + ', '.join(fonts[:30]) + '...',
        }))
        return

    # ── Generazione banner ─────────────────────────────────────────────────────
    banner, source = None, None

    if use_api:
        banner, source = render_api(text, font)

    if banner is None:
        banner, source = render_pyfiglet(text, font, width)

    print(json.dumps({
        'success': True,
        'banner':  banner,
        'font':    font,
        'source':  source,
        'message': f'```\n{banner}\n```',
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success': False,
            'error':   str(e),
            'stack':   traceback.format_exc(),
        }))
        sys.exit(1)
