#!/usr/bin/env python3
"""
cowsay.py — Fumetti ASCII con animali e personaggi tramite cowsay / cowthink.

Personaggi inclusi (50+): default, tux, dragon, stegosaurus, moose, elephant,
kitty, beavis.zen, cheese, daemon, eyes, flaming-sheep, ghostbusters,
hellokitty, meow, milk, moofasa, pony, satanic, sheep, skeleton, snowman...

Input (stdin JSON):
  text             — testo da dire/pensare (obbligatorio)
  character        — nome personaggio (default: "default" = mucca classica)
  think            — se true usa cowthink invece di cowsay
  list_characters  — se true elenca i personaggi disponibili
"""
import sys
import json
import subprocess


def get_available_characters() -> list[str]:
    """Recupera i personaggi disponibili tramite `cowsay -l`."""
    try:
        result = subprocess.run(
            ['cowsay', '-l'],
            capture_output=True, text=True, check=True,
        )
        lines = result.stdout.strip().splitlines()
        # La prima riga è un'intestazione "Cow files in..."
        characters = []
        for line in lines[1:]:
            characters.extend(line.split())
        return sorted(characters)
    except Exception:
        # Fallback alla lista statica se cowsay -l non funziona
        return [
            'beavis.zen', 'blowfish', 'bud-frogs', 'bunny', 'calvin',
            'cheese', 'cock', 'cower', 'daemon', 'default', 'dragon',
            'dragon-and-cow', 'elephant', 'elephant-in-snake', 'eyes',
            'flaming-sheep', 'ghostbusters', 'head-in', 'hellokitty',
            'kiss', 'kitty', 'koala', 'kosh', 'luke-koala', 'mech-and-cow',
            'meow', 'milk', 'moofasa', 'moose', 'mutilated', 'pony',
            'pony-smaller', 'ren', 'satanic', 'sheep', 'skeleton', 'small',
            'snowman', 'stegosaurus', 'stimpy', 'supermilker', 'surgery',
            'three-eyes', 'turkey', 'turtle', 'tux', 'udder', 'vader',
            'vader-koala', 'www',
        ]


def run_cowsay(text: str, character: str, think: bool) -> str:
    cmd = ['cowthink' if think else 'cowsay']
    if character and character not in ('default', ''):
        cmd.extend(['-f', character])
    cmd.append(text)

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.returncode != 0:
        # Personaggio non trovato → fallback alla mucca classica
        fallback_cmd = ['cowthink' if think else 'cowsay', text]
        result = subprocess.run(fallback_cmd, capture_output=True, text=True, check=True)

    return result.stdout


def main() -> None:
    data            = json.load(sys.stdin)
    text            = data.get('text', 'Moo!')
    character       = data.get('character', 'default')
    think           = bool(data.get('think', False))
    list_mode       = bool(data.get('list_characters', False))

    # ── Modalità lista personaggi ──────────────────────────────────────────────
    if list_mode:
        chars = get_available_characters()
        print(json.dumps({
            'success':    True,
            'characters': chars,
            'count':      len(chars),
            'message':    f'Personaggi disponibili ({len(chars)}):\n\n' +
                          ', '.join(f'`{c}`' for c in chars),
        }))
        return

    # ── Generazione fumetto ────────────────────────────────────────────────────
    art = run_cowsay(text, character, think)
    mode_label = 'cowthink' if think else 'cowsay'

    print(json.dumps({
        'success':   True,
        'art':       art,
        'character': character,
        'mode':      mode_label,
        'message':   f'```\n{art}\n```',
    }))


if __name__ == '__main__':
    try:
        main()
    except FileNotFoundError:
        print(json.dumps({
            'success': False,
            'error':   'cowsay non trovato nel PATH. '
                       'Verifica che la skill sia installata correttamente (dipendenza Nix: cowsay).',
        }))
        sys.exit(1)
    except Exception as e:
        import traceback
        print(json.dumps({
            'success': False,
            'error':   str(e),
            'stack':   traceback.format_exc(),
        }))
        sys.exit(1)
