#!/usr/bin/env python3
"""
image_ascii.py — Converte un'immagine (URL) in ASCII art tramite jp2a.

Flusso:
  1. Scarica l'immagine dall'URL
  2. Se non è JPEG, la converte con ImageMagick (magick convert)
  3. Passa il JPEG a jp2a con le opzioni richieste

jp2a supporta solo JPEG in input; ImageMagick gestisce PNG, WebP, GIF, BMP, ecc.

Input (stdin JSON):
  url     — URL dell'immagine (obbligatorio)
  width   — larghezza output in caratteri (default: 100)
  invert  — se true, inverte i caratteri chiari/scuri (default: false)
  colors  — se true, abilita output ANSI colorato (default: false)
"""
import sys
import json
import subprocess
import tempfile
import os
from pathlib import Path
from urllib.parse import urlparse

import requests

_TIMEOUT     = 20
_MAX_BYTES   = 10 * 1024 * 1024   # 10 MB — limite dimensione immagine
_JPEG_MAGIC  = b'\xff\xd8\xff'    # magic bytes per JPEG


def is_jpeg(data: bytes) -> bool:
    return data[:3] == _JPEG_MAGIC


def download_image(url: str) -> bytes:
    """Scarica l'immagine e verifica la dimensione."""
    resp = requests.get(
        url,
        timeout=_TIMEOUT,
        stream=True,
        headers={'User-Agent': 'Mozilla/5.0 (compatible; personalAgent/1.0)'},
    )
    resp.raise_for_status()

    chunks = []
    downloaded = 0
    for chunk in resp.iter_content(chunk_size=65536):
        downloaded += len(chunk)
        if downloaded > _MAX_BYTES:
            raise ValueError(f'Immagine troppo grande (limite: {_MAX_BYTES // 1024 // 1024} MB)')
        chunks.append(chunk)

    return b''.join(chunks)


def to_jpeg(data: bytes, suffix: str) -> bytes:
    """Converte in JPEG via ImageMagick. suffix è l'estensione originale (.png, .webp, ecc.)."""
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as fin:
        fin.write(data)
        fin_path = fin.name

    fout_path = fin_path + '.jpg'
    try:
        result = subprocess.run(
            ['magick', 'convert', fin_path, fout_path],
            capture_output=True, text=True,
        )
        if result.returncode != 0:
            # Prova con 'convert' (vecchio ImageMagick 6)
            result = subprocess.run(
                ['convert', fin_path, fout_path],
                capture_output=True, text=True, check=True,
            )

        with open(fout_path, 'rb') as f:
            return f.read()
    finally:
        for p in (fin_path, fout_path):
            try:
                os.unlink(p)
            except OSError:
                pass


def run_jp2a(jpeg_data: bytes, width: int, invert: bool, colors: bool) -> str:
    """Passa i dati JPEG a jp2a via stdin."""
    cmd = ['jp2a', f'--width={width}', '-']
    if invert:
        cmd.append('--invert')
    if colors:
        cmd.append('--colors')

    result = subprocess.run(
        cmd,
        input=jpeg_data,
        capture_output=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f'jp2a error: {result.stderr.decode(errors="replace").strip()}')

    return result.stdout.decode(errors='replace')


def guess_suffix(url: str, content_type: str) -> str:
    """Ricava l'estensione dell'immagine dall'URL o dal Content-Type."""
    path = urlparse(url).path.lower()
    for ext in ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp', '.tiff', '.tif', '.avif'):
        if path.endswith(ext):
            return ext

    ct = content_type.lower().split(';')[0].strip()
    mapping = {
        'image/jpeg': '.jpg',
        'image/png':  '.png',
        'image/webp': '.webp',
        'image/gif':  '.gif',
        'image/bmp':  '.bmp',
        'image/tiff': '.tiff',
        'image/avif': '.avif',
    }
    return mapping.get(ct, '.img')


def main() -> None:
    data   = json.load(sys.stdin)
    url    = data.get('url', '').strip()
    width  = max(20, min(300, int(data.get('width', 100))))
    invert = bool(data.get('invert', False))
    colors = bool(data.get('colors', False))

    if not url:
        raise ValueError('"url" è obbligatorio')

    # ── Download ───────────────────────────────────────────────────────────────
    resp = requests.get(
        url,
        timeout=_TIMEOUT,
        stream=True,
        headers={'User-Agent': 'Mozilla/5.0 (compatible; personalAgent/1.0)'},
    )
    resp.raise_for_status()
    content_type = resp.headers.get('Content-Type', 'image/jpeg')

    chunks, downloaded = [], 0
    for chunk in resp.iter_content(chunk_size=65536):
        downloaded += len(chunk)
        if downloaded > _MAX_BYTES:
            raise ValueError(f'Immagine troppo grande (limite: {_MAX_BYTES // 1024 // 1024} MB)')
        chunks.append(chunk)
    image_data = b''.join(chunks)

    # ── Conversione JPEG (se necessario) ──────────────────────────────────────
    if is_jpeg(image_data):
        jpeg_data = image_data
        converted = False
    else:
        suffix = guess_suffix(url, content_type)
        jpeg_data = to_jpeg(image_data, suffix)
        converted = True

    # ── jp2a ──────────────────────────────────────────────────────────────────
    art = run_jp2a(jpeg_data, width, invert, colors)

    print(json.dumps({
        'success':   True,
        'url':       url,
        'width':     width,
        'inverted':  invert,
        'converted': converted,
        'art':       art,
        'message':   f'ASCII art da `{url}` (larghezza {width}):\n\n```\n{art}\n```',
    }))


if __name__ == '__main__':
    try:
        main()
    except FileNotFoundError as e:
        tool = 'jp2a' if 'jp2a' in str(e) else 'ImageMagick (magick/convert)'
        print(json.dumps({
            'success': False,
            'error':   f'{tool} non trovato nel PATH. '
                       f'Verifica che la skill sia installata correttamente '
                       f'(dipendenze Nix: jp2a, imagemagick).',
        }))
        sys.exit(1)
    except Exception as e:
        import traceback
        print(json.dumps({
            'success': False,
            'error':   str(e),
            'stack':   traceback.format_exc(),
        }))
        sys.exit(1)
