#!/usr/bin/env python3
"""Shared helpers for the KNX skill: config parsing, connection lifecycle,
group-address map resolution and DPT encode/decode utilities.

All scripts read a JSON payload from stdin and print a JSON result to stdout.
Configuration comes from the `_config` object injected by the executor.
"""
import asyncio
import json
import sys

from xknx import XKNX
from xknx.dpt import DPTArray, DPTBase, DPTBinary
from xknx.io import ConnectionConfig, ConnectionType

CONNECT_TIMEOUT_S = 10

TRUTHY = {"on", "true", "1", "yes", "acceso", "accesa", "aperto", "aperta"}
FALSY = {"off", "false", "0", "no", "spento", "spenta", "chiuso", "chiusa"}


def read_input():
    """Read the JSON payload from stdin."""
    return json.load(sys.stdin)


def output(payload: dict) -> None:
    print(json.dumps(payload, ensure_ascii=False, default=str))


def fail(error: str, **extra) -> None:
    output({"success": False, "error": error, **extra})
    sys.exit(1)


def get_config(data: dict) -> dict:
    cfg = data.get("_config", {}) or {}
    host = (cfg.get("KNX_GATEWAY_HOST") or "").strip()
    port_raw = str(cfg.get("KNX_GATEWAY_PORT") or "3671").strip()
    try:
        port = int(port_raw)
    except ValueError:
        port = 3671
    mode = (cfg.get("KNX_CONNECTION") or "tunneling").strip().lower()
    ga_map = parse_ga_map(cfg.get("KNX_GA_MAP"))
    return {"host": host, "port": port, "mode": mode, "ga_map": ga_map}


def parse_ga_map(raw) -> dict:
    """Parse KNX_GA_MAP into {lowercase name: entry}. Tolerates missing/invalid JSON."""
    if not raw:
        return {}
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except (ValueError, TypeError):
            return {}
    if not isinstance(raw, dict):
        return {}
    parsed = {}
    for name, entry in raw.items():
        if isinstance(entry, str):
            entry = {"ga": entry}
        if isinstance(entry, dict) and entry.get("ga"):
            parsed[str(name).strip().lower()] = {
                "name": str(name).strip(),
                "ga": str(entry["ga"]).strip(),
                "dpt": str(entry["dpt"]).strip() if entry.get("dpt") else None,
                "status_ga": str(entry["status_ga"]).strip() if entry.get("status_ga") else None,
                "description": entry.get("description"),
            }
    return parsed


def resolve_target(data: dict, ga_map: dict, prefer_status: bool = False):
    """Resolve a (group_address, dpt, name) triple from explicit input or the GA map.

    Accepts either `group_address` (+ optional `dpt`) or `name` (looked up in the map).
    When prefer_status is True and the map entry has a status_ga, use it (reads).
    """
    ga = (data.get("group_address") or "").strip()
    dpt = (data.get("dpt") or "").strip() or None
    name = (data.get("name") or "").strip()

    if not ga and name:
        entry = ga_map.get(name.lower())
        if not entry:
            # Fall back to substring match so "luce cucina" finds "Luce Cucina (soffitto)"
            matches = [e for k, e in ga_map.items() if name.lower() in k]
            if len(matches) == 1:
                entry = matches[0]
            elif len(matches) > 1:
                fail(
                    f"Nome ambiguo '{name}': corrisponde a {[m['name'] for m in matches]}. "
                    "Usa il nome esatto o il group address.",
                )
            else:
                fail(
                    f"Nome '{name}' non trovato nella mappa KNX_GA_MAP. "
                    "Usa knx_devices per vedere i dispositivi configurati, "
                    "oppure passa direttamente group_address e dpt.",
                )
        ga = entry["status_ga"] if prefer_status and entry.get("status_ga") else entry["ga"]
        dpt = dpt or entry.get("dpt")
        name = entry["name"]

    if not ga:
        fail("Serve 'group_address' (es. '1/2/3') oppure 'name' presente in KNX_GA_MAP.")
    return ga, dpt, name or None


def reverse_lookup(ga: str, ga_map: dict):
    """Find the map entry whose ga or status_ga matches the given address."""
    for entry in ga_map.values():
        if entry["ga"] == ga or entry.get("status_ga") == ga:
            return entry
    return None


def coerce_value(value, dpt):
    """Normalize LLM-provided values before DPT encoding (on/off strings → bool, numeric strings → numbers)."""
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in TRUTHY:
            return True
        if lowered in FALSY:
            return False
        try:
            return int(value)
        except ValueError:
            pass
        try:
            return float(value)
        except ValueError:
            pass
    return value


def decode_payload(payload, dpt):
    """Decode a DPTArray/DPTBinary telegram payload with the given DPT, best effort."""
    raw = None
    if isinstance(payload, DPTBinary):
        raw = payload.value
    elif isinstance(payload, DPTArray):
        raw = list(payload.value)
    if dpt:
        transcoder = DPTBase.parse_transcoder(dpt)
        if transcoder:
            try:
                value = transcoder.from_knx(payload)
                unit = getattr(transcoder, "unit", None)
                return {"value": value, "unit": unit, "raw": raw}
            except Exception:
                pass
    return {"value": None, "unit": None, "raw": raw}


def build_connection_config(cfg: dict) -> ConnectionConfig:
    mode = cfg["mode"]
    if mode in ("tunneling_tcp", "tcp"):
        conn_type = ConnectionType.TUNNELING_TCP
    elif mode == "routing":
        conn_type = ConnectionType.ROUTING
    else:
        conn_type = ConnectionType.TUNNELING
    if conn_type is ConnectionType.ROUTING:
        return ConnectionConfig(connection_type=conn_type)
    return ConnectionConfig(
        connection_type=conn_type,
        gateway_ip=cfg["host"],
        gateway_port=cfg["port"],
    )


class KnxConnection:
    """Async context manager that opens and closes an XKNX connection with a hard timeout."""

    def __init__(self, cfg: dict, telegram_cb=None):
        self.cfg = cfg
        self.telegram_cb = telegram_cb
        self.xknx = None

    async def __aenter__(self) -> XKNX:
        if self.cfg["mode"] != "routing" and not self.cfg["host"]:
            fail(
                "KNX_GATEWAY_HOST non configurato. Imposta l'IP del gateway KNX/IP "
                "nella configurazione della skill (usa knx_discover per trovarlo).",
            )
        self.xknx = XKNX(connection_config=build_connection_config(self.cfg))
        if self.telegram_cb:
            self.xknx.telegram_queue.register_telegram_received_cb(self.telegram_cb)
        try:
            await asyncio.wait_for(self.xknx.start(), timeout=CONNECT_TIMEOUT_S)
        except asyncio.TimeoutError:
            fail(
                f"Timeout di connessione al gateway KNX {self.cfg['host']}:{self.cfg['port']} "
                f"(modalità {self.cfg['mode']}). Verifica IP, rete e che il gateway "
                "abbia slot di tunneling liberi.",
            )
        except Exception as exc:  # noqa: BLE001 - surfaced as tool output
            fail(f"Connessione al gateway KNX fallita: {exc}")
        return self.xknx

    async def __aexit__(self, exc_type, exc, tb) -> bool:
        if self.xknx:
            try:
                await asyncio.wait_for(self.xknx.stop(), timeout=5)
            except Exception:  # noqa: BLE001 - best-effort teardown
                pass
        return False


def run(coro) -> None:
    """Entry-point wrapper: run the coroutine and convert exceptions to JSON errors."""
    try:
        asyncio.run(coro)
    except SystemExit:
        raise
    except Exception as exc:  # noqa: BLE001 - surfaced as tool output
        fail(str(exc))
