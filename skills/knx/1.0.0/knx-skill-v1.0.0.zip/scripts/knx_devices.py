#!/usr/bin/env python3
"""List the devices configured in the KNX_GA_MAP skill configuration."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from knx_common import get_config, output, read_input  # noqa: E402


def main() -> None:
    data = read_input()
    cfg = get_config(data)
    devices = [
        {
            "name": entry["name"],
            "group_address": entry["ga"],
            "dpt": entry.get("dpt"),
            "status_group_address": entry.get("status_ga"),
            "description": entry.get("description"),
        }
        for entry in cfg["ga_map"].values()
    ]
    devices.sort(key=lambda d: d["name"].lower())
    message = (
        f"{len(devices)} dispositivi configurati."
        if devices
        else (
            "Nessun dispositivo configurato in KNX_GA_MAP. Si possono comunque usare "
            "group address espliciti con knx_read/knx_write, oppure configurare la mappa "
            "nelle impostazioni della skill."
        )
    )
    output({"success": True, "devices": devices, "count": len(devices), "message": message})


main()
