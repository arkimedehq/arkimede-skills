#!/usr/bin/env python3
"""Discover KNX/IP gateways on the local network via multicast search."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from knx_common import fail, output, read_input, run  # noqa: E402

from xknx import XKNX  # noqa: E402
from xknx.io import GatewayScanner  # noqa: E402


async def main() -> None:
    data = read_input()
    timeout = min(max(int(data.get("timeout") or 4), 1), 15)

    xknx = XKNX()
    scanner = GatewayScanner(xknx, timeout_in_seconds=timeout)
    try:
        gateways = await scanner.scan()
    except Exception as exc:  # noqa: BLE001 - surfaced as tool output
        fail(f"Scansione fallita: {exc}")

    found = [
        {
            "name": gw.name,
            "host": gw.ip_addr,
            "port": gw.port,
            "individual_address": str(gw.individual_address),
            "supports_tunnelling": gw.supports_tunnelling,
            "supports_tunnelling_tcp": gw.supports_tunnelling_tcp,
            "supports_routing": gw.supports_routing,
        }
        for gw in gateways
    ]
    message = (
        f"Trovati {len(found)} gateway KNX/IP. Usa 'host' come KNX_GATEWAY_HOST nella config della skill."
        if found
        else (
            "Nessun gateway KNX/IP trovato. La discovery usa multicast e può non funzionare "
            "dal container: se conosci l'IP del gateway impostalo direttamente in KNX_GATEWAY_HOST."
        )
    )
    output({"success": True, "gateways": found, "message": message})


run(main())
