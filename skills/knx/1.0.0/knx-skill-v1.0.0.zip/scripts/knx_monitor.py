#!/usr/bin/env python3
"""Listen to KNX bus traffic for a bounded time window and return decoded telegrams."""
import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from knx_common import (  # noqa: E402
    KnxConnection,
    decode_payload,
    get_config,
    output,
    read_input,
    reverse_lookup,
    run,
)

from xknx.telegram.apci import GroupValueRead, GroupValueResponse, GroupValueWrite  # noqa: E402

MAX_DURATION_S = 60
MAX_TELEGRAMS = 200


async def main() -> None:
    data = read_input()
    cfg = get_config(data)
    duration = min(max(int(data.get("duration") or 10), 1), MAX_DURATION_S)
    ga_filter = (data.get("group_address") or "").strip() or None

    telegrams = []
    started = time.time()

    def on_telegram(telegram) -> None:
        if len(telegrams) >= MAX_TELEGRAMS:
            return
        ga = str(telegram.destination_address)
        if ga_filter and ga != ga_filter:
            return
        payload = telegram.payload
        if isinstance(payload, GroupValueRead):
            kind, decoded = "read", None
        elif isinstance(payload, (GroupValueWrite, GroupValueResponse)):
            kind = "write" if isinstance(payload, GroupValueWrite) else "response"
            entry = reverse_lookup(ga, cfg["ga_map"])
            decoded = decode_payload(payload.value, entry.get("dpt") if entry else None)
        else:
            kind, decoded = type(payload).__name__, None
        entry = reverse_lookup(ga, cfg["ga_map"])
        telegrams.append(
            {
                "t": round(time.time() - started, 2),
                "source": str(telegram.source_address),
                "group_address": ga,
                "name": entry["name"] if entry else None,
                "type": kind,
                **(decoded or {}),
            }
        )

    async with KnxConnection(cfg, telegram_cb=on_telegram):
        await asyncio.sleep(duration)

    output(
        {
            "success": True,
            "duration": duration,
            "telegrams": telegrams,
            "count": len(telegrams),
            "message": (
                f"Osservati {len(telegrams)} telegrammi in {duration}s."
                + (" Nessun traffico sul bus nel periodo." if not telegrams else "")
            ),
        }
    )


run(main())
