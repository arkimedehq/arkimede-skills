#!/usr/bin/env python3
"""Write a value to a KNX group address (GroupValueWrite)."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from knx_common import (  # noqa: E402
    KnxConnection,
    coerce_value,
    fail,
    get_config,
    output,
    read_input,
    resolve_target,
    run,
)

from xknx.tools import group_value_write  # noqa: E402


async def main() -> None:
    data = read_input()
    cfg = get_config(data)

    if "value" not in data:
        fail("Campo 'value' obbligatorio.")
    ga, dpt, name = resolve_target(data, cfg["ga_map"], prefer_status=False)
    value = coerce_value(data["value"], dpt)

    if dpt is None and not isinstance(value, bool):
        fail(
            "Per valori non booleani serve il 'dpt' (es. '5.001' percentuale, '9.001' temperatura, "
            "'17.001' scena). Solo on/off può essere scritto senza dpt.",
        )

    async with KnxConnection(cfg) as xknx:
        # group_value_write is synchronous: it enqueues the telegram. Give the
        # outgoing queue a moment to flush before the connection is torn down.
        group_value_write(xknx, ga, value, value_type=dpt)
        await asyncio.sleep(0.5)

    label = name or ga
    output(
        {
            "success": True,
            "group_address": ga,
            "name": name,
            "dpt": dpt,
            "value": value,
            "message": f"Scritto {value!r} su {label} ({ga}).",
        }
    )


run(main())
