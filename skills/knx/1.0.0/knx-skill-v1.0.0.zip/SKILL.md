---
name: knx
description: 'Controlla un impianto domotico KNX tramite gateway KNX/IP (router o interfaccia): accende/spegne luci, comanda dimmer, tapparelle, scene e termostati scrivendo sui group address, legge lo stato di sensori e attuatori, monitora il traffico del bus in tempo reale e scopre i gateway sulla rete. Supporta nomi amichevoli configurabili (mappa group address) e tutti i datapoint type KNX.'
version: 1.0.0
author: info@rstonline.it
license: MIT
runtime:
  dependencies:
    python:
    - xknx>=3.0
  network: []
  config:
  - key: KNX_GATEWAY_HOST
    description: "IP del gateway KNX/IP (router o interfaccia), es. 192.168.1.160. Usa knx_discover per trovarlo."
    required: true
    secret: false
  - key: KNX_GATEWAY_PORT
    description: "Porta KNXnet/IP del gateway"
    default: "3671"
    required: false
    secret: false
  - key: KNX_CONNECTION
    description: "Modalità di connessione: tunneling (UDP, consigliata), tunneling_tcp, routing (multicast, solo con router KNX/IP)"
    default: "tunneling"
    required: false
    secret: false
  - key: KNX_GA_MAP
    description: 'Mappa JSON nome→group address: {"luce cucina": {"ga": "1/1/5", "dpt": "switch", "status_ga": "1/4/5", "description": "..."}}. Permette di comandare i dispositivi per nome.'
    required: false
    secret: false
  scripts:
  - filename: scripts/knx_write.py
    language: python
    description: |
      Scrive un valore su un group address KNX (GroupValueWrite): accende/spegne luci, imposta dimmer, muove tapparelle, richiama scene, imposta setpoint termostati. Accetta il nome di un dispositivo configurato in KNX_GA_MAP oppure group_address+dpt espliciti. Valori booleani (on/off/true/false) non richiedono dpt; per gli altri serve il dpt (es. 5.001 percentuale 0-100, 9.001 temperatura, 17.001 scena, 1.008 su/giù). Chiamalo quando l'utente chiede di comandare un dispositivo della casa.
    input_schema:
      type: object
      required:
      - value
      properties:
        name:
          type: string
          description: Nome del dispositivo come configurato in KNX_GA_MAP (alternativo a group_address)
        group_address:
          type: string
          description: 'Group address KNX esplicito, es. "1/1/5" (alternativo a name)'
        value:
          description: 'Valore da scrivere: true/false o "on"/"off" per interruttori, numero per dimmer/temperature/scene'
        dpt:
          type: string
          description: 'Datapoint type KNX: es. "1.001" o "switch" (on/off), "5.001" o "percent" (0-100%), "9.001" o "temperature" (°C), "17.001" o "scene_number", "1.008" o "up_down". Obbligatorio per valori non booleani se il dispositivo non è in mappa.'
  - filename: scripts/knx_read.py
    language: python
    description: |
      Legge lo stato attuale di uno o più group address KNX (GroupValueRead con attesa della risposta): stato luci, posizione tapparelle, temperature, sensori. Accetta un singolo target (name oppure group_address+dpt) o una lista items per letture multiple in una sola connessione. Se il dispositivo è in KNX_GA_MAP usa automaticamente lo status_ga e il dpt configurati. Chiamalo quando l'utente chiede lo stato di un dispositivo o un valore misurato.
    input_schema:
      type: object
      properties:
        name:
          type: string
          description: Nome del dispositivo in KNX_GA_MAP (alternativo a group_address)
        group_address:
          type: string
          description: 'Group address da leggere, es. "1/4/5" (alternativo a name)'
        dpt:
          type: string
          description: 'Datapoint type per decodificare la risposta, es. "9.001" per temperature'
        items:
          type: array
          description: 'Letture multiple: lista di oggetti {name} oppure {group_address, dpt} (max 30)'
          items:
            type: object
            properties:
              name:
                type: string
              group_address:
                type: string
              dpt:
                type: string
  - filename: scripts/knx_monitor.py
    language: python
    description: |
      Ascolta il traffico del bus KNX per una finestra di tempo limitata (1-60 secondi) e restituisce i telegrammi osservati, decodificati quando il group address è in KNX_GA_MAP. Utile per diagnosi, per scoprire quale group address usa un pulsante fisico (premi il pulsante durante il monitor) o per verificare che un comando sia transitato. Con group_address filtra solo quel GA. Chiamalo per debug dell'impianto o per identificare indirizzi sconosciuti.
    input_schema:
      type: object
      properties:
        duration:
          type: integer
          description: 'Durata dell''ascolto in secondi (1-60, default: 10)'
          default: 10
        group_address:
          type: string
          description: Se indicato, riporta solo i telegrammi verso questo group address
  - filename: scripts/knx_devices.py
    language: python
    description: |
      Elenca i dispositivi KNX configurati nella mappa KNX_GA_MAP della skill: nome, group address di comando, group address di stato, datapoint type e descrizione. Chiamalo per sapere quali dispositivi si possono comandare per nome, o quando l'utente chiede cosa può controllare in casa.
    input_schema:
      type: object
      properties: {}
  - filename: scripts/knx_discover.py
    language: python
    description: |
      Cerca i gateway KNX/IP (router e interfacce) sulla rete locale via multicast discovery e ne riporta IP, porta, individual address e modalità supportate (tunneling UDP/TCP, routing). Chiamalo in fase di configurazione iniziale per trovare l'IP da mettere in KNX_GATEWAY_HOST, o per diagnosticare problemi di connessione. Nota: il multicast può non funzionare dal container; in tal caso l'IP va fornito manualmente.
    input_schema:
      type: object
      properties:
        timeout:
          type: integer
          description: 'Secondi di attesa risposte (1-15, default: 4)'
          default: 4
---

# KNX — Domotica di casa

## Quando usarla

Usa questa skill quando l'utente chiede di:
- accendere/spegnere/regolare **luci, dimmer, prese comandate**
- muovere **tapparelle, tende, veneziane**
- richiamare **scene** o impostare **termostati/setpoint**
- leggere **stati e sensori** (temperatura, luminosità, presenza, stato luci)
- fare **diagnosi del bus KNX** (monitor traffico, scoprire group address, trovare il gateway)

**Non** usarla per dispositivi non KNX (Wi-Fi, Zigbee, ecc.).

## Come usarla

1. Se l'utente usa un nome ("accendi la luce in cucina"), chiama prima `knx_devices` per
   vedere i dispositivi configurati, poi `knx_write` con `name`. La risoluzione per nome
   funziona anche con corrispondenza parziale non ambigua.
2. Se il dispositivo non è in mappa, servono `group_address` + `dpt` espliciti
   (chiedili all'utente o scoprili con `knx_monitor` mentre preme il pulsante fisico).
3. Per gli stati usa `knx_read`: se il dispositivo è in mappa viene usato automaticamente
   il group address di stato (`status_ga`).

### DPT più comuni

| DPT | Alias | Uso | Valori |
|-----|-------|-----|--------|
| 1.001 | `switch` | luci on/off | true/false |
| 1.008 | `up_down` | tapparelle su/giù | false=su, true=giù |
| 3.007 | — | dimming relativo | step |
| 5.001 | `percent` | dimmer/posizione % | 0–100 |
| 9.001 | `temperature` | temperature | °C |
| 14.056 | `power` | potenza | W |
| 17.001 | `scene_number` | scene | 1–64 |

### Regole di comportamento

- **Scrivi sul bus solo ciò che l'utente ha chiesto**: un `knx_write` aziona dispositivi
  reali della casa. Non fare scritture "di prova" di tua iniziativa.
- Se una richiesta è ambigua su quale dispositivo comandare, elenca i candidati e chiedi.
- Dopo un comando, se esiste lo `status_ga`, puoi verificare con `knx_read` e confermare
  all'utente lo stato effettivo.

## Output

Tutti gli script restituiscono JSON con `success` e un campo `message` riassuntivo in
italiano da usare come base per la risposta. `knx_read` restituisce `results[]` con
`value`/`unit`; `knx_monitor` restituisce `telegrams[]` con sorgente, group address,
nome (se in mappa) e valore decodificato.
