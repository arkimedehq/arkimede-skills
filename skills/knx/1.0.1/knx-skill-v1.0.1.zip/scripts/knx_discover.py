#!/usr/bin/env python3
"""Discover KNX/IP gateways on the local network via multicast search.

When multicast finds nothing (typical from NATed containers) and a gateway is
configured, falls back to a unicast DescriptionRequest probe so the script
doubles as a connection diagnostic for the configured gateway.
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from knx_common import fail, get_config, output, read_input, run  # noqa: E402

from xknx import XKNX  # noqa: E402
from xknx.io import GatewayScanner  # noqa: E402
from xknx.io.self_description import request_description  # noqa: E402

PROBE_TIMEOUT_S = 5


def describe(gw) -> dict:
    """Serialize a GatewayDescriptor into the response shape."""
    return {
        "name": gw.name,
        "host": gw.ip_addr,
        "port": gw.port,
        "individual_address": str(gw.individual_address),
        "supports_tunnelling": gw.supports_tunnelling,
        "supports_tunnelling_tcp": gw.supports_tunnelling_tcp,
        "supports_routing": gw.supports_routing,
    }


async def probe_configured_gateway(cfg: dict) -> dict:
    """Unicast DescriptionRequest to the configured gateway (works through NAT)."""
    try:
        gw = await asyncio.wait_for(
            request_description(cfg["host"], cfg["port"]), timeout=PROBE_TIMEOUT_S
        )
        return {"host": cfg["host"], "port": cfg["port"], "reachable": True, "gateway": describe(gw)}
    except Exception as exc:  # noqa: BLE001 - surfaced as tool output
        return {"host": cfg["host"], "port": cfg["port"], "reachable": False, "error": str(exc)}


async def main() -> None:
    data = read_input()
    cfg = get_config(data)
    timeout = min(max(int(data.get("timeout") or 4), 1), 15)

    xknx = XKNX()
    scanner = GatewayScanner(xknx, timeout_in_seconds=timeout)
    try:
        gateways = await scanner.scan()
    except Exception as exc:  # noqa: BLE001 - surfaced as tool output
        fail(f"Scansione fallita: {exc}")

    found = [describe(gw) for gw in gateways]
    if found:
        output({
            "success": True,
            "gateways": found,
            "message": f"Trovati {len(found)} gateway KNX/IP. Usa 'host' come KNX_GATEWAY_HOST nella config della skill.",
        })
        return

    # Multicast found nothing: probe the configured gateway directly (unicast).
    if cfg["host"]:
        probe = await probe_configured_gateway(cfg)
        message = (
            f"Discovery multicast senza risultati (normale dal container), ma il gateway configurato "
            f"{cfg['host']}:{cfg['port']} risponde: {probe['gateway']['name']}. La connessione KNX funziona."
            if probe["reachable"]
            else (
                f"Discovery multicast senza risultati E il gateway configurato {cfg['host']}:{cfg['port']} "
                f"NON risponde ({probe.get('error', 'errore sconosciuto')}). Verifica IP, rete della skill e che il gateway sia acceso."
            )
        )
        output({"success": True, "gateways": [], "probe": probe, "message": message})
        return

    output({
        "success": True,
        "gateways": [],
        "message": (
            "Nessun gateway KNX/IP trovato. La discovery usa multicast e può non funzionare "
            "dal container: se conosci l'IP del gateway impostalo direttamente in KNX_GATEWAY_HOST."
        ),
    })


run(main())
