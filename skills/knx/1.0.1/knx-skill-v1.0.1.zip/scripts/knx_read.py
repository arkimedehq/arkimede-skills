#!/usr/bin/env python3
"""Read one or more KNX group addresses (GroupValueRead + wait for response)."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from knx_common import (  # noqa: E402
    KnxConnection,
    fail,
    get_config,
    normalize_value,
    output,
    read_input,
    resolve_target,
    run,
)

from xknx.dpt import DPTBase  # noqa: E402
from xknx.tools import read_group_value  # noqa: E402

READ_TIMEOUT_S = 3


async def read_one(xknx, item, ga_map):
    ga, dpt, name = resolve_target(item, ga_map, prefer_status=True)
    transcoder = DPTBase.parse_transcoder(dpt) if dpt else None
    unit = getattr(transcoder, "unit", None) if transcoder else None
    try:
        value = await asyncio.wait_for(
            read_group_value(xknx, ga, value_type=dpt), timeout=READ_TIMEOUT_S
        )
    except asyncio.TimeoutError:
        return {
            "group_address": ga,
            "name": name,
            "dpt": dpt,
            "value": None,
            "error": "Nessuna risposta (il dispositivo potrebbe non avere il flag di lettura attivo su questo GA)",
        }
    return {
        "group_address": ga,
        "name": name,
        "dpt": dpt,
        "value": normalize_value(value),
        "unit": unit,
    }


async def main() -> None:
    data = read_input()
    cfg = get_config(data)

    # Accept either a single target (group_address/name at top level) or items[].
    items = data.get("items")
    if not items:
        items = [data]
    if not isinstance(items, list) or not items:
        fail("Passa 'group_address' (o 'name'), oppure una lista 'items'.")
    if len(items) > 30:
        fail("Massimo 30 letture per chiamata.")

    async with KnxConnection(cfg) as xknx:
        results = [await read_one(xknx, item, cfg["ga_map"]) for item in items]

    ok = sum(1 for r in results if "error" not in r)
    output(
        {
            "success": True,
            "results": results,
            "message": f"Lette {ok}/{len(results)} group address.",
        }
    )


run(main())
