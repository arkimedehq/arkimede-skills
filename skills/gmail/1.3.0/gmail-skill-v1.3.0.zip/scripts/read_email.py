#!/usr/bin/env python3
"""
Gmail Skill — Leggi Email
Recupera il contenuto completo di un messaggio Gmail.
"""

import sys
import json
import os

sys.path.insert(0, os.path.dirname(__file__))
import gmail_auth


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    email_id     = data.get('email_id', '').strip()
    mark_as_read = data.get('mark_as_read', True)

    if not email_id:
        raise ValueError("Il campo 'email_id' è obbligatorio.")

    # Autenticazione
    service = gmail_auth.get_gmail_service(_config)

    # Recupera messaggio completo
    msg = service.users().messages().get(
        userId = 'me',
        id     = email_id,
        format = 'full'
    ).execute()

    headers   = msg.get('payload', {}).get('headers', [])
    label_ids = msg.get('labelIds', [])

    # Decodifica corpo
    body = gmail_auth.decode_body(msg.get('payload', {}))

    # Allegati
    attachments = gmail_auth.list_attachments(msg.get('payload', {}))

    # Segna come letta se richiesto
    if mark_as_read and 'UNREAD' in label_ids:
        service.users().messages().modify(
            userId = 'me',
            id     = email_id,
            body   = {'removeLabelIds': ['UNREAD']}
        ).execute()

    result = {
        "success":      True,
        "id":           msg['id'],
        "thread_id":    msg.get('threadId', ''),
        "subject":      gmail_auth.get_header(headers, 'Subject') or '(nessun oggetto)',
        "from":         gmail_auth.get_header(headers, 'From'),
        "to":           gmail_auth.get_header(headers, 'To'),
        "cc":           gmail_auth.get_header(headers, 'Cc'),
        "reply_to":     gmail_auth.get_header(headers, 'Reply-To'),
        "date":         gmail_auth.get_header(headers, 'Date'),
        "message_id_header": gmail_auth.get_header(headers, 'Message-ID'),
        "body_text":    body['text'],
        "body_html":    body['html'],
        "snippet":      msg.get('snippet', ''),
        "attachments":  attachments,
        "labels":       label_ids,
        "was_unread":   'UNREAD' in label_ids,
        "marked_read":  mark_as_read and 'UNREAD' in label_ids,
    }

    # Prepara il messaggio di risposta per il LLM
    subj = result["subject"]
    frm  = result["from"]
    result["message"] = f"Email da '{frm}' con oggetto '{subj}' recuperata con successo."

    print(json.dumps(result))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc()
        }))
        sys.exit(1)
