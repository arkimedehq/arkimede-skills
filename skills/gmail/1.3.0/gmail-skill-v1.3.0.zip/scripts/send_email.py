#!/usr/bin/env python3
"""
Gmail Skill — Invia Email
Invia un nuovo messaggio email via Gmail API.
"""

import sys
import json
import os

# Importa il modulo helper della skill (stesso directory)
sys.path.insert(0, os.path.dirname(__file__))
import gmail_auth


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    # Parametri input
    to          = data.get('to', '')
    subject     = data.get('subject', '')
    body        = data.get('body', '')
    cc          = data.get('cc', None)
    bcc         = data.get('bcc', None)
    html        = data.get('html', False)
    attachments = data.get('attachments', None)  # lista di path assoluti

    # Validazione
    if not to:
        raise ValueError("Il campo 'to' (destinatario) è obbligatorio.")
    if not subject:
        raise ValueError("Il campo 'subject' (oggetto) è obbligatorio.")
    if not body:
        raise ValueError("Il campo 'body' (corpo) è obbligatorio.")
    if attachments is not None and not isinstance(attachments, list):
        raise ValueError("Il campo 'attachments' deve essere una lista di path assoluti.")

    # Autenticazione e servizio Gmail
    service = gmail_auth.get_gmail_service(_config)
    sender  = gmail_auth.get_sender_address(_config, service)

    # Costruzione messaggio
    message = gmail_auth.build_raw_message(
        sender      = sender,
        to          = to,
        subject     = subject,
        body        = body,
        html        = html,
        cc          = cc,
        bcc         = bcc,
        attachments = attachments,
    )

    # Invio
    sent = service.users().messages().send(userId='me', body=message).execute()

    attachment_names = [os.path.basename(p) for p in attachments] if attachments else []
    summary = f"✅ Email inviata a {to} con oggetto '{subject}'."
    if attachment_names:
        summary += f" Allegati: {', '.join(attachment_names)}."

    print(json.dumps({
        "success":     True,
        "message_id":  sent.get('id'),
        "thread_id":   sent.get('threadId'),
        "to":          to,
        "subject":     subject,
        "attachments": attachment_names,
        "message":     summary,
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc()
        }))
        sys.exit(1)
