#!/usr/bin/env python3
"""
Gmail Skill — Inoltra Email
Inoltra un messaggio Gmail a nuovi destinatari.
"""

import sys
import json
import os

sys.path.insert(0, os.path.dirname(__file__))
import gmail_auth


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    email_id           = data.get('email_id', '').strip()
    to                 = data.get('to', '').strip()
    additional_message = data.get('message', '').strip()
    attachments        = data.get('attachments', None)

    if not email_id:
        raise ValueError("Il campo 'email_id' è obbligatorio.")
    if not to:
        raise ValueError("Il campo 'to' (destinatario) è obbligatorio.")
    if attachments is not None and not isinstance(attachments, list):
        raise ValueError("Il campo 'attachments' deve essere una lista di path assoluti.")

    # Autenticazione
    service = gmail_auth.get_gmail_service(_config)
    sender  = gmail_auth.get_sender_address(_config, service)

    # Recupera il messaggio originale completo
    orig = service.users().messages().get(
        userId = 'me',
        id     = email_id,
        format = 'full'
    ).execute()

    headers = orig.get('payload', {}).get('headers', [])

    orig_from    = gmail_auth.get_header(headers, 'From')
    orig_to      = gmail_auth.get_header(headers, 'To')
    orig_date    = gmail_auth.get_header(headers, 'Date')
    orig_subject = gmail_auth.get_header(headers, 'Subject')

    # Decodifica corpo originale
    orig_body = gmail_auth.decode_body(orig.get('payload', {}))
    orig_text = orig_body['text'] or orig_body['html'] or '(nessun contenuto)'

    # Oggetto con Fwd:
    fwd_subject = orig_subject
    if not fwd_subject.lower().startswith('fwd:') and not fwd_subject.lower().startswith('i:'):
        fwd_subject = f"Fwd: {orig_subject}"

    # Compone il corpo con intestazione di inoltro
    fwd_header = (
        "---------- Messaggio inoltrato ----------\n"
        f"Da: {orig_from}\n"
        f"Data: {orig_date}\n"
        f"Oggetto: {orig_subject}\n"
        f"A: {orig_to}\n"
        "----------------------------------------\n\n"
    )

    if additional_message:
        body = additional_message + "\n\n" + fwd_header + orig_text
    else:
        body = fwd_header + orig_text

    # Costruisce il messaggio (senza thread_id — l'inoltro apre un nuovo thread)
    message = gmail_auth.build_raw_message(
        sender      = sender,
        to          = to,
        subject     = fwd_subject,
        body        = body,
        attachments = attachments,
    )

    # Invia
    sent = service.users().messages().send(userId='me', body=message).execute()

    attachment_names = [os.path.basename(p) for p in attachments] if attachments else []
    summary = f"✅ Email inoltrata a '{to}' con oggetto '{fwd_subject}'."
    if attachment_names:
        summary += f" Allegati aggiuntivi: {', '.join(attachment_names)}."

    print(json.dumps({
        "success":     True,
        "message_id":  sent.get('id'),
        "thread_id":   sent.get('threadId'),
        "to":          to,
        "subject":     fwd_subject,
        "original_id": email_id,
        "attachments": attachment_names,
        "message":     summary,
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc()
        }))
        sys.exit(1)
