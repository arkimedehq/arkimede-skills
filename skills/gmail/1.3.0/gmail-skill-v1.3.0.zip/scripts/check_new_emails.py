#!/usr/bin/env python3
"""
Gmail Skill — Controlla Nuove Email
Verifica se sono arrivate nuove email nelle ultime N minuti.
Funziona come sistema di polling: chiamare periodicamente per monitorare la posta in arrivo.
"""

import sys
import json
import os
import time

sys.path.insert(0, os.path.dirname(__file__))
import gmail_auth


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    since_minutes = int(data.get('since_minutes', 30))
    max_results   = min(int(data.get('max_results', 20)), 50)
    unread_only   = data.get('unread_only', True)

    # Calcola il timestamp Unix per il limite temporale
    now_ts    = int(time.time())
    since_ts  = now_ts - (since_minutes * 60)

    # Autenticazione
    service = gmail_auth.get_gmail_service(_config)

    # Query Gmail: email più recenti di X minuti fa
    # Gmail supporta 'after:{epoch}' per filtrare per data
    parts = [f'after:{since_ts}']
    if unread_only:
        parts.append('is:unread')
    query = ' '.join(parts)

    list_response = service.users().messages().list(
        userId     = 'me',
        maxResults = max_results,
        labelIds   = ['INBOX'],
        q          = query
    ).execute()

    messages_meta = list_response.get('messages', [])
    total         = list_response.get('resultSizeEstimate', 0)

    if not messages_meta:
        filter_desc = "non lette " if unread_only else ""
        print(json.dumps({
            "success":       True,
            "new_count":     0,
            "emails":        [],
            "since_minutes": since_minutes,
            "unread_only":   unread_only,
            "checked_at":    time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(now_ts)),
            "message":       (
                f"Nessuna email {filter_desc}arrivata negli ultimi {since_minutes} minuti."
            )
        }))
        return

    # Recupera dettagli per ogni messaggio
    emails = []
    for m in messages_meta:
        msg = service.users().messages().get(
            userId          = 'me',
            id              = m['id'],
            format          = 'metadata',
            metadataHeaders = ['Subject', 'From', 'To', 'Date']
        ).execute()
        emails.append(gmail_auth.parse_email_summary(msg))

    # Ordina per data interna Gmail (internalDate) — più recente prima
    # Gmail API restituisce già in ordine decrescente

    unread_count = sum(1 for e in emails if e['unread'])
    filter_desc  = "non lette " if unread_only else ""
    checked_at   = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(now_ts))

    msg_text = (
        f"📬 {len(emails)} nuova/e email {filter_desc}"
        f"negli ultimi {since_minutes} minuti"
        + (f" ({unread_count} non lette)" if not unread_only and unread_count > 0 else "")
        + f". Verificato alle {checked_at}."
    )

    print(json.dumps({
        "success":       True,
        "new_count":     len(emails),
        "unread_count":  unread_count,
        "since_minutes": since_minutes,
        "unread_only":   unread_only,
        "checked_at":    checked_at,
        "emails":        emails,
        "message":       msg_text
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc()
        }))
        sys.exit(1)
