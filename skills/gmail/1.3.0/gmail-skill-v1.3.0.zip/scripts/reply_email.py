#!/usr/bin/env python3
"""
Gmail Skill — Rispondi a un'Email
Risponde a un messaggio Gmail mantenendo il thread di conversazione.
"""

import sys
import json
import os

sys.path.insert(0, os.path.dirname(__file__))
import gmail_auth


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    email_id    = data.get('email_id', '').strip()
    body        = data.get('body', '').strip()
    reply_all   = data.get('reply_all', False)
    html        = data.get('html', False)
    attachments = data.get('attachments', None)

    if not email_id:
        raise ValueError("Il campo 'email_id' è obbligatorio.")
    if not body:
        raise ValueError("Il campo 'body' (corpo della risposta) è obbligatorio.")
    if attachments is not None and not isinstance(attachments, list):
        raise ValueError("Il campo 'attachments' deve essere una lista di path assoluti.")

    # Autenticazione
    service = gmail_auth.get_gmail_service(_config)
    sender  = gmail_auth.get_sender_address(_config, service)

    # Recupera il messaggio originale (formato metadata per gli header)
    orig = service.users().messages().get(
        userId = 'me',
        id     = email_id,
        format = 'metadata',
        metadataHeaders = ['From', 'To', 'Cc', 'Subject', 'Message-ID', 'References', 'Reply-To']
    ).execute()

    headers   = orig.get('payload', {}).get('headers', [])
    thread_id = orig.get('threadId', '')

    orig_from       = gmail_auth.get_header(headers, 'From')
    orig_to         = gmail_auth.get_header(headers, 'To')
    orig_cc         = gmail_auth.get_header(headers, 'Cc')
    orig_reply_to   = gmail_auth.get_header(headers, 'Reply-To')
    orig_subject    = gmail_auth.get_header(headers, 'Subject')
    orig_message_id = gmail_auth.get_header(headers, 'Message-ID')
    orig_references = gmail_auth.get_header(headers, 'References')

    # Destinatario della risposta
    # Priorità: Reply-To > From
    reply_to_addr = orig_reply_to if orig_reply_to else orig_from

    if reply_all:
        # Raccoglie tutti i destinatari originali (escluso se stessi)
        all_recipients = []
        for addr in [reply_to_addr, orig_to, orig_cc]:
            if addr:
                for a in addr.split(','):
                    a = a.strip()
                    if a and sender.lower() not in a.lower():
                        all_recipients.append(a)
        # Rimuovi duplicati preservando ordine
        seen = set()
        unique = []
        for a in all_recipients:
            key = a.lower()
            if key not in seen:
                seen.add(key)
                unique.append(a)
        final_to = ', '.join(unique) if unique else reply_to_addr
    else:
        final_to = reply_to_addr

    # Oggetto con Re:
    reply_subject = orig_subject
    if not reply_subject.lower().startswith('re:'):
        reply_subject = f"Re: {orig_subject}"

    # Costruzione headers threading
    refs = (orig_references + ' ' + orig_message_id).strip() if orig_references else orig_message_id

    # Costruisce il messaggio
    message = gmail_auth.build_raw_message(
        sender      = sender,
        to          = final_to,
        subject     = reply_subject,
        body        = body,
        html        = html,
        in_reply_to = orig_message_id,
        references  = refs,
        thread_id   = thread_id,
        attachments = attachments,
    )

    # Invia
    sent = service.users().messages().send(userId='me', body=message).execute()

    attachment_names = [os.path.basename(p) for p in attachments] if attachments else []
    summary = f"✅ Risposta inviata a '{final_to}' con oggetto '{reply_subject}'."
    if attachment_names:
        summary += f" Allegati: {', '.join(attachment_names)}."

    print(json.dumps({
        "success":     True,
        "message_id":  sent.get('id'),
        "thread_id":   sent.get('threadId'),
        "to":          final_to,
        "subject":     reply_subject,
        "reply_all":   reply_all,
        "attachments": attachment_names,
        "message":     summary,
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc()
        }))
        sys.exit(1)
