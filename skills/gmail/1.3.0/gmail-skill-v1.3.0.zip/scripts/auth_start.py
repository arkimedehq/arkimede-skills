#!/usr/bin/env python3
"""
Gmail Skill — Avvia autenticazione OAuth2
Genera l'URL di autorizzazione Google e guida l'utente nel processo di connessione.

Non richiede dipendenze esterne: usa solo la stdlib Python.
"""

import sys

# Questo script usa SOLO la stdlib Python.
# Rimuoviamo .deps dal path prima di qualsiasi import per evitare
# che dipendenze incompatibili (es. cffi compilato per una versione
# Python/OS diversa) vengano caricate accidentalmente.
sys.path = [p for p in sys.path if '.deps' not in p]

import json
import os
import urllib.parse


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    # client_id e client_secret: presi dall'input oppure dalla config già salvata
    client_id     = (data.get('client_id') or _config.get('GMAIL_CLIENT_ID', '')).strip()
    client_secret = (data.get('client_secret') or _config.get('GMAIL_CLIENT_SECRET', '')).strip()

    if not client_id:
        raise ValueError(
            "Per avviare l'autenticazione Gmail è necessario il Client ID del progetto Google Cloud.\n"
            "Come ottenerlo:\n"
            "1. Vai su console.cloud.google.com\n"
            "2. Crea un progetto → abilita Gmail API\n"
            "3. Credenziali → Crea ID client OAuth → Tipo: App desktop\n"
            "4. Copia Client ID e Client Secret e forniscili come input a questo script."
        )

    if not client_secret:
        raise ValueError(
            "È necessario anche il Client Secret del progetto Google Cloud.\n"
            "Lo trovi nella stessa pagina del Client ID su console.cloud.google.com."
        )

    # Costruisce l'URL di autorizzazione Google OAuth2
    # redirect_uri=http://localhost è sempre permesso da Google per le app di tipo 'Desktop'
    auth_url = "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode({
        'client_id':     client_id,
        'redirect_uri':  'http://localhost',
        'response_type': 'code',
        'scope':         'https://mail.google.com/',
        'access_type':   'offline',   # necessario per ricevere il refresh token
        'prompt':        'consent',   # forza la schermata di consenso → garantisce il refresh token
    })

    already_configured = bool(_config.get('GMAIL_CLIENT_ID', '').strip())

    result = {
        "success":  True,
        "auth_url": auth_url,
        "step":     "1/2",
        "message": (
            "🔐 **Passo 1 di 2 — Autorizza l'accesso a Gmail**\n\n"
            f"Apri questo link nel browser:\n\n"
            f"**{auth_url}**\n\n"
            "Accedi con il tuo account Gmail e concedi i permessi richiesti.\n\n"
            "Dopo aver autorizzato, Google ti reindirizzerà a una pagina "
            "`localhost` che mostrerà un **errore di connessione** — è normale. "
            "**Copia l'URL completo dalla barra degli indirizzi del browser** "
            "(inizia con `http://localhost?code=...`) e incollalo nella chat.\n\n"
            "Poi chiama `auth_complete` con quell'URL per completare la configurazione."
        ),
        "next_step": "Incolla nella chat l'URL che vedi nella barra del browser dopo l'autorizzazione.",
        "hint": (
            None if already_configured
            else f"Tieni a portata di mano anche il Client Secret: ti servirà per il passo 2."
        ),
    }

    # Rimuovi campi None dall'output
    result = {k: v for k, v in result.items() if v is not None}

    print(json.dumps(result))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc(),
        }))
        sys.exit(1)
