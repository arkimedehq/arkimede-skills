#!/usr/bin/env python3
"""
Modulo helper condiviso per l'autenticazione Gmail API.
Non viene eseguito direttamente — viene importato dagli altri script della skill.
"""

import os
import sys
import base64


def get_gmail_service(_config):
    """
    Crea e restituisce un servizio Gmail API autenticato via OAuth2 refresh token.
    Rilancia ValueError se le credenziali mancano o sono non valide.
    """
    from google.oauth2.credentials import Credentials
    from google.auth.transport.requests import Request
    from googleapiclient.discovery import build

    client_id     = _config.get('GMAIL_CLIENT_ID', '').strip()
    client_secret = _config.get('GMAIL_CLIENT_SECRET', '').strip()
    refresh_token = _config.get('GMAIL_REFRESH_TOKEN', '').strip()

    if not client_id or not client_secret or not refresh_token:
        raise ValueError(
            "Credenziali Gmail non configurate. "
            "Imposta GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET e GMAIL_REFRESH_TOKEN "
            "nelle impostazioni della skill (Impostazioni → Skills → gmail → Configura). "
            "Vedi il SKILL.md per la procedura di setup."
        )

    creds = Credentials(
        token=None,
        refresh_token=refresh_token,
        token_uri='https://oauth2.googleapis.com/token',
        client_id=client_id,
        client_secret=client_secret,
        scopes=['https://mail.google.com/']
    )

    # Esegue il refresh del token di accesso
    creds.refresh(Request())

    service = build('gmail', 'v1', credentials=creds, cache_discovery=False)
    return service


def get_sender_address(_config, service):
    """Restituisce l'indirizzo email configurato o lo recupera dal profilo Gmail."""
    email = _config.get('GMAIL_USER_EMAIL', '').strip()
    if not email:
        profile = service.users().getProfile(userId='me').execute()
        email = profile.get('emailAddress', 'me')
    return email


def get_header(headers, name):
    """Restituisce il valore di un header email (case-insensitive). Stringa vuota se assente."""
    for h in headers:
        if h['name'].lower() == name.lower():
            return h['value']
    return ''


def decode_body(payload):
    """
    Decodifica ricorsivamente il corpo di un messaggio Gmail dalla struttura payload.
    Restituisce dict con chiavi 'text' e 'html'.
    """
    result = {'text': '', 'html': ''}

    mime_type = payload.get('mimeType', '')

    if mime_type == 'text/plain':
        data = payload.get('body', {}).get('data', '')
        if data:
            result['text'] = base64.urlsafe_b64decode(data + '==').decode('utf-8', errors='replace')

    elif mime_type == 'text/html':
        data = payload.get('body', {}).get('data', '')
        if data:
            result['html'] = base64.urlsafe_b64decode(data + '==').decode('utf-8', errors='replace')

    elif 'parts' in payload:
        for part in payload['parts']:
            sub = decode_body(part)
            if sub['text']:
                result['text'] += sub['text']
            if sub['html']:
                result['html'] += sub['html']

    return result


def list_attachments(payload):
    """
    Raccoglie la lista degli allegati da un payload Gmail.
    Restituisce lista di dict con filename, mimeType, size, attachmentId.
    """
    attachments = []
    _collect_attachments(payload, attachments)
    return attachments


def _collect_attachments(payload, result):
    """Funzione ricorsiva di supporto per list_attachments."""
    filename  = payload.get('filename', '')
    mime_type = payload.get('mimeType', '')
    body      = payload.get('body', {})

    if filename and body.get('attachmentId'):
        result.append({
            'filename':      filename,
            'mime_type':     mime_type,
            'size':          body.get('size', 0),
            'attachment_id': body['attachmentId'],
        })

    for part in payload.get('parts', []):
        _collect_attachments(part, result)


def parse_email_summary(msg):
    """
    Estrae le informazioni principali da un oggetto messaggio Gmail (formato metadata).
    Restituisce dict con id, thread_id, subject, from, to, date, snippet, unread, has_attachments.
    """
    headers    = msg.get('payload', {}).get('headers', [])
    label_ids  = msg.get('labelIds', [])
    parts      = msg.get('payload', {}).get('parts', [])
    mime_type  = msg.get('payload', {}).get('mimeType', '')

    # Verifica allegati (almeno una parte non è testo/html puro)
    has_attachments = any(
        p.get('filename') for p in parts
    ) if parts else False

    return {
        'id':              msg['id'],
        'thread_id':       msg.get('threadId', ''),
        'subject':         get_header(headers, 'Subject') or '(nessun oggetto)',
        'from':            get_header(headers, 'From'),
        'to':              get_header(headers, 'To'),
        'date':            get_header(headers, 'Date'),
        'snippet':         msg.get('snippet', ''),
        'unread':          'UNREAD' in label_ids,
        'has_attachments': has_attachments,
        'labels':          label_ids,
    }


def build_raw_message(sender, to, subject, body, html=False, cc=None, bcc=None,
                      in_reply_to=None, references=None, thread_id=None,
                      attachments=None):
    """
    Costruisce un messaggio MIME base64url pronto per Gmail API.
    Restituisce dict con chiave 'raw' (e 'threadId' se fornito).

    attachments: lista di path assoluti a file locali da allegare (opzionale).
    """
    import mimetypes
    from email.mime.text        import MIMEText
    from email.mime.multipart   import MIMEMultipart
    from email.mime.base        import MIMEBase
    from email.mime.application import MIMEApplication
    from email                  import encoders

    has_attachments = bool(attachments)

    if has_attachments:
        # Struttura: mixed → (alternative → plain+html) + allegati
        msg = MIMEMultipart('mixed')
        body_part = MIMEMultipart('alternative')
        body_part.attach(MIMEText(body, 'plain', 'utf-8'))
        if html:
            body_part.attach(MIMEText(body, 'html', 'utf-8'))
        msg.attach(body_part)
    elif html:
        msg = MIMEMultipart('alternative')
        msg.attach(MIMEText(body, 'plain', 'utf-8'))
        msg.attach(MIMEText(body, 'html',  'utf-8'))
    else:
        msg = MIMEText(body, 'plain', 'utf-8')

    msg['From']    = sender
    msg['To']      = to if isinstance(to, str) else ', '.join(to)
    msg['Subject'] = subject

    if cc:
        msg['Cc']  = cc if isinstance(cc, str) else ', '.join(cc)
    if bcc:
        msg['Bcc'] = bcc if isinstance(bcc, str) else ', '.join(bcc)
    if in_reply_to:
        msg['In-Reply-To'] = in_reply_to
    if references:
        msg['References']  = references

    # Allegati dal filesystem condiviso
    if has_attachments:
        for file_path in attachments:
            if not os.path.isfile(file_path):
                raise FileNotFoundError(
                    f"Allegato non trovato: {file_path}. "
                    "Verifica che il path sia corretto e che il file sia accessibile dall'executor."
                )
            mime_type, _ = mimetypes.guess_type(file_path)
            if mime_type is None:
                mime_type = 'application/octet-stream'
            main_type, sub_type = mime_type.split('/', 1)
            filename = os.path.basename(file_path)

            with open(file_path, 'rb') as f:
                file_data = f.read()

            part = MIMEBase(main_type, sub_type)
            part.set_payload(file_data)
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', 'attachment', filename=filename)
            msg.attach(part)

    raw_bytes = base64.urlsafe_b64encode(msg.as_bytes()).decode('utf-8')
    result    = {'raw': raw_bytes}
    if thread_id:
        result['threadId'] = thread_id
    return result
