#!/usr/bin/env python3
"""
Gmail Skill — Completa autenticazione OAuth2

Riceve l'URL di redirect da Google (con il codice di autorizzazione),
scambia il codice con i token OAuth2 e li salva DIRETTAMENTE nel backend
tramite l'API interna dell'executor.

I token non vengono mai restituiti come output dello script:
l'AI (e la conversation history) non li vedrà mai.

Non richiede dipendenze esterne: usa solo la stdlib Python.
"""

import sys

# Questo script usa SOLO la stdlib Python.
# Rimuoviamo .deps dal path prima di qualsiasi import per evitare
# che dipendenze incompatibili (es. cffi compilato per una versione
# Python/OS diversa) vengano caricate accidentalmente.
sys.path = [p for p in sys.path if '.deps' not in p]

import json
import os
import urllib.parse
import urllib.request
import urllib.error


# ── Variabili iniettate dall'executor ─────────────────────────────────────────
SKILL_ID             = os.environ.get('SKILL_ID', '')
BACKEND_INTERNAL_URL = os.environ.get('BACKEND_INTERNAL_URL', 'http://localhost:3000').rstrip('/')
INTERNAL_TOKEN     = os.environ.get('INTERNAL_TOKEN', '')


def exchange_code(client_id: str, client_secret: str, code: str) -> dict:
    """Scambia il codice di autorizzazione con access_token e refresh_token."""
    payload = urllib.parse.urlencode({
        'code':          code,
        'client_id':     client_id,
        'client_secret': client_secret,
        'redirect_uri':  'http://localhost',
        'grant_type':    'authorization_code',
    }).encode('utf-8')

    req = urllib.request.Request(
        'https://oauth2.googleapis.com/token',
        data    = payload,
        headers = {'Content-Type': 'application/x-www-form-urlencoded'},
        method  = 'POST',
    )

    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')
        try:
            err = json.loads(body)
            raise ValueError(
                f"Errore Google OAuth: {err.get('error', 'unknown')} — "
                f"{err.get('error_description', body)}"
            )
        except json.JSONDecodeError:
            raise ValueError(f"Errore HTTP {e.code} da Google: {body}")


def get_user_email(access_token: str) -> str:
    """Recupera l'indirizzo email dell'account appena autorizzato."""
    req = urllib.request.Request(
        'https://www.googleapis.com/oauth2/v2/userinfo',
        headers = {'Authorization': f'Bearer {access_token}'},
    )
    try:
        with urllib.request.urlopen(req) as resp:
            info = json.loads(resp.read().decode('utf-8'))
            return info.get('email', '')
    except Exception:
        return ''


def save_config_via_internal_api(config: dict) -> None:
    """
    Salva le config vars direttamente nel backend tramite l'endpoint interno.

    I valori NON transitano attraverso l'output dello script (e quindi non
    appaiono nella chat history): vengono scritti direttamente nel DB.

    Lancia ValueError se la chiamata fallisce.
    """
    if not INTERNAL_TOKEN:
        raise ValueError(
            "INTERNAL_TOKEN non configurata nell'executor.\n"
            "Aggiungi al file .env dell'executor:\n"
            "  INTERNAL_TOKEN=<secret>\n"
            "e al file .env del backend lo stesso valore.\n"
            "Genera la chiave con: openssl rand -hex 32"
        )

    if not SKILL_ID:
        raise ValueError(
            "SKILL_ID non disponibile nell'environment.\n"
            "Questo è un errore interno dell'executor: aggiorna la versione dell'executor."
        )

    url     = f"{BACKEND_INTERNAL_URL}/internal/skills/{SKILL_ID}/save-config"
    body    = json.dumps({'config': config}).encode('utf-8')
    request = urllib.request.Request(
        url,
        data    = body,
        headers = {
            'Content-Type':       'application/json',
            'x-internal-token': INTERNAL_TOKEN,
        },
        method  = 'POST',
    )

    try:
        with urllib.request.urlopen(request) as resp:
            result = json.loads(resp.read().decode('utf-8'))
            if not result.get('ok'):
                raise ValueError(f"Il backend ha risposto con ok=false: {result}")
    except urllib.error.HTTPError as e:
        body_resp = e.read().decode('utf-8', errors='replace')
        try:
            err_obj = json.loads(body_resp)
            msg = err_obj.get('message', body_resp)
        except Exception:
            msg = body_resp
        raise ValueError(f"Errore API interna (HTTP {e.code}): {msg}")
    except urllib.error.URLError as e:
        raise ValueError(
            f"Impossibile raggiungere il backend all'indirizzo {BACKEND_INTERNAL_URL}.\n"
            f"Dettaglio: {e.reason}\n"
            "Verifica che il backend sia in esecuzione e che BACKEND_INTERNAL_URL sia corretto."
        )


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    # redirect_url: l'URL copiato dalla barra del browser dopo l'autorizzazione
    redirect_url  = data.get('redirect_url', '').strip()

    # client_id / client_secret: presi dall'input o dalla config già salvata
    client_id     = (data.get('client_id')     or _config.get('GMAIL_CLIENT_ID',     '')).strip()
    client_secret = (data.get('client_secret') or _config.get('GMAIL_CLIENT_SECRET', '')).strip()

    # ── Validazione input ──────────────────────────────────────────────────────

    if not redirect_url:
        raise ValueError(
            "Il campo 'redirect_url' è obbligatorio.\n"
            "Incolla l'URL completo che vedi nella barra del browser dopo aver "
            "autorizzato l'accesso Gmail (inizia con 'http://localhost?code=...')."
        )

    if not client_id or not client_secret:
        raise ValueError(
            "Client ID e Client Secret sono obbligatori.\n"
            "Se non li hai ancora configurati, forniscili come input "
            "oppure impostali in Impostazioni → Skills → gmail → Configura."
        )

    # ── Estrazione codice dall'URL ─────────────────────────────────────────────

    try:
        parsed = urllib.parse.urlparse(redirect_url)
        params = urllib.parse.parse_qs(parsed.query)
    except Exception:
        raise ValueError(f"URL non valido: '{redirect_url}'")

    # Gestione errore esplicito da Google (es. accesso negato)
    if 'error' in params:
        error_code = params['error'][0]
        error_map  = {
            'access_denied': "Hai rifiutato l'accesso. Riprova e accetta i permessi Gmail.",
        }
        raise ValueError(error_map.get(error_code, f"Google ha restituito un errore: {error_code}"))

    code = params.get('code', [None])[0]
    if not code:
        raise ValueError(
            "Codice di autorizzazione non trovato nell'URL.\n"
            "Assicurati di aver copiato l'URL COMPLETO dalla barra del browser, "
            "inclusi tutti i parametri dopo il '?'."
        )

    # ── Scambio codice → token ─────────────────────────────────────────────────

    tokens = exchange_code(client_id, client_secret, code)

    refresh_token = tokens.get('refresh_token')
    access_token  = tokens.get('access_token', '')

    if not refresh_token:
        raise ValueError(
            "Google non ha restituito il refresh token.\n"
            "Cause possibili:\n"
            "  • L'account aveva già autorizzato questa app → revoca l'accesso su "
            "    myaccount.google.com/permissions e riprova\n"
            "  • L'URL di autorizzazione non includeva 'prompt=consent' → usa auth_start per generarlo correttamente"
        )

    # ── Email dell'account autorizzato ─────────────────────────────────────────

    email = get_user_email(access_token) if access_token else ''

    # ── Salvataggio diretto nel backend (i token NON appaiono in chat) ─────────
    #
    # I valori vengono scritti direttamente nel DB tramite l'API interna
    # dell'executor. L'output di questo script non contiene credenziali.

    save_config_via_internal_api({
        'GMAIL_CLIENT_ID':     client_id,
        'GMAIL_CLIENT_SECRET': client_secret,
        'GMAIL_REFRESH_TOKEN': refresh_token,
        'GMAIL_USER_EMAIL':    email,
    })

    # ── Output (nessuna credenziale) ───────────────────────────────────────────

    print(json.dumps({
        "success": True,
        "step":    "2/2",
        "email":   email,
        "message": (
            f"✅ **Gmail connessa con successo!**\n\n"
            f"Account autorizzato: **{email or '(email non disponibile)'}**\n\n"
            "La configurazione è stata salvata in modo sicuro. "
            "Puoi iniziare subito a leggere e inviare email. 🚀"
        ),
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc(),
        }))
        sys.exit(1)
