#!/usr/bin/env python3
"""
daemon_emails.py — Gmail Daemon: monitora nuove email in tempo reale.

Protocollo:
  - Legge la configurazione da stdin JSON (campo _config) all'avvio
  - Legge le variabili d'ambiente: PUSH_URL, DAEMON_ID, SKILL_ID, USER_ID
  - Fa polling via Gmail History API ogni POLL_INTERVAL secondi
  - Invia eventi al backend via POST su PUSH_URL

Evento emesso (event_type: 'new_emails'):
  {
    "skill_id":   "...",
    "user_id":    "...",
    "daemon_id":  "...",
    "event_type": "new_emails",
    "payload": {
      "count":  2,
      "emails": [
        {
          "id":      "18f4a2b3c4d5e6f7",
          "subject": "...",
          "from":    "...",
          "date":    "...",
          "snippet": "..."
        }
      ]
    }
  }

Ciclo di vita:
  1. Leggi config da stdin
  2. Autenticati con Gmail API
  3. Ottieni l'historyId corrente (baseline)
  4. Loop: ogni POLL_INTERVAL secondi chiama history.list
  5. Per ogni nuova email: fetch metadata e invia evento a PUSH_URL
  6. Aggiorna historyId
  7. In caso di errore critico: esci con exit code 1 (il backend rileverà daemon_exit)
"""

import sys
import json
import os
import time
import base64
import logging
import signal

# ─── Logging (su stderr, non inquina stdout) ──────────────────────────────────

logging.basicConfig(
    stream=sys.stderr,
    level=logging.INFO,
    format='[daemon_emails] %(asctime)s %(levelname)s %(message)s',
    datefmt='%H:%M:%S',
)
log = logging.getLogger('daemon_emails')

# ─── Env vars iniettati dall'executor ─────────────────────────────────────────

PUSH_URL     = os.environ.get('PUSH_URL', '')
DAEMON_ID    = os.environ.get('DAEMON_ID', '')
SKILL_ID     = os.environ.get('SKILL_ID', '')
USER_ID      = os.environ.get('USER_ID', '')
INTERNAL_KEY = os.environ.get('INTERNAL_TOKEN', '')

# ─── Graceful shutdown ────────────────────────────────────────────────────────

_running = True

def _handle_signal(sig, frame):
    global _running
    log.info(f'Ricevuto segnale {sig} — shutdown in corso...')
    _running = False

signal.signal(signal.SIGTERM, _handle_signal)
signal.signal(signal.SIGINT, _handle_signal)

# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    # Leggi configurazione da stdin (protocollo standard skill)
    try:
        raw = sys.stdin.read()
        data = json.loads(raw) if raw.strip() else {}
    except Exception as e:
        log.error(f'Errore lettura stdin: {e}')
        sys.exit(1)

    cfg = data.get('_config', {})

    client_id     = cfg.get('GMAIL_CLIENT_ID', '')
    client_secret = cfg.get('GMAIL_CLIENT_SECRET', '')
    refresh_token = cfg.get('GMAIL_REFRESH_TOKEN', '')
    user_email    = cfg.get('GMAIL_USER_EMAIL', 'me')

    # GMAIL_POLL_INTERVAL: prima da _config, poi da env var, poi default 30s
    poll_interval = int(cfg.get('GMAIL_POLL_INTERVAL') or os.environ.get('GMAIL_POLL_INTERVAL') or 30)

    if not all([client_id, client_secret, refresh_token]):
        log.error('Configurazione Gmail incompleta (GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET, GMAIL_REFRESH_TOKEN)')
        sys.exit(1)

    if not PUSH_URL:
        log.error('PUSH_URL non configurato')
        sys.exit(1)

    log.info(f'Gmail daemon avviato per {user_email} (poll ogni {poll_interval}s)')

    # Import dipendenze Google (disponibili dopo installazione)
    try:
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        from googleapiclient.errors import HttpError
    except ImportError as e:
        log.error(f'Dipendenze Google non installate: {e}')
        sys.exit(1)

    # Costruisci credenziali OAuth2
    creds = Credentials(
        token=None,
        refresh_token=refresh_token,
        token_uri='https://oauth2.googleapis.com/token',
        client_id=client_id,
        client_secret=client_secret,
        scopes=['https://mail.google.com/'],
    )

    # Costruisci il service Gmail
    try:
        service = build('gmail', 'v1', credentials=creds, cache_discovery=False)
    except Exception as e:
        log.error(f'Errore costruzione Gmail service: {e}')
        sys.exit(1)

    # ── Ottieni historyId baseline ─────────────────────────────────────────────
    try:
        profile = service.users().getProfile(userId='me').execute()
        history_id = str(profile['historyId'])
        log.info(f'historyId baseline: {history_id}')
    except Exception as e:
        log.error(f'Errore getProfile: {e}')
        sys.exit(1)

    # ── Polling loop ──────────────────────────────────────────────────────────
    log.info('Loop di monitoraggio avviato')

    while _running:
        time.sleep(poll_interval)

        if not _running:
            break

        try:
            # Chiede solo le modifiche dall'ultimo historyId noto
            history_resp = service.users().history().list(
                userId='me',
                startHistoryId=history_id,
                historyTypes=['messageAdded'],
                labelId='INBOX',
            ).execute()

            new_history_id = history_resp.get('historyId', history_id)
            histories = history_resp.get('history', [])

            if not histories:
                history_id = new_history_id
                continue

            # Raccogli i nuovi message_id (dedup)
            new_msg_ids = set()
            for h in histories:
                for added in h.get('messagesAdded', []):
                    msg = added.get('message', {})
                    # Filtra: solo messaggi INBOX non SENT
                    labels = set(msg.get('labelIds', []))
                    if 'INBOX' in labels and 'SENT' not in labels:
                        new_msg_ids.add(msg['id'])

            if not new_msg_ids:
                history_id = new_history_id
                continue

            # Fetch metadata per ogni nuovo messaggio
            emails = []
            for msg_id in list(new_msg_ids)[:20]:  # max 20 per evento
                try:
                    msg = service.users().messages().get(
                        userId='me',
                        id=msg_id,
                        format='metadata',
                        metadataHeaders=['Subject', 'From', 'Date'],
                    ).execute()

                    headers = {h['name']: h['value'] for h in msg.get('payload', {}).get('headers', [])}
                    emails.append({
                        'id':      msg_id,
                        'subject': headers.get('Subject', '(nessun oggetto)'),
                        'from':    headers.get('From', ''),
                        'date':    headers.get('Date', ''),
                        'snippet': msg.get('snippet', ''),
                    })
                except Exception as e:
                    log.warning(f'Errore fetch messaggio {msg_id}: {e}')

            if emails:
                log.info(f'{len(emails)} nuova/e email rilevata/e')
                push_event('new_emails', {
                    'count':  len(emails),
                    'emails': emails,
                })

            history_id = new_history_id

        except Exception as e:
            log.error(f'Errore durante polling Gmail: {e}')
            # Non uscire per errori transitori (es. rate limit, rete)
            # L'uscita avviene solo per errori critici (auth, ecc.)
            if 'invalid_grant' in str(e).lower() or 'unauthorized' in str(e).lower():
                log.error('Errore autenticazione — daemon in uscita')
                push_event('auth_error', {'error': str(e)})
                sys.exit(1)

    log.info('Daemon Gmail terminato')


def push_event(event_type: str, payload: dict):
    """Invia un evento al backend tramite PUSH_URL."""
    import urllib.request

    body = json.dumps({
        'skill_id':   SKILL_ID,
        'user_id':    USER_ID,
        'daemon_id':  DAEMON_ID,
        'event_type': event_type,
        'payload':    payload,
    }).encode('utf-8')

    req = urllib.request.Request(
        PUSH_URL,
        data=body,
        headers={
            'Content-Type':       'application/json',
            'x-internal-token': INTERNAL_KEY,
        },
        method='POST',
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            log.debug(f'Evento {event_type} inviato (HTTP {resp.status})')
    except Exception as e:
        log.warning(f'Errore invio evento {event_type}: {e}')


if __name__ == '__main__':
    main()
