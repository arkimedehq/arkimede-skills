#!/usr/bin/env python3
"""
Gmail Skill — Elenca Email
Recupera la lista email da una cartella Gmail con filtri opzionali.
"""

import sys
import json
import os

sys.path.insert(0, os.path.dirname(__file__))
import gmail_auth


# Mappa nomi cartella → label Gmail
FOLDER_MAP = {
    'INBOX':  'INBOX',
    'SENT':   'SENT',
    'DRAFT':  'DRAFT',
    'SPAM':   'SPAM',
    'TRASH':  'TRASH',
    'INBOX':  'INBOX',
    'INVIATI': 'SENT',
    'BOZZE':  'DRAFT',
    'CESTINO': 'TRASH',
}


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    # Parametri input
    folder      = data.get('folder', 'INBOX').upper()
    max_results = min(int(data.get('max_results', 10)), 50)
    query       = data.get('query', '')
    unread_only = data.get('unread_only', False)

    # Costruisce la query Gmail
    gmail_label = FOLDER_MAP.get(folder, 'INBOX')
    parts = []
    if query:
        parts.append(query)
    if unread_only:
        parts.append('is:unread')
    final_query = ' '.join(parts) if parts else ''

    # Autenticazione
    service = gmail_auth.get_gmail_service(_config)

    # Recupera lista ID messaggi
    params = {
        'userId':     'me',
        'maxResults': max_results,
        'labelIds':   [gmail_label],
    }
    if final_query:
        params['q'] = final_query

    list_response = service.users().messages().list(**params).execute()
    messages_meta = list_response.get('messages', [])

    if not messages_meta:
        label_name = folder if folder != 'INBOX' else 'posta in arrivo'
        query_desc = f" per '{final_query}'" if final_query else ''
        print(json.dumps({
            "success":    True,
            "count":      0,
            "emails":     [],
            "folder":     folder,
            "query":      final_query,
            "message":    f"Nessuna email trovata in {label_name}{query_desc}."
        }))
        return

    # Recupera dettagli (headers) per ogni messaggio in batch
    emails = []
    for m in messages_meta:
        msg = service.users().messages().get(
            userId  = 'me',
            id      = m['id'],
            format  = 'metadata',
            metadataHeaders = ['Subject', 'From', 'To', 'Date']
        ).execute()
        emails.append(gmail_auth.parse_email_summary(msg))

    unread_count = sum(1 for e in emails if e['unread'])
    label_name   = folder if folder != 'INBOX' else 'posta in arrivo'

    print(json.dumps({
        "success":      True,
        "count":        len(emails),
        "unread_count": unread_count,
        "folder":       folder,
        "query":        final_query,
        "emails":       emails,
        "message":      (
            f"Trovate {len(emails)} email in {label_name}"
            + (f" ({unread_count} non lette)" if unread_count > 0 else "")
            + (f" — query: '{final_query}'" if final_query else "")
            + "."
        )
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            "success": False,
            "error":   str(e),
            "stack":   traceback.format_exc()
        }))
        sys.exit(1)
