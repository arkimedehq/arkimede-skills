# 📧 Gmail — Gestione Email Completa

Integrazione con Gmail tramite API ufficiale Google. Permette di inviare, leggere,
rispondere, inoltrare email e verificare l'arrivo di nuovi messaggi.
Include un **daemon di monitoraggio in tempo reale** (watch) che notifica
automaticamente ogni nuova email nell'INBOX.

---

## ⚙️ Configurazione

Hai **due modi** per configurare questa skill:

### 🤖 Modalità guidata (consigliata) — via chat

Di' semplicemente all'assistente:

> **"Connetti Gmail"** oppure **"Configura la skill Gmail"**

L'assistente ti guiderà passo-passo: genererà un link da aprire nel browser,
autorizzerai l'accesso al tuo account Gmail e incollerai l'URL risultante in chat.

La configurazione viene salvata **automaticamente e in modo sicuro** direttamente
nel backend — i token OAuth non compaiono mai nella cronologia della chat.
Nessun copia-incolla di credenziali richiesto.

### ✏️ Modalità manuale — compilazione diretta

Se preferisci configurare i campi tu stesso, vai su
**Impostazioni → Skills → gmail → Configura** e compila:

| Variabile | Dove trovarla |
|-----------|--------------|
| `GMAIL_CLIENT_ID` | Google Cloud Console → Credenziali → ID client OAuth |
| `GMAIL_CLIENT_SECRET` | Google Cloud Console → Credenziali → ID client OAuth |
| `GMAIL_REFRESH_TOKEN` | [OAuth2 Playground](https://developers.google.com/oauthplayground) (vedi sotto) |
| `GMAIL_USER_EMAIL` | Il tuo indirizzo Gmail (es. `mario@gmail.com`) |

<details>
<summary>📖 Come ottenere le credenziali manualmente</summary>

**1. Crea il progetto Google Cloud**
1. Vai su [console.cloud.google.com](https://console.cloud.google.com)
2. Nuovo progetto → dai un nome (es. `Arkimede Gmail`)
3. **API e servizi → Libreria** → cerca **Gmail API** → Abilita
4. **API e servizi → Credenziali** → **Crea ID client OAuth** → tipo **App desktop**
5. Copia **Client ID** e **Client Secret**

**2. Aggiungi te stesso come utente di test**
1. **API e servizi → Schermata consenso OAuth**
2. Sezione **"Utenti di test"** → aggiungi il tuo indirizzo Gmail

**3. Ottieni il Refresh Token**
1. Vai su [OAuth2 Playground](https://developers.google.com/oauthplayground)
2. ⚙️ → spunta *"Use your own OAuth credentials"* → inserisci Client ID e Secret
3. Seleziona scope: `https://mail.google.com/`
4. **Authorize APIs** → accedi con Gmail → **Exchange authorization code for tokens**
5. Copia il **Refresh token**

</details>

---

## ⏱️ Durata del token

| Stato app Google | Durata refresh token |
|-----------------|---------------------|
| **Testing** (default) | 7 giorni — poi va riconnessa |
| **Produzione** | Illimitata (scade solo dopo 6 mesi di inattività) |

Per passare in produzione: **Schermata consenso OAuth → Pubblica app**.

Per riconnettere un token scaduto, di' semplicemente **"Riconnetti Gmail"** in chat.

---

## ✅ Funzionalità disponibili

| Azione | Come chiederla |
|--------|----------------|
| Connetti / riconfigura | `"Connetti Gmail"`, `"Configura Gmail"` |
| Invia email | `"Invia email a X"`, `"Manda un messaggio a..."` |
| Invia email con allegato | `"Invia a X allegando il file Y"` |
| Mostra posta | `"Mostra le email"`, `"Ho email?"`, `"Controlla la posta"` |
| Leggi messaggio | `"Leggi l'email di X"`, `"Apri il messaggio..."` |
| Rispondi | `"Rispondi a X"`, `"Manda una risposta a..."` |
| Rispondi con allegato | `"Rispondi allegando il report"` |
| Inoltra | `"Inoltra a X"`, `"Gira questa email a..."` |
| Inoltra con allegato | `"Inoltra a X e allega anche il PDF"` |
| Nuove email (manuale) | `"Ho ricevuto qualcosa?"`, `"Ci sono email nuove?"` |
| **Monitoraggio automatico** | Avvia il daemon — vedi sezione sotto |

---

## 🔔 Monitoraggio in tempo reale (Daemon / Watch)

Il daemon `daemon_emails.py` gira in background e invia un **evento push**
ogni volta che arriva una nuova email nell'INBOX — senza bisogno di interrogare
manualmente la casella.

### Come funziona

Il daemon usa la **Gmail History API**: a ogni ciclo scarica solo le modifiche
dall'ultimo controllo, senza riscaricare l'intera posta.

L'intervallo di polling è configurabile tramite la variabile `GMAIL_POLL_INTERVAL`
(impostabile in **Settings → Skills → Gmail → Configura**, default: **30 secondi**).
Valori consigliati:
- `15` — più reattivo, più chiamate API
- `30` — bilanciato (default)
- `120` — meno chiamate API, meno reattivo

### Evento emesso

Quando arrivano nuove email il daemon invia un evento `new_emails` con:
- il numero di email arrivate
- per ognuna: id, oggetto, mittente, data, anteprima

Come vengono presentati questi eventi dipende dall'applicazione che ospita la skill.

### Errori e riconnessione

| Evento emesso | Causa | Soluzione |
|---------------|-------|-----------|
| `auth_error` | Token OAuth scaduto o revocato | Di' `"Riconnetti Gmail"` in chat, poi riavvia il daemon |
| `daemon_exit` | Errore critico non recuperabile | Controlla i log del daemon e riavvia |

> **Nota:** L'app Google in modalità *Testing* genera token che scadono dopo **7 giorni**.
> Se usi il daemon in modo continuativo, passa l'app in modalità *Produzione* su
> Google Cloud Console → Schermata consenso OAuth → Pubblica app.

---

## Dipendenze

- `google-api-python-client>=2.100`
- `google-auth>=2.20`
- `google-auth-httplib2>=0.2`
- `httplib2>=0.22`

## Versione

`1.3.0` — maggio 2026 · Licenza MIT · Autore: info@rstonline.it  
_Novità v1.3.0: config var `GMAIL_POLL_INTERVAL` per personalizzare l'intervallo di polling del daemon (default: 30s); il valore viene letto prima da `_config`, poi dalla variabile d'ambiente._  
_Novità v1.2.0: supporto allegati in uscita su `send_email`, `reply_email`, `forward_email` (path assoluti, MIME type auto-rilevato)._  
_Novità v1.1.0: daemon di monitoraggio real-time (watch via Gmail History API), notifiche persistenti nel DB._

## Network

Questa skill effettua chiamate verso domini esterni. Sono dichiarati in `skill.yaml` (campo `network:`) e visibili all'admin in fase di review; con l'overlay **egress** i domini non elencati sono bloccati a livello di rete.

| Dominio | Uso |
|---|---|
| `accounts.google.com` | OAuth2 — pagina di autorizzazione |
| `oauth2.googleapis.com` | OAuth2 — scambio e refresh dei token |
| `www.googleapis.com` | Gmail API (send/list/read/reply/forward/history) |

> OAuth2 Google (autorizzazione, scambio/refresh token) e Gmail API per inviare, elencare, leggere, rispondere e inoltrare email.
