---
name: gmail
description: |
  Integrazione completa con Gmail. Permette di inviare email, elencare la posta in arrivo o altre cartelle, leggere singole email per esteso, rispondere, inoltrare messaggi e verificare se sono arrivate nuove email. Include un daemon di monitoraggio real-time (watch) che notifica istantaneamente l'arrivo di nuove email nell'INBOX tramite push notification al backend, senza la necessità di interrogare manualmente. Usa l'API Gmail ufficiale di Google via OAuth2.
version: 1.3.0
author: info@rstonline.it
license: MIT
runtime:
  dependencies:
    python:
      - google-api-python-client>=2.100
      - google-auth>=2.20
      - google-auth-httplib2>=0.2
      - httplib2>=0.22
  network:
    - accounts.google.com
    - oauth2.googleapis.com
    - www.googleapis.com
  config:
    - key: GMAIL_CLIENT_ID
      description: Client ID dell'app OAuth2 Google Cloud (Settings → Skills → Gmail → Configura)
      required: true
      secret: true
    - key: GMAIL_CLIENT_SECRET
      description: Client Secret dell'app OAuth2 Google Cloud
      required: true
      secret: true
    - key: GMAIL_REFRESH_TOKEN
      description: Refresh Token OAuth2 ottenuto al primo accesso (vedi SKILL.md → Setup)
      required: true
      secret: true
    - key: GMAIL_USER_EMAIL
      description: Indirizzo email Gmail dell'account (es. utente@gmail.com)
      required: true
      secret: false
    - key: GMAIL_POLL_INTERVAL
      description: 'Intervallo di polling del daemon in secondi (default: 30). Valori consigliati: 15 (più reattivo) – 120 (meno chiamate API).'
      required: false
      secret: false
  scripts:
    - filename: scripts/auth_start.py
      language: python
      description: |
        AVVIA il processo di autenticazione OAuth2 Gmail: genera il link di autorizzazione Google da aprire nel browser. Usare ESCLUSIVAMENTE quando l'utente chiede di connettere Gmail, configurare la skill per la prima volta, o riconnettere un account scaduto (token revocato/scaduto). Restituisce un URL cliccabile. NON usare per inviare, leggere o elencare email.
      input_schema:
        type: object
        properties:
          client_id:
            type: string
            description: Client ID OAuth2 Google Cloud (opzionale se già in config)
          client_secret:
            type: string
            description: Client Secret OAuth2 Google Cloud (opzionale se già in config)
    - filename: scripts/auth_complete.py
      language: python
      description: |
        COMPLETA l'autenticazione OAuth2 Gmail: riceve l'URL di reindirizzamento dal browser, scambia il codice con i token e salva la configurazione. Usare ESCLUSIVAMENTE subito dopo auth_start, quando l'utente incolla l'URL dalla barra del browser. NON usare per inviare, leggere o elencare email.
      input_schema:
        type: object
        required:
          - redirect_url
        properties:
          redirect_url:
            type: string
            description: URL completo copiato dalla barra del browser dopo l'autorizzazione (inizia con http://localhost?code=...)
          client_id:
            type: string
            description: Client ID OAuth2 (opzionale se già in config)
          client_secret:
            type: string
            description: Client Secret OAuth2 (opzionale se già in config)
    - filename: scripts/send_email.py
      language: python
      description: |
        INVIA (componi, spedisci, manda, scrivi) una nuova email in uscita via Gmail. Usare ESCLUSIVAMENTE quando l'utente vuole inviare/mandare/spedire/scrivere un messaggio email a uno o più destinatari, con o senza allegati. Supporta: destinatari multipli, CC, BCC, corpo HTML o testo puro, allegati da path assoluti (es. PDF generati da skill_pdf_generator_html_generate_pdf_js). NON usare per leggere, elencare, cercare, rispondere o controllare email ricevute.
      input_schema:
        type: object
        required:
          - to
          - subject
          - body
        properties:
          to:
            type: string
            description: Destinatario o lista destinatari separati da virgola (es. 'mario@example.com, luigi@example.com')
          subject:
            type: string
            description: Oggetto dell'email
          body:
            type: string
            description: Corpo dell'email (testo puro oppure HTML se html=true)
          cc:
            type: string
            description: CC separati da virgola (opzionale)
          bcc:
            type: string
            description: BCC separati da virgola (opzionale)
          html:
            type: boolean
            description: 'Se true, il corpo viene inviato come HTML (default: false)'
          attachments:
            type: array
            items:
              type: string
            description: |
              Lista di path assoluti ai file da allegare (opzionale). Usare i path restituiti da altre skill che generano file (es. export CSV, report PDF, ecc.). Il tipo MIME viene rilevato automaticamente dall'estensione del file. Esempio: ["/shared/output/report.pdf", "/shared/output/dati.csv"]
    - filename: scripts/list_emails.py
      language: python
      description: |
        ELENCA (mostra, recupera, visualizza, sfoglia) le email presenti in una cartella Gmail. Restituisce mittente, oggetto, data e ID di ogni messaggio. Usare ESCLUSIVAMENTE quando l'utente vuole vedere/mostrare/elencare/controllare la posta ricevuta o inviata. Gli ID restituiti servono per leggere, rispondere o inoltrare messaggi specifici. NON usare per inviare, comporre, mandare o spedire email.
      input_schema:
        type: object
        properties:
          folder:
            type: string
            description: 'Cartella Gmail: INBOX, SENT, DRAFT, SPAM, TRASH (default: INBOX)'
          max_results:
            type: integer
            description: 'Numero massimo di email da restituire (default: 10, max: 50)'
          query:
            type: string
            description: Query di ricerca Gmail (es. 'from:boss@company.com is:unread subject:fattura')
          unread_only:
            type: boolean
            description: 'Se true, mostra solo le email non lette (default: false)'
    - filename: scripts/read_email.py
      language: python
      description: |
        LEGGE il contenuto completo di una singola email (intestazioni, corpo testo/HTML, lista allegati). Usare ESCLUSIVAMENTE quando si conosce l'ID di un messaggio specifico (ottenuto da list_emails o check_new_emails) e si vuole leggere/aprire/ visualizzare il testo completo di quel messaggio. Segna automaticamente il messaggio come letto. NON usare per inviare, elencare o cercare email.
      input_schema:
        type: object
        required:
          - email_id
        properties:
          email_id:
            type: string
            description: ID del messaggio Gmail (ottenuto da list_emails)
          mark_as_read:
            type: boolean
            description: 'Se true segna come letta (default: true)'
    - filename: scripts/reply_email.py
      language: python
      description: |
        RISPONDE a un'email esistente mantenendo il thread originale. Usare ESCLUSIVAMENTE quando l'utente vuole rispondere/replicare a un messaggio ricevuto. Richiede l'email_id del messaggio originale (ottenuto da list_emails). Supporta risposta al solo mittente o a tutti (reply-all) e allegati. NON usare per inviare nuove email (usare send_email), né per elencare email.
      input_schema:
        type: object
        required:
          - email_id
          - body
        properties:
          email_id:
            type: string
            description: ID del messaggio Gmail a cui rispondere
          body:
            type: string
            description: Corpo della risposta (testo puro oppure HTML se html=true)
          reply_all:
            type: boolean
            description: 'Se true risponde a tutti i destinatari (default: false, risponde solo al mittente)'
          html:
            type: boolean
            description: 'Se true, il corpo viene inviato come HTML (default: false)'
          attachments:
            type: array
            items:
              type: string
            description: |
              Lista di path assoluti ai file da allegare (opzionale). Usare i path restituiti da altre skill che generano file. Il tipo MIME viene rilevato automaticamente dall'estensione del file. Esempio: ["/shared/output/report.pdf"]
    - filename: scripts/forward_email.py
      language: python
      description: |
        INOLTRA un'email esistente a nuovi destinatari aprendo un nuovo thread. Usare ESCLUSIVAMENTE quando l'utente vuole inoltrare/girare/mandare un messaggio ricevuto ad altri. Richiede l'email_id dell'originale. Supporta messaggio aggiuntivo e allegati extra. NON usare per inviare nuove email (usare send_email), né per rispondere.
      input_schema:
        type: object
        required:
          - email_id
          - to
        properties:
          email_id:
            type: string
            description: ID del messaggio Gmail da inoltrare
          to:
            type: string
            description: Destinatario o lista destinatari separati da virgola
          message:
            type: string
            description: Messaggio aggiuntivo da aggiungere prima del contenuto inoltrato (opzionale)
          attachments:
            type: array
            items:
              type: string
            description: |
              Lista di path assoluti a file aggiuntivi da allegare (opzionale). Si aggiungono al contenuto inoltrato. Usare i path restituiti da altre skill che generano file. Il tipo MIME viene rilevato automaticamente dall'estensione del file. Esempio: ["/shared/output/dati.csv"]
    - filename: scripts/check_new_emails.py
      language: python
      description: |
        VERIFICA se sono arrivate nuove email nelle ultime N minuti. Usare ESCLUSIVAMENTE quando l'utente chiede se ha ricevuto email di recente, se ci sono novità nella posta, o per controllare l'arrivo di messaggi specifici attesi. Restituisce lista delle email ricevute nel periodo con mittente, oggetto e anteprima. NON usare per inviare email o per elencare tutta la posta.
      input_schema:
        type: object
        properties:
          since_minutes:
            type: integer
            description: 'Controlla email arrivate negli ultimi N minuti (default: 30)'
          max_results:
            type: integer
            description: 'Numero massimo di email da restituire (default: 20)'
          unread_only:
            type: boolean
            description: 'Se true mostra solo le non lette (default: true)'
    - filename: scripts/daemon_emails.py
      language: python
      mode: daemon
      description: |
        Daemon di monitoraggio Gmail in tempo reale (watch). Gira come processo background e invia una notifica push istantanea al backend non appena arrivano nuove email nell'INBOX, usando la Gmail History API. Non viene mai invocato dal LLM: si avvia e si gestisce tramite l'interfaccia daemon (Impostazioni → Skills → Background oppure POST /api/daemons). Richiede GMAIL_CLIENT_ID, GMAIL_CLIENT_SECRET e GMAIL_REFRESH_TOKEN configurati. Intervallo di polling configurabile con la variabile d'ambiente GMAIL_POLL_INTERVAL (default: 30 secondi). Emette eventi: new_emails (nuove email rilevate), auth_error (token scaduto/revocato).
---

# Gmail — Gestione Email

Skill per operazioni Gmail via OAuth2: invio, lettura, elenco, risposta, inoltro e monitoraggio.

**Prerequisito comune a tutti gli script:** la skill deve essere autenticata (GMAIL_CLIENT_ID,
GMAIL_CLIENT_SECRET e GMAIL_REFRESH_TOKEN configurati). Se mancano o sono scaduti, usa prima
`skill_gmail_auth_start_py` → `skill_gmail_auth_complete_py`.

**Regola generale:** usa SOLO il nome tool indicato in ogni sezione. Non inventare nomi.

---

## Rete (network)

Richiede egress verso: `accounts.google.com`, `oauth2.googleapis.com`, `www.googleapis.com`. I domini sono già dichiarati in `skill.yaml`.

<!-- @tool: auth_start.py -->
## Autenticazione — Avvio OAuth2

**Tool name:** `skill_gmail_auth_start_py`

**Quando usarlo:** l'utente chiede di connettere Gmail, configurare la skill per la prima volta,
o ricevuti errori di autenticazione (token scaduto/revocato). NON usare per email.

### Prerequisiti (solo al primo setup)

L'utente deve avere un progetto Google Cloud con Gmail API abilitata e un Client ID OAuth2 di tipo **App desktop**.
Se non ce l'ha:
1. [console.cloud.google.com](https://console.cloud.google.com) → Nuovo progetto
2. API e servizi → Libreria → cerca **Gmail API** → Abilita
3. API e servizi → Credenziali → **Crea credenziali → ID client OAuth → App desktop**
4. Copiare **Client ID** e **Client Secret**

### Comportamento

Restituisce un `auth_url`. **Mostralo all'utente come link cliccabile** con queste istruzioni:
> "Clicca il link, accedi con il tuo account Gmail e concedi i permessi.
> Dopo l'autorizzazione vedrai una pagina di errore: è normale.
> Copia l'URL completo dalla barra del browser e incollalo qui."

Poi chiama `skill_gmail_auth_complete_py` con l'URL incollato.

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `client_id` | string | ❌ | OAuth Client ID (se non già in `_config`) |
| `client_secret` | string | ❌ | OAuth Client Secret (se non già in `_config`) |

### Errori comuni

| Errore | Causa | Soluzione |
|--------|-------|-----------|
| `refresh_token` assente | App già autorizzata | Revocare accesso su myaccount.google.com/permissions e ripetere |
| `access_denied` | Permessi rifiutati | Ripetere e accettare tutti i permessi |
| HTTP 401 / invalid_client | Client ID/Secret errati | Verificare su console.cloud.google.com |

**Scope OAuth usato:** `https://mail.google.com/` (accesso completo — necessario per send, reply, forward e daemon).

<!-- @tool: auth_complete.py -->
## Autenticazione — Completamento OAuth2

**Tool name:** `skill_gmail_auth_complete_py`

**Quando usarlo:** subito dopo `skill_gmail_auth_start_py`, quando l'utente incolla l'URL dalla barra del browser. NON usare per email.

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `redirect_url` | string | ✅ | URL completo incollato dall'utente |
| `client_id` | string | ❌ | Solo se non già in `_config` |
| `client_secret` | string | ❌ | Solo se non già in `_config` |

### Comportamento

Salva la configurazione direttamente e in modo sicuro nel backend (i token non appaiono mai nell'output).
Se va a buon fine restituisce solo un messaggio di conferma — **nessuna azione manuale richiesta all'utente**.

<!-- @tool: send_email.py -->
## Invia Email

**Tool name:** `skill_gmail_send_email_py`

**Quando usarlo:** ESCLUSIVAMENTE quando l'utente vuole **inviare / mandare / spedire / scrivere**
un'email in uscita a uno o più destinatari. Anche con allegati (PDF, CSV, ecc.).

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `to` | string | ✅ | Destinatario/i, separati da virgola |
| `subject` | string | ✅ | Oggetto dell'email |
| `body` | string | ✅ | Corpo dell'email |
| `cc` | string | ❌ | CC separati da virgola |
| `bcc` | string | ❌ | BCC separati da virgola |
| `html` | boolean | ❌ | Se `true`, body trattato come HTML (default: `false`) |
| `attachments` | array | ❌ | Lista di path assoluti ai file da allegare |

### Output

```json
{
  "success": true,
  "message_id": "18f4a2b3c4d5e6f7",
  "to": "mario@example.com",
  "subject": "Preventivo Giugno",
  "attachments": ["report.pdf"],
  "message": "✅ Email inviata a mario@example.com con oggetto 'Preventivo Giugno'."
}
```

**Come rispondere:** `Ho inviato l'email a {to} con oggetto "{subject}". ✅`

### Allegati da altre skill

Per allegare un file generato da un'altra skill (es. PDF da `skill_pdf_generator_html_generate_pdf_js`):
1. Leggi il `file_path` assoluto nell'output della skill precedente
2. Passalo nel campo `attachments`, es: `["/percorso/assoluto/report.pdf"]`

Il tipo MIME viene rilevato automaticamente dall'estensione.

**Flusso completo — genera PDF e invia:**
```
# Step 1 — genera il PDF
skill_pdf_generator_html_generate_pdf_js(html="...", filename="report.pdf")
# → restituisce { "file_path": "/Users/.../uploads/skills-output/pdfs/report.pdf", ... }

# Step 2 — invia con allegato
skill_gmail_send_email_py(
  to="utente@example.com",
  subject="Report",
  body="In allegato il report.",
  attachments=["/Users/.../uploads/skills-output/pdfs/report.pdf"]
)
```

<!-- @tool: list_emails.py -->
## Elenca Email

**Tool name:** `skill_gmail_list_emails_py`

**Quando usarlo:** ESCLUSIVAMENTE quando l'utente vuole **vedere / mostrare / elencare /
sfogliare / controllare** la posta ricevuta o inviata. Restituisce lista con ID, mittente,
oggetto e data. Gli ID servono per leggere (`skill_gmail_read_email_py`), rispondere
(`skill_gmail_reply_email_py`) o inoltrare (`skill_gmail_forward_email_py`) messaggi specifici.
NON usare per inviare email.

### Input

| Campo | Tipo | Default | Descrizione |
|-------|------|---------|-------------|
| `folder` | string | `INBOX` | Cartella: `INBOX`, `SENT`, `DRAFT`, `SPAM`, `TRASH` |
| `max_results` | integer | `10` | Quante email (max: 50) |
| `query` | string | — | Query Gmail (es: `from:boss@azienda.com is:unread subject:fattura`) |
| `unread_only` | boolean | `false` | Solo non lette |

### Output

```json
{
  "success": true,
  "count": 3,
  "unread_count": 1,
  "folder": "INBOX",
  "emails": [
    { "id": "18f4a2b3c4d5e6f7", "subject": "Preventivo approvato", "from": "mario@example.com",
      "date": "Sat, 24 May 2026 10:30:00 +0200", "snippet": "Ciao...", "unread": true }
  ],
  "message": "Trovate 3 email in posta in arrivo (1 non lette)."
}
```

**Come presentare:**
```
📥 Hai **{count}** email:

| # | Da | Oggetto | Data | Stato |
|---|----|---------|----|-------|
| 1 | mario@example.com | Preventivo approvato | 24 Mag | 🔵 Nuova |
| 2 | anna@example.com | Meeting domani | 23 Mag | ✅ Letta |
```

<!-- @tool: read_email.py -->
## Leggi Email

**Tool name:** `skill_gmail_read_email_py`

**Quando usarlo:** ESCLUSIVAMENTE quando si conosce l'`email_id` di un messaggio specifico
e si vuole **leggere / aprire / visualizzare** il testo completo. Richiede l'ID ottenuto
da `skill_gmail_list_emails_py` o `skill_gmail_check_new_emails_py`.
Segna automaticamente il messaggio come letto.

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `email_id` | string | ✅ | ID del messaggio (da `list_emails` o `check_new_emails`) |
| `mark_as_read` | boolean | ❌ | Segna come letta (default: `true`) |

### Output

```json
{
  "success": true,
  "id": "18f4a2b3c4d5e6f7",
  "subject": "Preventivo approvato",
  "from": "mario@example.com",
  "to": "me@gmail.com",
  "date": "Sat, 24 May 2026 10:30:00 +0200",
  "body_text": "Ciao,\n\nHo approvato il preventivo...",
  "attachments": [],
  "message": "Email recuperata."
}
```

**Come presentare:** mostra `body_text` (o `body_html` se `body_text` è vuoto).
Indica mittente, data, oggetto. Se ci sono allegati elenca i nomi file.

<!-- @tool: reply_email.py -->
## Rispondi a un'Email

**Tool name:** `skill_gmail_reply_email_py`

**Quando usarlo:** ESCLUSIVAMENTE quando l'utente vuole **rispondere / replicare** a un
messaggio ricevuto, mantenendo il thread. Richiede l'`email_id` del messaggio originale.
NON usare per inviare nuove email (usa `skill_gmail_send_email_py` per messaggi nuovi).

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `email_id` | string | ✅ | ID dell'email a cui rispondere |
| `body` | string | ✅ | Testo della risposta |
| `reply_all` | boolean | ❌ | Risponde a tutti i destinatari (default: `false`) |
| `html` | boolean | ❌ | Body come HTML (default: `false`) |
| `attachments` | array | ❌ | Lista di path assoluti ai file da allegare |

### Output

```json
{
  "success": true,
  "message_id": "18f4a2b3c4d5e6f8",
  "thread_id": "18f4a2b3c4d5e6f7",
  "to": "mario@example.com",
  "subject": "Re: Preventivo approvato",
  "message": "✅ Risposta inviata."
}
```

**Threading:** mantiene automaticamente il thread originale.

<!-- @tool: forward_email.py -->
## Inoltra Email

**Tool name:** `skill_gmail_forward_email_py`

**Quando usarlo:** ESCLUSIVAMENTE quando l'utente vuole **inoltrare / girare / mandare
ad altri** un messaggio ricevuto. Richiede l'`email_id` dell'originale. Apre un nuovo thread.
NON usare per inviare email nuove (usa `skill_gmail_send_email_py`).

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `email_id` | string | ✅ | ID del messaggio da inoltrare |
| `to` | string | ✅ | Destinatario/i dell'inoltro |
| `message` | string | ❌ | Testo aggiuntivo prima del contenuto inoltrato |
| `attachments` | array | ❌ | File aggiuntivi da allegare |

### Output

```json
{
  "success": true,
  "message_id": "18f4a2b3c4d5e6f9",
  "to": "luigi@example.com",
  "subject": "Fwd: Preventivo approvato",
  "message": "✅ Email inoltrata a 'luigi@example.com'."
}
```

<!-- @tool: check_new_emails.py -->
## Controlla Nuove Email

**Tool name:** `skill_gmail_check_new_emails_py`

**Quando usarlo:** ESCLUSIVAMENTE quando l'utente chiede **se ha ricevuto email** di recente,
se ci sono novità nella posta, o per verificare l'arrivo di messaggi specifici attesi.
NON usare per inviare email o per elencare tutta la posta storica.

### Input

| Campo | Tipo | Default | Descrizione |
|-------|------|---------|-------------|
| `since_minutes` | integer | `30` | Controlla gli ultimi N minuti |
| `max_results` | integer | `20` | Max email da restituire |
| `unread_only` | boolean | `true` | Solo non lette |

### Output

```json
{
  "success": true,
  "new_count": 2,
  "unread_count": 2,
  "since_minutes": 30,
  "checked_at": "2026-05-24T10:45:00",
  "emails": [ "..." ],
  "message": "📬 2 nuova/e email negli ultimi 30 minuti."
}
```

**Come rispondere:**
- Se `new_count == 0`: "Nessuna nuova email negli ultimi {since_minutes} minuti. 📭"
- Se `new_count > 0`: mostra la lista in formato tabella (come per `list_emails`).

<!-- @tool: daemon_emails.py -->
## Monitoraggio in tempo reale (daemon)

> ⚠️ **Questo script NON viene mai invocato dal LLM** — non esiste un tool chiamabile.
> È un daemon background gestito dall'applicazione (Settings → Background).
> Il LLM deve solo suggerire all'utente di avviarlo tramite l'interfaccia, non chiamarlo.

### Cosa fa

Si connette alla Gmail History API e monitora l'INBOX ogni `GMAIL_POLL_INTERVAL` secondi (default: 30).
Quando trova nuove email, invia un evento push al backend.

### Evento `new_emails`

```json
{
  "event_type": "new_emails",
  "payload": {
    "count": 2,
    "emails": [
      { "id": "18f4a2b3c4d5e6f7", "subject": "Preventivo approvato",
        "from": "mario@example.com", "date": "...", "snippet": "Ciao..." }
    ]
  }
}
```

Gli `email_id` nell'evento sono usabili direttamente con i tool read/reply/forward.

### Evento `auth_error`

```json
{ "event_type": "auth_error", "payload": { "error": "invalid_grant: Token has been expired or revoked." } }
```

**Soluzione:** riconnettere Gmail e riavviare il daemon.

### Note operative

- Il daemon filtra solo messaggi con label `INBOX` e senza label `SENT`.
- Il token OAuth scade dopo **7 giorni** in modalità Testing Google.
- Variabili iniettate automaticamente: `PUSH_URL`, `DAEMON_ID`, `SKILL_ID`, `USER_ID`, `INTERNAL_TOKEN`.
