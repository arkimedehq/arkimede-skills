# PDF Generator HTML

Genera documenti PDF A4 professionali da contenuto HTML tramite **Puppeteer** (Chromium headless).

## Funzionalità

- Supporta HTML/CSS completo: tabelle stilizzate, intestazioni, liste, testo formattato, stili inline
- Template professionale incluso: font, colori corporate, tabelle con righe alternate, footer automatico
- Ideale per preventivi, report, fatture, tavole costi
- **Integrazione inter-skill**: il `file_path` restituito può essere passato direttamente alla skill Gmail per allegare
  il PDF a un'email

## Input

| Campo      | Tipo   | Richiesto | Descrizione                               |
|------------|--------|:---------:|-------------------------------------------|
| `title`    | string |     ✅     | Titolo del documento (testo puro)         |
| `content`  | string |     ✅     | Corpo del documento come HTML             |
| `filename` | string |     ❌     | Nome base del file (default: `documento`) |
| `styles`   | string |     ❌     | CSS aggiuntivo da iniettare               |

## Output

```json
{
  "success": true,
  "filename": "preventivo_3f8a1b2c4d5e.pdf",
  "file_path": "/absolute/path/to/skills-output/pdfs/preventivo_3f8a1b2c4d5e.pdf",
  "download_url": "skills-output/pdfs/preventivo_3f8a1b2c4d5e.pdf",
  "size_bytes": 45678,
  "message": "PDF 'Preventivo' generato (44.6 KB)."
}
```

| Campo | Uso |
|-------|-----|
| `file_path` | Percorso assoluto — inter-skill (es. `attachments` Gmail) |
| `download_url` | Path relativo alla dir `uploads/` — il backend/frontend costruisce l'URL di download (`/api/files/raw?rel=…`) |

## Configurazione

| Chiave     | Descrizione                                   | Default       |
|------------|-----------------------------------------------|---------------|
| `APP_NAME` | Nome applicazione mostrato nel footer del PDF | `${APP_NAME}` |

## Dipendenze

- `puppeteer@22` (installato automaticamente al primo avvio)

## Versione

`1.1.0` — Migrazione a `SKILLS_OUTPUT_DIR` per inter-skill file sharing. Output: `file_path` (assoluto, per inter-skill) e `download_url` (relativo a `uploads/`, per costruire l'URL di download lato backend/frontend). Filename con UUID hex (6 byte, 12 char) per prevenire allucinazioni LLM sulla ricostruzione del nome file.

## Network

Nessun egress dichiarato: il rendering avviene in locale con Puppeteer. **Attenzione:** se l'HTML in input referenzia risorse remote (immagini, CSS o font via URL), con l'overlay egress non verranno caricate finché i loro domini non sono aggiunti a `network:` nel `skill.yaml`.
