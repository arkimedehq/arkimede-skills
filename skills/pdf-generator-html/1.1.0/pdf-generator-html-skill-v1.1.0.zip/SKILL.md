---
name: pdf-generator-html
description: |
  Genera documenti PDF A4 professionali da contenuto HTML tramite Puppeteer (Chromium headless). Supporta HTML/CSS completo: tabelle stilizzate, intestazioni, liste, testo formattato, stili inline. Ideale per preventivi, report, tavole costi.
version: 1.1.0
author: info@rstonline.it
license: MIT
runtime:
  dependencies:
    javascript:
      - puppeteer@22
  network: []
  config:
    - key: APP_NAME
      description: Nome applicazione mostrato nel footer del PDF
      default: ${APP_NAME}
      required: false
      secret: false
  scripts:
    - filename: scripts/generate_pdf.js
      language: node
      description: |
        Genera un PDF A4 da titolo + contenuto HTML tramite Puppeteer. Accetta HTML completo nel campo content: tabelle (<table>), intestazioni (<h2>, <h3>), liste (<ul>, <ol>), paragrafi (<p>). Restituisce file_path con il path assoluto del file generato. Per allegare il PDF a un'email, passare file_path al campo attachments di send_email, reply_email o forward_email della skill Gmail.
      input_schema:
        type: object
        required:
          - title
          - content
        properties:
          title:
            type: string
            description: Titolo principale del documento (testo puro, non HTML)
          content:
            type: string
            description: |
              Corpo del documento come HTML. Esempio: <p>Testo introduttivo.</p> <table><tr><th>Voce</th><th>Prezzo</th></tr><tr><td>Prodotto</td><td>100 EUR</td></tr></table>
          filename:
            type: string
            description: 'Nome base del file senza estensione (default: documento)'
          styles:
            type: string
            description: CSS aggiuntivo da iniettare nel documento (opzionale)
---

# PDF Generator HTML

## Quando usarla

Usa questa skill **solo su richiesta esplicita dell'utente** — quando chiede di:

- Generare un PDF, un preventivo, un report, una tavola costi
- "Fammi un PDF con…" / "Crea un preventivo…" / "Voglio un documento da scaricare"

**Non** generare PDF automaticamente durante conversazioni normali.

## Come usarla

Chiama lo script `scripts/generate_pdf.js` con:

| Campo      | Tipo   | Obbligatorio | Descrizione                                       |
|------------|--------|:------------:|---------------------------------------------------|
| `title`    | string |      ✅       | Titolo del documento (testo puro, non HTML)       |
| `content`  | string |      ✅       | Corpo come HTML (vedi esempi sotto)               |
| `filename` | string |      ❌       | Nome file senza estensione (default: `documento`) |
| `styles`   | string |      ❌       | CSS aggiuntivo da iniettare (opzionale)           |

> `_config` viene iniettato automaticamente dal backend — non includerlo nell'input.

## Come costruire il contenuto HTML

Il campo `content` accetta HTML completo. Esempi:

**Paragrafi:**

```html
<p>Gentile cliente,</p>
<p>di seguito il preventivo per la fornitura.</p>
```

**Tabella preventivo:**

```html

<table>
    <tr>
        <th>Voce</th>
        <th>Qtà</th>
        <th>Prezzo unit.</th>
        <th>Totale</th>
    </tr>
    <tr>
        <td>Banco cassa</td>
        <td>1</td>
        <td>2.400 EUR</td>
        <td>2.400 EUR</td>
    </tr>
    <tr>
        <td>Scaffalature</td>
        <td>4</td>
        <td>850 EUR</td>
        <td>3.400 EUR</td>
    </tr>
    <tr>
        <td><strong>Totale</strong></td>
        <td></td>
        <td></td>
        <td><strong>5.800 EUR</strong></td>
    </tr>
</table>
```

**Liste:**

```html

<ul>
    <li>Caratteristica 1</li>
    <li>Caratteristica 2</li>
</ul>
```

**Sezioni con intestazioni:**

```html
<h2>Sezione 1</h2>
<p>Testo della sezione.</p>
<h2>Sezione 2</h2>
<p>Altro testo.</p>
```

## Output e risposta all'utente

Lo script restituisce JSON con:

```json
{
  "success": true,
  "filename": "preventivo_3f8a1b2c4d5e.pdf",
  "file_path": "/absolute/path/to/skills-output/pdfs/preventivo_3f8a1b2c4d5e.pdf",
  "download_url": "skills-output/pdfs/preventivo_3f8a1b2c4d5e.pdf",
  "size_bytes": 45678,
  "message": "PDF 'Preventivo' generato (44.6 KB)."
}
```

| Campo | Descrizione |
|-------|-------------|
| `file_path` | Percorso assoluto — usalo per inter-skill (es. allegato Gmail) |
| `download_url` | Path relativo alla dir `uploads/` — il backend/frontend lo usa per costruire l'URL di download (`/api/files/raw?rel=…`) |

### Come presentare il link all'utente

Formatta il link come markdown usando `download_url` come href. Il frontend intercetta automaticamente i path `skills-output/…` e li converte in download autenticati.

```
Il PDF è pronto! [📄 {filename}]({download_url}) ({size_kb} KB)
```

Esempio concreto:
```
Il PDF è pronto! [📄 preventivo_3f8a1b2c4d5e.pdf](skills-output/pdfs/preventivo_3f8a1b2c4d5e.pdf) (44.6 KB)
```

### Allegare il PDF a un'email (inter-skill)

Il campo `file_path` contiene il percorso assoluto del file generato. Passalo direttamente al campo `attachments` della
skill Gmail per allegarlo a un'email:

```json
{
  "to": "cliente@example.com",
  "subject": "Preventivo richiesto",
  "body": "In allegato il preventivo.",
  "attachments": [
    "{file_path}"
  ]
}
```

> **Nota:** Il file è salvato nella directory condivisa tra skill (`SKILLS_OUTPUT_DIR`). Non è necessario copiarlo — il
> path restituito è già accessibile da altre skills.

## Stili predefiniti nel template

Il template include già:

- Font Arial/Helvetica, colore corporate `#1a56db`
- Intestazioni `<h1>` (titolo principale, blu con linea), `<h2>`, `<h3>`
- Tabelle: header blu bianco, righe alternate grigio/bianco, ultima riga in grassetto
- Footer automatico con data, ora e nome applicazione
- Margini A4 standard (20mm top/bottom, 15mm lato)

## Rete (network)

Nessuna connessione esterna: la skill opera in locale e/o via backend interno.
