'use strict';
/**
 * generate_pdf.js — Skill: pdf-generator-html  v1.0.0
 *
 * Genera un PDF A4 professionale da HTML tramite Puppeteer (Chromium headless).
 *
 * Input  (stdin): JSON con:
 *   - title    (string, required)  — titolo del documento (testo puro)
 *   - content  (string, required)  — corpo come HTML
 *   - filename (string, optional)  — nome file base senza estensione
 *   - styles   (string, optional)  — CSS aggiuntivo
 *   - _config  (object, iniettato) — APP_NAME, UPLOAD_DIR
 *
 * La directory di output viene letta da process.env.SKILLS_OUTPUT_DIR (iniettato
 * dall'executor in ogni script). Il PDF viene salvato in SKILLS_OUTPUT_DIR/pdfs/.
 *
 * Output (stdout): JSON con success, filename, file_path, size_bytes, message
 */
const fs   = require('fs');
const path = require('path');

// ── Helpers ───────────────────────────────────────────────────────────────────

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatDate(d) {
  return d.toLocaleDateString('it-IT', {
    day: '2-digit', month: 'long', year: 'numeric',
  });
}

function formatDateTime(d) {
  return (
    d.toLocaleDateString('it-IT') +
    ' ' +
    d.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────

async function main() {
  // Leggi input da stdin
  const raw = fs.readFileSync(0, 'utf8');
  let data;
  try {
    data = JSON.parse(raw);
  } catch (e) {
    console.log(JSON.stringify({ success: false, error: `JSON non valido: ${e.message}` }));
    process.exit(1);
  }

  const _config    = data._config ?? {};
  const title      = String(data.title    ?? 'Documento');
  const content    = String(data.content  ?? '');
  const baseName   = String(data.filename ?? 'documento').replace(/\s+/g, '_');
  const extraStyles = String(data.styles  ?? '');

  // Directory condivisa iniettata dall'executor — accessibile a tutte le skill
  const skillsOutputDir = process.env.SKILLS_OUTPUT_DIR ?? path.join(process.cwd(), '..', 'skills-output');
  const outputDir = path.join(skillsOutputDir, 'pdfs');
  const appName   = _config.APP_NAME ?? 'PDF';

  // ── Carica Puppeteer ────────────────────────────────────────────────────────
  let puppeteer;
  try {
    puppeteer = require('puppeteer');
  } catch (e) {
    console.log(JSON.stringify({
      success: false,
      error: `puppeteer non trovato: ${e.message}. Esegui reinstall deps dalla UI.`,
    }));
    process.exit(1);
  }

  // ── Lancia Chromium ─────────────────────────────────────────────────────────
  const browser = await puppeteer.launch({
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
    ],
  });

  let page;
  try {
    page = await browser.newPage();

    const now = new Date();

    // ── Template HTML ───────────────────────────────────────────────────────
    const html = `<!DOCTYPE html>
<html lang="it">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *, *::before, *::after { box-sizing: border-box; }

    body {
      font-family: Arial, Helvetica, sans-serif;
      margin: 0;
      padding: 0 40px 60px 40px;
      color: #212121;
      font-size: 11pt;
      line-height: 1.55;
    }

    /* ── Titolo principale ── */
    .doc-title {
      color: #1a56db;
      border-bottom: 3px solid #1a56db;
      padding-bottom: 8px;
      margin: 36px 0 4px 0;
      font-size: 20pt;
      font-weight: bold;
    }

    .doc-date {
      font-size: 9pt;
      color: #666;
      font-style: italic;
      margin-bottom: 24px;
    }

    /* ── Intestazioni ── */
    h2 {
      color: #1a56db;
      font-size: 14pt;
      margin: 24px 0 8px 0;
      border-bottom: 1px solid #c7d8f7;
      padding-bottom: 4px;
    }
    h3 {
      color: #333;
      font-size: 12pt;
      margin: 16px 0 6px 0;
    }
    h4 {
      color: #555;
      font-size: 11pt;
      margin: 12px 0 4px 0;
    }

    /* ── Testo ── */
    p { margin: 0 0 8px 0; }
    strong { font-weight: bold; }
    em { font-style: italic; }

    /* ── Liste ── */
    ul, ol { margin: 0 0 10px 0; padding-left: 22px; }
    li { margin-bottom: 3px; }

    /* ── Tabelle ── */
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 16px 0 20px 0;
      font-size: 10pt;
      page-break-inside: avoid;
    }
    th {
      background: #1a56db;
      color: #ffffff;
      padding: 9px 10px;
      text-align: center;
      font-weight: bold;
      border: 1px solid #1a56db;
    }
    td {
      border: 1px solid #ddd;
      padding: 7px 10px;
      vertical-align: top;
    }
    tr:nth-child(even) td { background: #f5f8ff; }
    tr:last-child td {
      font-weight: bold;
      background: #e8efff;
      border-top: 2px solid #1a56db;
    }

    /* ── Evidenziazioni utili ── */
    .highlight { background: #fff3cd; padding: 2px 4px; border-radius: 3px; }
    .note {
      background: #f0f4ff;
      border-left: 4px solid #1a56db;
      padding: 10px 14px;
      margin: 12px 0;
      font-size: 10pt;
      color: #333;
    }

    /* ── Footer ── */
    .footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      height: 28px;
      padding: 0 40px;
      border-top: 1px solid #ddd;
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 8pt;
      color: #999;
      background: white;
    }

    /* ── Stili aggiuntivi utente ── */
    ${extraStyles}
  </style>
</head>
<body>
  <h1 class="doc-title">${escapeHtml(title)}</h1>
  <p class="doc-date">${formatDate(now)}</p>

  <div class="content">
    ${content}
  </div>

  <div class="footer">
    <span>Generato il ${formatDateTime(now)}</span>
    <span>${escapeHtml(appName)}</span>
  </div>
</body>
</html>`;

    await page.setContent(html, { waitUntil: 'networkidle0' });

    // ── Salva PDF ─────────────────────────────────────────────────────────────
    fs.mkdirSync(outputDir, { recursive: true });

    const uid      = require('crypto').randomBytes(6).toString('hex');
    const outFname = `${baseName}_${uid}.pdf`;
    const outPath   = path.join(outputDir, outFname);

    await page.pdf({
      path: outPath,
      format: 'A4',
      printBackground: true,
      margin: {
        top:    '20mm',
        bottom: '35mm',   // spazio per il footer fisso
        left:   '0mm',
        right:  '0mm',
      },
    });

    const sizeBytes = fs.statSync(outPath).size;

    const uploadsDir   = path.dirname(skillsOutputDir);
    const downloadUrl  = path.relative(uploadsDir, outPath);

    console.log(JSON.stringify({
      success:      true,
      filename:     outFname,
      file_path:    outPath,
      download_url: downloadUrl,
      size_bytes:   sizeBytes,
      message:      `PDF '${title}' generato (${(sizeBytes / 1024).toFixed(1)} KB).`,
    }));

  } finally {
    await browser.close();
  }
}

main().catch((err) => {
  console.log(JSON.stringify({
    success: false,
    error:   err.message,
    stack:   err.stack,
  }));
  process.exit(1);
});