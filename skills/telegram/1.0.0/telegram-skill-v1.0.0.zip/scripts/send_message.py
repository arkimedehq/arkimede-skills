#!/usr/bin/env python3
"""
telegram — send a message from the linked Telegram account.

The recipient must be 'me' (Saved Messages) or one of ALLOWED_RECIPIENTS (any contact
when it is empty); it can be designated by @username, +phone, numeric id or name. Long
texts are split; an optional file is sent as a document, with the text as caption when
it fits. Every message sent to someone is noted in the sent log (the listener uses it to
recognise their replies in personal mode).

Without `to`, the message is for the user themself: through the bot when one is
configured and the user linked it (it rings; the answer names the Arkimede chat the bot
uses with them, `arkimede_chat`), else to the account's Saved Messages.

As a user channel (SKILL.md `user-channel`), the host gives the recipient in
`_config.DELIVERY_ADDRESS` (the person's `telegram` address: a numeric id, @username or
+phone), which takes the place of `to`; the allowlist still holds. Only the host sets
`_config`: a model's arguments never reach it.

Input:  {"to": "Maria", "text": "…", "file": "/path/to/file.pdf", "format": "markdown|plain"}
"""

import json
import os
import sys
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (CAPTION_MAX, SkillError, StateLock, connect_authorized,
                       record_sent, resolve_recipient, run, split_text, state_dir,
                       summary, throttle)

BOT_API = 'https://api.telegram.org'


def _bot_call(token, method, payload):
    req = urllib.request.Request(f'{BOT_API}/bot{token}/{method}', data=json.dumps(payload).encode(),
                                 headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=30) as res:
            body = json.loads(res.read() or b'{}')
    except urllib.error.HTTPError as exc:
        body = json.loads(exc.read() or b'{}')
    return bool(body.get('ok')), body


def via_bot(config, text):
    """Sends to the user's own Telegram through the bot: (sent, arkimede_chat) — (False, None)
    when there is no bot or the user never linked it (TG_SESSIONS, kept by bot.js)."""
    token = config.get('TELEGRAM_BOT_TOKEN')
    user_id = config.get('ARKIMEDE_USER_ID') or os.environ.get('USER_ID', '')
    if not token or not user_id:
        return False, None
    try:
        sessions = json.loads(config.get('TG_SESSIONS') or '{}')
    except json.JSONDecodeError:
        sessions = {}
    linked = [(tg_id, s) for tg_id, s in sessions.items() if isinstance(s, dict) and s.get('userId') == user_id]
    if not linked:
        return False, None
    tg_id, session = linked[0]
    for chunk in split_text(text):
        ok, body = _bot_call(token, 'sendMessage', {'chat_id': int(tg_id), 'text': chunk, 'parse_mode': 'Markdown'})
        if not ok:  # Markdown parse errors (unbalanced *_`) → plain text
            ok, body = _bot_call(token, 'sendMessage', {'chat_id': int(tg_id), 'text': chunk})
        if not ok:
            raise SkillError('bot_failed', f"The bot could not send: {body.get('description', 'unknown error')}")
    return True, (session.get('chats') or {}).get(str(tg_id))


async def main(data, config):
    text = str(data.get('text') or '').strip()
    file = str(data.get('file') or '').strip()
    if not text and not file:
        raise SkillError('bad_input', "Give 'text', 'file' or both.")
    if file and not os.path.isfile(file):
        raise SkillError('file_not_found', f'File not found: {file}')
    to = config.get('DELIVERY_ADDRESS') or str(data.get('to') or '').strip()
    if not to and text and not file:
        sent, chat = via_bot(config, text)
        if sent:
            return {'sent_to': {'self': True, 'via': 'bot'}, **({'arkimede_chat': chat} if chat else {}),
                    'message': 'Message delivered on Telegram (bot).'}
    to = to or 'me'
    suffix = config.get('MESSAGE_SUFFIX')
    if suffix and text:
        text = f'{text}\n\n{suffix}'
    parse_mode = None if str(data.get('format') or '').lower() == 'plain' else 'md'

    sdir = state_dir(config)
    with StateLock(sdir):
        client = await connect_authorized(config, sdir)
        try:
            user, is_self = await resolve_recipient(client, config, sdir, to)
            throttle(config, sdir)
            ids = []
            if file and len(text) <= CAPTION_MAX:
                msg = await client.send_file(user, file, caption=text or None, parse_mode=parse_mode,
                                             force_document=True)
                ids.append(msg.id)
            else:
                for chunk in split_text(text):
                    ids.append((await client.send_message(user, chunk, parse_mode=parse_mode,
                                                          link_preview=False)).id)
                if file:
                    ids.append((await client.send_file(user, file, force_document=True)).id)
        finally:
            await client.disconnect()
    if not is_self:
        record_sent(sdir, user.id, ids)
    return {'sent_to': summary(user, is_self=is_self), 'message_ids': ids,
            'message': f'Message delivered on Telegram to {summary(user)["name"]}.'}


if __name__ == '__main__':
    run(main)
