#!/usr/bin/env python3
"""
telegram — withdraw messages the linked account sent (deleted for both
sides). Only the account's own messages, only in chats with allowed recipients
or "me". By default the last message the account sent in that chat.

Input:  {"to": "Maria", "message_ids": [101, 102]}
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (SkillError, StateLock, connect_authorized, resolve_recipient,
                       run, state_dir, summary)

LAST_SCAN = 20     # how far back to look for the account's last message


async def main(data, config):
    ids = data.get('message_ids') or []
    if not isinstance(ids, list) or not all(str(i).isdigit() for i in ids):
        raise SkillError('bad_input', "'message_ids' must be a list of message ids.")
    ids = [int(i) for i in ids]

    sdir = state_dir(config)
    with StateLock(sdir):
        client = await connect_authorized(config, sdir)
        try:
            user, is_self = await resolve_recipient(client, config, sdir, data.get('to'))
            if ids:
                found = [m for m in await client.get_messages(user, ids=ids) if m is not None]
            else:
                found = [m for m in await client.get_messages(user, limit=LAST_SCAN) if m.out][:1]
            own = [m.id for m in found if m.out]
            if not own:
                raise SkillError('nothing_to_delete',
                                 'No message sent by this account was found to withdraw in that chat.')
            await client.delete_messages(user, own, revoke=True)
        finally:
            await client.disconnect()
    skipped = [i for i in ids if i not in own]
    return {'chat': summary(user, is_self=is_self), 'deleted_ids': own,
            **({'skipped_ids': skipped} if skipped else {}),
            'message': f'Withdrew {len(own)} message(s) in the chat with {summary(user)["name"]}.'}


if __name__ == '__main__':
    run(main)
