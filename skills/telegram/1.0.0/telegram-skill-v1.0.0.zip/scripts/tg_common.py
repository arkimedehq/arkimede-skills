#!/usr/bin/env python3
"""
Shared helpers for the telegram skill.

Agent-agnostic contract, the same for every script:
  stdin   a JSON object with the script's input. An optional "_config" object
          carries configuration (some agent runtimes pass it that way).
  env     the same configuration keys as environment variables (fallback).
  stdout  exactly one JSON object:
            {"success": true, ...}
            {"success": false, "error": "<code>", "message": "<human text>", ...}

The session (the login to the Telegram account) lives either in the
TELEGRAM_SESSION config value or in a file of the state directory, written by
login_finish with mode 600. It is never printed.

One connection per session: while the listener daemon (listen.py) is connected it
holds the only one, and the scripts hand their request to it through the state
directory's spool (run → via_daemon) instead of connecting themselves — a session
connected twice at once can be revoked by Telegram.
"""

import asyncio
import fcntl
import json
import os
import re
import sys
import time
import unicodedata
from pathlib import Path

APP_VERSION = '1.0.0'
PENDING_TTL_S = 10 * 60          # a login code is valid for a few minutes
LOCK_TIMEOUT_S = 60
TEXT_CHUNK = 4000                # Telegram's limit is 4096 characters
CAPTION_MAX = 1000               # Telegram's caption limit is 1024 characters
DAEMON_STALE_S = 30              # the listener's heartbeat older than this: not running
SPOOL_TIMEOUT_S = 120            # how long a script waits for the listener's answer
SENT_KEEP = 50                   # message ids kept per person in the sent log
# Scripts that never go through the listener: a login makes its own (new) session.
LOCAL_ONLY = {'login_start', 'login_finish'}


class SkillError(Exception):
    """An expected failure, reported as {"success": false, "error": code, ...}."""

    def __init__(self, code, message, **extra):
        super().__init__(message)
        self.code = code
        self.message = message
        self.extra = extra


# ── I/O ──────────────────────────────────────────────────────────────────────

class Config:
    """Configuration from the stdin "_config" object, falling back to the env."""

    def __init__(self, values=None):
        self._values = {k: v for k, v in (values or {}).items() if v not in (None, '')}

    def get(self, key, default=''):
        value = self._values.get(key)
        if value is None:
            value = os.environ.get(key, '')
        value = str(value).strip()
        return value if value else default


def read_input():
    raw = '' if sys.stdin is None or sys.stdin.isatty() else sys.stdin.read()
    try:
        data = json.loads(raw) if raw.strip() else {}
    except json.JSONDecodeError as exc:
        raise SkillError('bad_input', f'stdin is not valid JSON: {exc}')
    if not isinstance(data, dict):
        raise SkillError('bad_input', 'stdin must be a JSON object')
    config = data.pop('_config', None)
    return data, Config(config if isinstance(config, dict) else {})


def emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, default=str) + '\n')
    sys.stdout.flush()


def outcome(exc):
    """A failure as the JSON answer every script gives."""
    if isinstance(exc, SkillError):
        return {'success': False, 'error': exc.code, 'message': exc.message, **exc.extra}
    flood = _flood_seconds(exc)
    if flood is not None:
        return {'success': False, 'error': 'flood_wait', 'retry_after_s': flood,
                'message': f'Telegram asks to wait {flood} seconds before trying again (anti-spam limit).'}
    return {'success': False, 'error': 'unexpected', 'message': f'{type(exc).__name__}: {exc}'}


async def run_main(main, data, config):
    """`main(data, config)` → the JSON answer (success or the failure)."""
    try:
        return {'success': True, **((await main(data, config)) or {})}
    except Exception as exc:  # noqa: BLE001 — every failure must come back as JSON
        return outcome(exc)


def run(main):
    """Runs `async main(data, config) -> dict` and prints the JSON result — through the
    listener daemon when it holds the connection (see the module's docstring)."""
    try:
        data, config = read_input()
    except SkillError as exc:
        return emit(outcome(exc))
    script = Path(sys.modules[main.__module__].__file__ or '').stem
    try:
        sdir = state_dir(config)
        if script not in LOCAL_ONLY and daemon_alive(sdir):
            return emit(via_daemon(sdir, script, data, config))
    except SkillError as exc:
        return emit(outcome(exc))
    emit(asyncio.run(run_main(main, data, config)))


def _flood_seconds(exc):
    try:
        from telethon.errors import FloodWaitError
    except ImportError:
        return None
    return exc.seconds if isinstance(exc, FloodWaitError) else None


# ── State directory, session, lock ───────────────────────────────────────────

def state_dir(config):
    """TELEGRAM_STATE_DIR, else the host's per-skill SKILL_STATE_DIR, else ~/.config."""
    base = (config.get('TELEGRAM_STATE_DIR')
            or os.environ.get('SKILL_STATE_DIR', '').strip()
            or str(Path.home() / '.config' / 'telegram'))
    path = Path(base)
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass  # a mount we do not own: keep its permissions
    return path


def write_private(path, text):
    """Atomically writes a file readable only by the owner."""
    tmp = path.with_name(path.name + '.tmp')
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as fh:
        fh.write(text)
    os.replace(tmp, path)


def remove_file(path):
    try:
        path.unlink()
    except FileNotFoundError:
        pass


def load_session(config, sdir):
    """Returns (session_string, source) with source 'config', 'file' or None."""
    value = config.get('TELEGRAM_SESSION')
    if value:
        return value, 'config'
    file = sdir / 'session'
    if file.exists():
        value = file.read_text().strip()
        if value:
            return value, 'file'
    return '', None


# ── The listener daemon: heartbeat and spool ─────────────────────────────────

def daemon_alive(sdir):
    """Whether the listener daemon holds the connection now (a fresh heartbeat)."""
    try:
        return time.time() - (sdir / 'daemon.alive').stat().st_mtime < DAEMON_STALE_S
    except FileNotFoundError:
        return False


def spool_dir(sdir):
    path = sdir / 'spool'
    path.mkdir(mode=0o700, exist_ok=True)
    return path


def via_daemon(sdir, script, data, config, timeout=SPOOL_TIMEOUT_S):
    """Hands a script's request to the listener daemon and waits for its answer. The
    request carries the configuration this run got (a host's DELIVERY_ADDRESS, the
    user it runs as); it is readable only by the owner and deleted once read."""
    import uuid

    spool = spool_dir(sdir)
    rid = uuid.uuid4().hex
    values = dict(config._values)
    if os.environ.get('USER_ID'):
        values.setdefault('ARKIMEDE_USER_ID', os.environ['USER_ID'])
    write_private(spool / f'{rid}.req', json.dumps({'script': script, 'data': data, 'config': values}))
    answer = spool / f'{rid}.res'
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if answer.exists():
            try:
                result = json.loads(answer.read_text())
            finally:
                remove_file(answer)
            return result
        time.sleep(0.1)
    remove_file(spool / f'{rid}.req')
    raise SkillError('busy', 'The Telegram listener did not answer in time; try again shortly.')


# ── The sent log: what the agent wrote to whom (replies in personal mode) ────

def record_sent(sdir, peer_id, message_ids, now=None):
    """Notes that the agent wrote `message_ids` to `peer_id` (now)."""
    path = sdir / 'sent.json'
    with open(sdir / '.sent.lock', 'a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            try:
                log = json.loads(path.read_text())
            except (FileNotFoundError, json.JSONDecodeError):
                log = {}
            entry = log.get(str(peer_id)) or {'ids': []}
            entry['at'] = now if now is not None else time.time()
            entry['ids'] = (entry['ids'] + [int(i) for i in message_ids])[-SENT_KEEP:]
            log[str(peer_id)] = entry
            write_private(path, json.dumps(log))
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def sent_to(sdir, peer_id):
    """{'at': epoch, 'ids': [...]} of the agent's last messages to `peer_id`, or None."""
    try:
        return json.loads((sdir / 'sent.json').read_text()).get(str(peer_id))
    except (FileNotFoundError, json.JSONDecodeError):
        return None


class StateLock:
    """One Telegram connection at a time: a session used concurrently from two
    connections can be revoked by Telegram (AUTH_KEY_DUPLICATED)."""

    def __init__(self, sdir, timeout=LOCK_TIMEOUT_S):
        self._path = sdir / '.lock'
        self._timeout = timeout
        self._fh = None

    def __enter__(self):
        self._fh = open(self._path, 'a+')
        deadline = time.monotonic() + self._timeout
        while True:
            try:
                fcntl.flock(self._fh, fcntl.LOCK_EX | fcntl.LOCK_NB)
                return self
            except BlockingIOError:
                if time.monotonic() > deadline:
                    self._fh.close()
                    raise SkillError('busy', 'Another Telegram operation is still running; try again shortly.')
                time.sleep(0.2)

    def __exit__(self, *exc):
        fcntl.flock(self._fh, fcntl.LOCK_UN)
        self._fh.close()


# ── Client ───────────────────────────────────────────────────────────────────

def parse_proxy(url):
    """'socks5://user:pass@host:1080' or 'http://host:3128' → Telethon proxy dict."""
    if not url:
        return None
    m = re.match(r'^(socks5|socks4|http)://(?:([^:@/]+)(?::([^@/]*))?@)?([^:/]+):(\d+)/?$', url)
    if not m:
        raise SkillError('not_configured', 'TELEGRAM_PROXY must look like socks5://host:port or http://host:port')
    scheme, user, password, host, port = m.groups()
    proxy = {'proxy_type': scheme, 'addr': host, 'port': int(port), 'rdns': True}
    if user:
        proxy['username'] = user
        proxy['password'] = password or ''
    return proxy


def connection_proxy(config, env=None):
    """TELEGRAM_PROXY when set; else the host's egress proxy (HTTPS_PROXY / HTTP_PROXY, an HTTP CONNECT proxy:
    a sandbox with no direct route out lets the skill reach only through it — Telethon does not read these variables
    itself); else none."""
    env = os.environ if env is None else env
    explicit = config.get('TELEGRAM_PROXY')
    if explicit:
        return parse_proxy(explicit)
    for key in ('HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy'):
        url = (env.get(key) or '').strip()
        if url.startswith('http://'):
            return parse_proxy(url)
    return None


def make_client(config, session_string='', receive_updates=False):
    from telethon import TelegramClient
    from telethon.sessions import StringSession

    api_id = config.get('TELEGRAM_API_ID')
    api_hash = config.get('TELEGRAM_API_HASH')
    if not api_id or not api_hash:
        raise SkillError('not_configured',
                         'Set TELEGRAM_API_ID and TELEGRAM_API_HASH (create them at https://my.telegram.org → API development tools).')
    if not api_id.isdigit():
        raise SkillError('not_configured', 'TELEGRAM_API_ID must be a number.')
    return TelegramClient(
        StringSession(session_string or None), int(api_id), api_hash,
        proxy=connection_proxy(config),
        device_model='telegram skill', app_version=APP_VERSION,
        receive_updates=receive_updates,
    )


async def connect_authorized(config, sdir):
    session, _ = load_session(config, sdir)
    if not session:
        raise SkillError('not_logged_in',
                         'No Telegram account is linked yet. The account owner must log in once with login_start and login_finish.')
    client = make_client(config, session)
    await client.connect()
    if not await client.is_user_authorized():
        await client.disconnect()
        raise SkillError('session_expired',
                         'The Telegram session is no longer valid (logged out or revoked). The account owner must log in again.')
    return client


# ── Recipients ───────────────────────────────────────────────────────────────

SELF_WORDS = {'me', 'self', 'saved', 'saved messages'}
_USERNAME = re.compile(r'^[a-z][a-z0-9_]{3,31}$')


def classify(value):
    """'@name' → username, '+39…' → phone, digits → id, 'me' → self, else a name."""
    v = value.strip()
    low = v.lower()
    if low in SELF_WORDS:
        return 'self', None
    if v.startswith('@'):
        return 'username', low[1:]
    if v.startswith('+'):
        digits = re.sub(r'[\s\-().]', '', v[1:])
        if digits.isdigit():
            return 'phone', digits
    if v.isdigit():
        return 'id', int(v)
    return 'name', v


def parse_allowlist(raw, key='ALLOWED_RECIPIENTS'):
    """ALLOWED_RECIPIENTS (or AUTHORIZED_CONTACTS): @username, +phone or numeric id, separated by
    commas or new lines. An empty ALLOWED_RECIPIENTS means open mode: anyone the account can reach
    (see resolve_recipient)."""
    entries = []
    for part in re.split(r'[,;\n]+', raw or ''):
        part = part.strip()
        if not part:
            continue
        kind, value = classify(part)
        if kind == 'name':
            if not _USERNAME.match(part.lower()):
                raise SkillError('not_configured',
                                 f"{key} entry '{part}' is not a @username, +phone or numeric id.")
            kind, value = 'username', part.lower()
        if kind != 'self':
            entries.append((kind, value, part))
    return entries


def _usernames(user):
    names = [user.username] if getattr(user, 'username', None) else []
    names += [u.username for u in (getattr(user, 'usernames', None) or []) if getattr(u, 'username', None)]
    return [n.lower() for n in names]


def matches(user, kind, value):
    if kind == 'id':
        return user.id == value
    if kind == 'username':
        return value in _usernames(user)
    if kind == 'phone':
        return (getattr(user, 'phone', None) or '') == value
    return False


def fold(text):
    text = unicodedata.normalize('NFKD', text or '')
    return ''.join(c for c in text if not unicodedata.combining(c)).lower()


def full_name(user):
    return ' '.join(p for p in (getattr(user, 'first_name', None), getattr(user, 'last_name', None)) if p) \
        or (getattr(user, 'username', None) or str(user.id))


def name_matches(user, query):
    """Every word of the query is the start of a word of the name (accents ignored)."""
    words = fold(full_name(user)).split() + _usernames(user)
    return all(any(w.startswith(q) for w in words) for q in fold(query).split())


def summary(user, is_self=False):
    out = {'id': user.id, 'name': full_name(user)}
    if getattr(user, 'username', None):
        out['username'] = '@' + user.username
    if is_self:
        out['is_self'] = True
    return out


async def address_book(client):
    """The account's Telegram contacts (the people saved in its address book)."""
    from telethon.tl.functions.contacts import GetContactsRequest
    from telethon.tl.types import User

    return [u for u in (await client(GetContactsRequest(hash=0))).users
            if isinstance(u, User) and not u.deleted]


async def resolve_allowed(client, sdir, allow):
    """The allowed recipients as Telegram users, plus the entries that could not be
    found. Contacts come in one request; usernames outside the contacts are
    resolved once and cached (username resolution is rate-limited by Telegram)."""
    from telethon.tl.functions.contacts import GetContactsRequest
    from telethon.tl.types import InputPeerUser, User

    contacts = (await client(GetContactsRequest(hash=0))).users
    cache_file = sdir / 'peers.json'
    try:
        cache = json.loads(cache_file.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        cache = {}
    users, unresolved, cache_changed = {}, [], False
    for kind, value, original in allow:
        found = next((u for u in contacts if matches(u, kind, value)), None)
        if found is None and kind == 'username':
            cached = cache.get(value)
            try:
                if cached:
                    found = await client.get_entity(InputPeerUser(cached['id'], cached['access_hash']))
                else:
                    found = await client.get_entity(value)
                    if isinstance(found, User):
                        cache[value] = {'id': found.id, 'access_hash': found.access_hash}
                        cache_changed = True
            except (ValueError, TypeError):
                found = None
        if isinstance(found, User) and not found.deleted:
            users[found.id] = found
        else:
            unresolved.append(original)
    if cache_changed:
        write_private(cache_file, json.dumps(cache))
    return list(users.values()), unresolved


async def resolve_recipient(client, config, sdir, to):
    """The one allowed user `to` designates: 'me', @username, +phone, id or a name.

    With an empty ALLOWED_RECIPIENTS (open mode) anyone can be reached: a name is
    looked up in the address book, a @username anywhere on Telegram, a +phone or an
    id among the contacts."""
    to = (to or '').strip()
    if not to:
        raise SkillError('bad_input', "'to' is required.")
    me = await client.get_me()
    kind, value = classify(to)
    if kind == 'self':
        return me, True
    allow = parse_allowlist(config.get('ALLOWED_RECIPIENTS'))
    if allow:
        users, unresolved = await resolve_allowed(client, sdir, allow)
    elif kind == 'name':
        users, unresolved = await address_book(client), []
    else:
        users, unresolved = await resolve_allowed(client, sdir, [(kind, value, to)])
    if kind == 'name':
        exact = [u for u in users if fold(to).lstrip('@') in _usernames(u)]
        candidates = exact or [u for u in users if name_matches(u, to)]
    else:
        candidates = [u for u in users if matches(u, kind, value)]
    if len(candidates) == 1:
        return candidates[0], False
    if not candidates and not allow:
        raise SkillError('recipient_not_found',
                         f"'{to}' was not found. A name is looked up only among the account's Telegram contacts; "
                         'someone outside them can be reached by @username.')
    allowed = [summary(u) for u in users]
    if not candidates:
        raise SkillError('recipient_not_allowed',
                         f"'{to}' is not among the allowed recipients. Only 'me' (Saved Messages) and the "
                         'contacts listed in ALLOWED_RECIPIENTS can be reached; the account owner can extend that list.',
                         allowed=allowed, unresolved=unresolved)
    raise SkillError('ambiguous_recipient', f"'{to}' matches several allowed recipients: ask which one.",
                     candidates=[summary(u) for u in candidates])


# ── Sending ──────────────────────────────────────────────────────────────────

def split_text(text, size=TEXT_CHUNK):
    """Splits on line breaks (or spaces) so no chunk exceeds `size` characters."""
    chunks, rest = [], text
    while len(rest) > size:
        cut = rest.rfind('\n', 0, size)
        if cut < size // 2:
            cut = rest.rfind(' ', 0, size)
        if cut < size // 2:
            cut = size
        chunks.append(rest[:cut].rstrip())
        rest = rest[cut:].lstrip('\n ')
    if rest:
        chunks.append(rest)
    return chunks


def throttle(config, sdir):
    """Keeps at least SEND_MIN_INTERVAL seconds between two sends (default 2)."""
    try:
        interval = max(0.0, float(config.get('SEND_MIN_INTERVAL', '2')))
    except ValueError:
        interval = 2.0
    stamp = sdir / 'last_send'
    try:
        last = float(stamp.read_text())
    except (FileNotFoundError, ValueError):
        last = 0.0
    wait = last + interval - time.time()
    if wait > 0:
        time.sleep(min(wait, interval))
    write_private(stamp, str(time.time()))
