#!/usr/bin/env python3
"""
telegram — read the latest messages of the conversation with an allowed
recipient (oldest first). Does not mark them as read.

Input:  {"from": "Maria", "limit": 10}
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (SkillError, StateLock, connect_authorized, resolve_recipient,
                       run, state_dir, summary)

MAX_LIMIT = 50


def media_kind(msg):
    if not msg.media:
        return None
    return type(msg.media).__name__.replace('MessageMedia', '').lower()


async def main(data, config):
    try:
        limit = int(data.get('limit') or 10)
    except (TypeError, ValueError):
        raise SkillError('bad_input', "'limit' must be a number.")
    limit = max(1, min(limit, MAX_LIMIT))

    sdir = state_dir(config)
    with StateLock(sdir):
        client = await connect_authorized(config, sdir)
        try:
            user, is_self = await resolve_recipient(client, config, sdir, data.get('from'))
            messages = await client.get_messages(user, limit=limit)
        finally:
            await client.disconnect()
    return {'with': summary(user, is_self=is_self),
            'messages': [{'id': m.id, 'date': m.date.isoformat() if m.date else None,
                          'from_me': bool(m.out), 'text': m.message or '', 'media': media_kind(m)}
                         for m in reversed(messages)]}


if __name__ == '__main__':
    run(main)
