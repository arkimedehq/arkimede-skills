#!/usr/bin/env python3
"""
telegram — the listener daemon: the account's one connection, kept open.

  - Private messages that arrive are handed to the host as a guest's turn and the
    agent's answer is sent back (Arkimede: POST /internal/guests/message, as the
    daemon's owner). Which ones, by ACCOUNT_MODE:
      dedicated  the account is the agent's own: every contact (and only the
                 allowlist, when ALLOWED_RECIPIENTS is set) is talking to it; the
                 AUTHORIZED_CONTACTS may have the agent do anything (the host is told:
                 `authorized`), every other contact gets answers only;
      personal   the account is the user's: only a reply to what the agent wrote —
                 a reply to one of its messages, or a message within
                 REPLY_WINDOW_HOURS of its last one to that person. Everything else
                 stays the user's own. A contact here is never authorized: answers only
                 (the user talks to the agent through the bot).
    Groups, channels, bots and the account's own messages are never handed over.
  - The scripts (send, read, delete…) do not connect while this runs: they put their
    request in the state directory's spool and this daemon runs it on its connection
    (tg_common.via_daemon). A heartbeat file tells them it is running.
  - No session yet: it waits for the owner's login; a new login (another session):
    it reconnects with it; logged out: it waits again.

Config: the skill's (stdin `_config`). Env from the host: BACKEND_INTERNAL_URL,
INTERNAL_TOKEN (the daemon's own token), SKILL_STATE_DIR.
"""

import asyncio
import fcntl
import importlib
import json
import os
import sys
import time
import urllib.error
import urllib.request

sys.path.insert(0, os.path.dirname(__file__))
import tg_common as tc  # noqa: E402

HEARTBEAT_S = 10
SPOOL_POLL_S = 0.2
GUEST_TIMEOUT_S = 300
CHANNEL = 'telegram'


def log(msg):
    sys.stderr.write(f'[telegram listen] {msg}\n')
    sys.stderr.flush()


# ── Which messages are for the agent ─────────────────────────────────────────

def authorized(config, sender):
    """Whether `sender` may have the agent act for them: an AUTHORIZED_CONTACTS entry of a
    dedicated account. Never in personal mode (the account is the user's: its contacts only get
    answers)."""
    if config.get('ACCOUNT_MODE', 'personal').lower() != 'dedicated':
        return False
    if getattr(sender, 'bot', False) or getattr(sender, 'is_self', False):
        return False
    trusted = tc.parse_allowlist(config.get('AUTHORIZED_CONTACTS'), 'AUTHORIZED_CONTACTS')
    return any(tc.matches(sender, kind, value) for kind, value, _ in trusted)


def admitted(config, sdir, sender, reply_to_id, now=None):
    """Whether a private message from `sender` goes to the agent (see the module doc)."""
    if getattr(sender, 'bot', False) or getattr(sender, 'is_self', False):
        return False
    if authorized(config, sender):
        return True
    allow = tc.parse_allowlist(config.get('ALLOWED_RECIPIENTS'))
    if allow and not any(tc.matches(sender, kind, value) for kind, value, _ in allow):
        return False
    if config.get('ACCOUNT_MODE', 'personal').lower() == 'dedicated':
        return bool(allow) or bool(getattr(sender, 'contact', False))
    sent = tc.sent_to(sdir, sender.id)
    if not sent:
        return False
    if reply_to_id and reply_to_id in sent.get('ids', []):
        return True
    try:
        window_h = float(config.get('REPLY_WINDOW_HOURS', '24'))
    except ValueError:
        window_h = 24.0
    return ((now if now is not None else time.time()) - float(sent.get('at', 0))) < window_h * 3600


def ask_host(sender, text, trusted=False):
    """The agent's answer to a guest's message (the host runs the turn), or None. `trusted`: an
    authorized contact — the agent may act for them; otherwise it only answers."""
    url = os.environ.get('BACKEND_INTERNAL_URL', 'http://localhost:3000').rstrip('/') + '/internal/guests/message'
    body = {'channel': CHANNEL, 'externalId': str(sender.id), 'displayName': tc.full_name(sender), 'text': text,
            'authorized': bool(trusted)}
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={
        'Content-Type': 'application/json', 'x-internal-token': os.environ.get('INTERNAL_TOKEN', '')})
    try:
        with urllib.request.urlopen(req, timeout=GUEST_TIMEOUT_S) as res:
            return (json.loads(res.read() or b'{}').get('answer') or '').strip() or None
    except urllib.error.HTTPError as exc:
        log(f'the host refused a guest message ({exc.code}): {exc.read()[:200]!r}')
    except Exception as exc:  # noqa: BLE001
        log(f'the host is not reachable: {exc}')
    return None


# ── Running the scripts' requests on this connection ─────────────────────────

class _Shared:
    """The daemon's client as a script sees it: the same connection, never closed by them."""

    def __init__(self, client):
        self._client = client

    def __getattr__(self, name):
        return getattr(self._client, name)

    async def __call__(self, *args, **kwargs):
        return await self._client(*args, **kwargs)

    async def disconnect(self):
        pass


class _NoLock:
    def __init__(self, *args, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


async def serve(client, request):
    """One spooled request → the script's JSON answer, run on this connection."""
    script = str(request.get('script') or '')
    if not script.replace('_', '').isalnum() or script in tc.LOCAL_ONLY or script == 'listen':
        return {'success': False, 'error': 'bad_input', 'message': f'Unknown script: {script}'}
    config = tc.Config(request.get('config') or {})
    if script == 'logout':
        return await logout(client, config)
    module = importlib.import_module(script)

    async def shared(_config, _sdir):
        return _Shared(client)

    # Requests run one at a time (the daemon's lock): patch the script for this one, then put it back.
    saved = module.connect_authorized, module.StateLock
    module.connect_authorized, module.StateLock = shared, _NoLock
    try:
        return await tc.run_main(module.main, request.get('data') or {}, config)
    finally:
        module.connect_authorized, module.StateLock = saved


async def logout(client, config):
    sdir = tc.state_dir(config)
    ended = bool(await client.log_out())
    for name in ('session', 'pending_login.json', 'peers.json', 'last_send', 'sent.json'):
        tc.remove_file(sdir / name)
    return {'success': True, 'logged_out': ended, 'message': 'Logged out.'}


async def spool_loop(client, sdir, busy):
    spool = tc.spool_dir(sdir)
    while client.is_connected():
        for req in sorted(spool.glob('*.req'), key=lambda p: p.stat().st_mtime):
            try:
                request = json.loads(req.read_text())
            except (OSError, json.JSONDecodeError):
                continue
            tc.remove_file(req)
            async with busy:
                try:
                    answer = await serve(client, request)
                except Exception as exc:  # noqa: BLE001
                    answer = tc.outcome(exc)
            tc.write_private(spool / (req.stem + '.res'), json.dumps(answer, ensure_ascii=False, default=str))
        await asyncio.sleep(SPOOL_POLL_S)


async def heartbeat_loop(client, config, sdir, session):
    beat = sdir / 'daemon.alive'
    while client.is_connected():
        beat.touch()
        if tc.load_session(config, sdir)[0] != session:  # a new login, or logged out
            log('the session changed: reconnecting')
            await client.disconnect()
            return
        await asyncio.sleep(HEARTBEAT_S)


# ── Main loop ────────────────────────────────────────────────────────────────

async def connected(config, sdir, session):
    from telethon import events
    from telethon.tl.types import User

    client = tc.make_client(config, session, receive_updates=True)
    await client.connect()
    if not await client.is_user_authorized():
        await client.disconnect()
        log('the session is not authorized: waiting for a new login')
        return False
    busy = asyncio.Lock()

    @client.on(events.NewMessage(incoming=True))
    async def on_message(event):
        if not event.is_private:
            return
        text = (event.raw_text or '').strip()
        sender = await event.get_sender()
        if not text or not isinstance(sender, User):
            return
        if not admitted(config, sdir, sender, getattr(event.message, 'reply_to_msg_id', None)):
            return
        answer = await asyncio.to_thread(ask_host, sender, text, authorized(config, sender))
        if not answer:
            return
        async with busy:
            ids = []
            for chunk in tc.split_text(answer):
                try:
                    ids.append((await client.send_message(sender, chunk, parse_mode='md', link_preview=False)).id)
                except Exception:  # noqa: BLE001 — markdown the parser rejects: plain text
                    ids.append((await client.send_message(sender, chunk, link_preview=False)).id)
            tc.record_sent(sdir, sender.id, ids)

    me = await client.get_me()
    log(f'connected as {tc.full_name(me)} ({config.get("ACCOUNT_MODE", "personal")} mode)')
    tasks = [asyncio.create_task(spool_loop(client, sdir, busy)),
             asyncio.create_task(heartbeat_loop(client, config, sdir, session))]
    try:
        await client.run_until_disconnected()
    finally:
        for t in tasks:
            t.cancel()
        tc.remove_file(sdir / 'daemon.alive')
    return True


async def main():
    data, config = tc.read_input()
    sdir = tc.state_dir(config)
    single = open(sdir / '.daemon', 'a+')
    try:
        fcntl.flock(single, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log('another listener is already running for this account')
        sys.exit(1)
    pause = 5
    while True:
        session, _ = tc.load_session(config, sdir)
        if not session:
            await asyncio.sleep(10)
            continue
        try:
            # Wait for a script still connected to finish, then hold the connection.
            with tc.StateLock(sdir, timeout=300):
                ok = await connected(config, sdir, session)
            pause = 5
            if not ok:
                await asyncio.sleep(30)
        except Exception as exc:  # noqa: BLE001 — keep listening through network failures
            log(f'disconnected ({type(exc).__name__}: {exc}); retrying in {pause}s')
            tc.remove_file(sdir / 'daemon.alive')
            await asyncio.sleep(pause)
            pause = min(pause * 2, 300)


if __name__ == '__main__':
    asyncio.run(main())
