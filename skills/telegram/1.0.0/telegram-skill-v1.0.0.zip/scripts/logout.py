#!/usr/bin/env python3
"""
telegram — log out (run by the account owner, not by the agent).

Ends the session on Telegram's side (it disappears from Settings → Devices) and
deletes it from the state directory.

Input:  {}
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (StateLock, load_session, make_client, remove_file, run,
                       state_dir)


async def main(data, config):
    sdir = state_dir(config)
    with StateLock(sdir):
        session, source = load_session(config, sdir)
        ended = False
        if session:
            client = make_client(config, session)
            await client.connect()
            try:
                if await client.is_user_authorized():
                    ended = await client.log_out()
            finally:
                if client.is_connected():
                    await client.disconnect()
        for name in ('session', 'pending_login.json', 'peers.json', 'last_send'):
            remove_file(sdir / name)

    message = 'Logged out.' if ended else 'No active session: local login data removed.'
    if source == 'config':
        message += ' The session came from TELEGRAM_SESSION: remove that value from the configuration too.'
    return {'logged_out': ended, 'message': message}


if __name__ == '__main__':
    run(main)
