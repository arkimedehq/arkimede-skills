"""Offline tests for the telegram skill: a fake Telegram client, no network.

Run from the skill folder, with telethon installed:  python3 -m unittest discover tests
"""

import asyncio
import importlib
import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

SCRIPTS = Path(__file__).resolve().parent.parent / 'scripts'
sys.path.insert(0, str(SCRIPTS))

import tg_common  # noqa: E402
from telethon import errors  # noqa: E402
from telethon.tl.functions.contacts import GetContactsRequest  # noqa: E402
from telethon.tl.types import User  # noqa: E402

ME = User(id=1, first_name='Andrea', username='andrea_me', access_hash=11)
MARIA = User(id=2, first_name='Maria', last_name='Rossi', username='mariar', phone='393331112222', access_hash=22)
MARIO = User(id=3, first_name='Mario', last_name='Bianchi', phone='393334445555', access_hash=33)
STRANGER = User(id=4, first_name='Luca', username='luca_x', access_hash=44)
PUBLIC = User(id=5, first_name='Nicola', username='nicola_pub', access_hash=55)


class FakeClient:
    """Stands in for TelegramClient; records what the scripts do."""
    instances = []
    authorized = True
    sign_in_plan = []          # exceptions (or None) raised by successive sign_in calls

    def __init__(self, session=''):
        self.session_in = session
        self.session = SimpleNamespace(save=lambda: 'SESSION-STRING')
        self.sent, self.files, self.connected = [], [], False
        self.entity_lookups = []
        FakeClient.instances.append(self)

    async def connect(self): self.connected = True
    async def disconnect(self): self.connected = False
    def is_connected(self): return self.connected
    async def is_user_authorized(self): return FakeClient.authorized
    async def get_me(self): return ME

    async def __call__(self, request):
        assert isinstance(request, GetContactsRequest)
        return SimpleNamespace(users=[MARIA, MARIO, STRANGER])

    async def get_entity(self, ref):
        self.entity_lookups.append(ref)
        if ref == 'nicola_pub' or getattr(ref, 'user_id', None) == 5:
            return PUBLIC
        raise ValueError('not found')

    async def send_message(self, user, text, **kw):
        self.sent.append((user.id, text, kw.get('parse_mode')))
        return SimpleNamespace(id=100 + len(self.sent))

    async def send_file(self, user, file, caption=None, **kw):
        self.files.append((user.id, file, caption))
        return SimpleNamespace(id=200 + len(self.files))

    async def get_messages(self, user, limit=None, ids=None):
        history = [SimpleNamespace(id=9, date=None, out=False, message='ciao', media=None),
                   SimpleNamespace(id=8, date=None, out=True, message='hey', media=None),
                   SimpleNamespace(id=7, date=None, out=True, message='old', media=None)]
        if ids is not None:
            by_id = {m.id: m for m in history}
            return [by_id.get(i) for i in ids]
        return history[:limit]

    async def delete_messages(self, user, ids, revoke=False):
        self.deleted = (user.id, list(ids), revoke)

    async def send_code_request(self, phone):
        self.code_phone = phone
        return SimpleNamespace(phone_code_hash='HASH', type=SimpleNamespace())

    async def sign_in(self, **kw):
        self.sign_in_args = kw
        exc = FakeClient.sign_in_plan.pop(0) if FakeClient.sign_in_plan else None
        if exc:
            raise exc
        FakeClient.authorized = True
        return ME

    async def log_out(self):
        self.connected = False
        return True


def load(name):
    mod = importlib.import_module(name)
    mod.make_client = lambda config, session='': FakeClient(session)
    return mod


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.sdir = Path(self.tmp.name)
        FakeClient.instances, FakeClient.authorized, FakeClient.sign_in_plan = [], True, []
        tg_common.make_client = lambda config, session='': FakeClient(session)
        self.cfg = {'TELEGRAM_API_ID': '123', 'TELEGRAM_API_HASH': 'h', 'TELEGRAM_STATE_DIR': self.tmp.name,
                    'ALLOWED_RECIPIENTS': '@mariar, +39 333 444 5555, @nicola_pub', 'SEND_MIN_INTERVAL': '0'}
        (self.sdir / 'session').write_text('SAVED')

    def tearDown(self):
        self.tmp.cleanup()

    def call(self, script, data, **cfg):
        mod = load(script)
        try:
            return {'success': True, **asyncio.run(mod.main(dict(data), tg_common.Config({**self.cfg, **cfg})))}
        except tg_common.SkillError as exc:
            return {'success': False, 'error': exc.code, 'message': exc.message, **exc.extra}


class AllowlistTests(unittest.TestCase):
    def test_parse(self):
        self.assertEqual(tg_common.parse_allowlist('@Maria_R; +39 333-111 2222\n12345, bob_smith, me'),
                         [('username', 'maria_r', '@Maria_R'), ('phone', '393331112222', '+39 333-111 2222'),
                          ('id', 12345, '12345'), ('username', 'bob_smith', 'bob_smith')])

    def test_rejects_free_text_entries(self):
        with self.assertRaises(tg_common.SkillError) as ctx:
            tg_common.parse_allowlist('Maria Rossi')
        self.assertEqual(ctx.exception.code, 'not_configured')

    def test_name_matching_ignores_accents_and_case(self):
        nico = User(id=9, first_name='Nicolò', last_name='Ferrà')
        self.assertTrue(tg_common.name_matches(nico, 'nicolo'))
        self.assertTrue(tg_common.name_matches(nico, 'NIC fer'))
        self.assertFalse(tg_common.name_matches(nico, 'maria'))

    def test_split_text(self):
        text = ('riga ' * 50 + '\n') * 40
        chunks = tg_common.split_text(text, 1000)
        self.assertTrue(all(len(c) <= 1000 for c in chunks))
        self.assertEqual(''.join(chunks).replace('\n', '').replace(' ', ''), text.replace('\n', '').replace(' ', ''))

    def test_proxy(self):
        self.assertEqual(tg_common.parse_proxy('socks5://u:p@h:1080'),
                         {'proxy_type': 'socks5', 'addr': 'h', 'port': 1080, 'rdns': True, 'username': 'u', 'password': 'p'})
        with self.assertRaises(tg_common.SkillError):
            tg_common.parse_proxy('ftp://h')

    def test_connection_proxy_falls_back_to_the_hosts_egress_proxy(self):
        egress = {'HTTPS_PROXY': 'http://egress-proxy:3128'}
        self.assertEqual(tg_common.connection_proxy({'TELEGRAM_PROXY': ''}, egress),
                         {'proxy_type': 'http', 'addr': 'egress-proxy', 'port': 3128, 'rdns': True})
        # The skill's own proxy wins; no proxy at all → a direct connection.
        self.assertEqual(tg_common.connection_proxy({'TELEGRAM_PROXY': 'socks5://h:1080'}, egress)['proxy_type'], 'socks5')
        self.assertIsNone(tg_common.connection_proxy({'TELEGRAM_PROXY': ''}, {}))

    def test_config_prefers_stdin_then_env(self):
        os.environ['TG_TEST_KEY'] = 'from-env'
        try:
            self.assertEqual(tg_common.Config({'TG_TEST_KEY': 'from-stdin'}).get('TG_TEST_KEY'), 'from-stdin')
            self.assertEqual(tg_common.Config({'TG_TEST_KEY': ''}).get('TG_TEST_KEY'), 'from-env')
        finally:
            del os.environ['TG_TEST_KEY']


class SendTests(Base):
    def test_send_by_name_to_allowed_contact(self):
        r = self.call('send_message', {'to': 'maria', 'text': 'ciao'})
        self.assertTrue(r['success'], r)
        self.assertEqual(r['sent_to'], {'id': 2, 'name': 'Maria Rossi', 'username': '@mariar'})
        self.assertEqual(FakeClient.instances[-1].sent, [(2, 'ciao', 'md')])
        self.assertFalse(FakeClient.instances[-1].connected)

    def test_send_by_phone_and_username(self):
        self.assertEqual(self.call('send_message', {'to': '+39 333 444 5555', 'text': 'x'})['sent_to']['id'], 3)
        self.assertEqual(self.call('send_message', {'to': '@MariaR', 'text': 'x'})['sent_to']['id'], 2)

    def test_contact_not_in_allowlist_is_refused(self):
        r = self.call('send_message', {'to': 'Luca', 'text': 'x'})
        self.assertEqual(r['error'], 'recipient_not_allowed')
        self.assertEqual(FakeClient.instances[-1].sent, [])
        r = self.call('send_message', {'to': '@luca_x', 'text': 'x'})
        self.assertEqual(r['error'], 'recipient_not_allowed')

    def test_empty_allowlist_allows_anyone(self):
        open_ = {'ALLOWED_RECIPIENTS': ''}
        r = self.call('send_message', {'to': 'me', 'text': 'nota'}, **open_)
        self.assertTrue(r['sent_to']['is_self'])
        # any contact, by name (Luca is outside the usual allowlist), phone or username
        self.assertEqual(self.call('send_message', {'to': 'luca', 'text': 'x'}, **open_)['sent_to']['id'], 4)
        self.assertEqual(self.call('send_message', {'to': '+39 333 111 2222', 'text': 'x'}, **open_)['sent_to']['id'], 2)
        self.assertEqual(self.call('send_message', {'to': '@luca_x', 'text': 'x'}, **open_)['sent_to']['id'], 4)
        # anyone else on Telegram by @username, but not by name
        self.assertEqual(self.call('send_message', {'to': '@nicola_pub', 'text': 'x'}, **open_)['sent_to']['id'], 5)
        r = self.call('send_message', {'to': 'nicola', 'text': 'x'}, **open_)
        self.assertEqual(r['error'], 'recipient_not_found')
        self.assertEqual(FakeClient.instances[-1].sent, [])
        self.assertEqual(self.call('send_message', {'to': 'mar', 'text': 'x'}, **open_)['error'], 'ambiguous_recipient')
        self.assertEqual(self.call('read_messages', {'from': 'luca'}, **open_)['messages'][0]['id'], 7)

    def test_ambiguous_name(self):
        r = self.call('send_message', {'to': 'mar', 'text': 'x'})
        self.assertEqual(r['error'], 'ambiguous_recipient')
        self.assertEqual({c['id'] for c in r['candidates']}, {2, 3})

    def test_username_outside_contacts_is_resolved_once_and_cached(self):
        self.assertEqual(self.call('send_message', {'to': 'nicola', 'text': 'x'})['sent_to']['id'], 5)
        self.assertEqual(FakeClient.instances[-1].entity_lookups, ['nicola_pub'])
        self.assertEqual(json.loads((self.sdir / 'peers.json').read_text()), {'nicola_pub': {'id': 5, 'access_hash': 55}})
        self.call('send_message', {'to': 'nicola', 'text': 'x'})
        self.assertEqual(getattr(FakeClient.instances[-1].entity_lookups[0], 'user_id', None), 5)

    def test_suffix_plain_and_chunks(self):
        r = self.call('send_message', {'to': 'me', 'text': 'a' * 5000, 'format': 'plain'}, MESSAGE_SUFFIX='— bot')
        sent = FakeClient.instances[-1].sent
        self.assertEqual(len(sent), 2)
        self.assertTrue(sent[-1][1].endswith('\n\n— bot'))
        self.assertIsNone(sent[0][2])
        self.assertEqual(len(r['message_ids']), 2)

    def test_file_with_caption_or_after_text(self):
        f = self.sdir / 'doc.pdf'
        f.write_bytes(b'%PDF')
        self.call('send_message', {'to': 'me', 'text': 'eccolo', 'file': str(f)})
        self.assertEqual(FakeClient.instances[-1].files, [(1, str(f), 'eccolo')])
        self.call('send_message', {'to': 'me', 'text': 'b' * 2000, 'file': str(f)})
        c = FakeClient.instances[-1]
        self.assertEqual((len(c.sent), c.files), (1, [(1, str(f), None)]))
        self.assertEqual(self.call('send_message', {'to': 'me', 'file': '/nope.pdf'})['error'], 'file_not_found')

    def test_not_logged_in_and_expired(self):
        (self.sdir / 'session').unlink()
        self.assertEqual(self.call('send_message', {'to': 'me', 'text': 'x'})['error'], 'not_logged_in')
        (self.sdir / 'session').write_text('SAVED')
        FakeClient.authorized = False
        self.assertEqual(self.call('send_message', {'to': 'me', 'text': 'x'})['error'], 'session_expired')

    def test_session_from_config_wins(self):
        self.call('send_message', {'to': 'me', 'text': 'x'}, TELEGRAM_SESSION='FROM-CONFIG')
        self.assertEqual(FakeClient.instances[-1].session_in, 'FROM-CONFIG')


class ChannelTests(Base):
    """The host's channel: an address it chooses, the user themself through the bot, the sent log."""

    def test_host_delivery_address_takes_the_place_of_to_and_is_logged(self):
        r = self.call('send_message', {'text': 'promemoria'}, DELIVERY_ADDRESS='@MariaR')
        self.assertEqual(r['sent_to']['id'], 2)
        self.assertEqual(tg_common.sent_to(self.sdir, 2)['ids'], r['message_ids'])
        r = self.call('send_message', {'to': 'me', 'text': 'x'}, DELIVERY_ADDRESS='@luca_x')
        self.assertEqual(r['error'], 'recipient_not_allowed')
        self.call('send_message', {'to': 'me', 'text': 'nota'})
        self.assertIsNone(tg_common.sent_to(self.sdir, 1))  # Saved Messages are nobody's reply

    def test_without_to_the_user_themself_through_the_bot_else_saved_messages(self):
        mod = load('send_message')
        calls = []
        mod._bot_call = lambda token, method, payload: (calls.append((method, payload)) or (True, {'ok': True}))
        sessions = json.dumps({'777': {'userId': 'u1', 'chats': {'777': 'chat-a'}}})
        cfg = tg_common.Config({**self.cfg, 'TELEGRAM_BOT_TOKEN': 't', 'TG_SESSIONS': sessions, 'ARKIMEDE_USER_ID': 'u1'})
        r = asyncio.run(mod.main({'text': 'ricordati'}, cfg))
        self.assertEqual(r['arkimede_chat'], 'chat-a')
        self.assertEqual(calls[0][1]['chat_id'], 777)
        self.assertEqual(FakeClient.instances, [])  # no account connection for it
        # Not linked to the bot: Saved Messages.
        r = self.call('send_message', {'text': 'ricordati'}, TELEGRAM_BOT_TOKEN='t', TG_SESSIONS=sessions, ARKIMEDE_USER_ID='u2')
        self.assertTrue(r['sent_to']['is_self'])


class ListenerTests(Base):
    """Which incoming messages go to the agent, and the scripts run on the listener's connection."""

    def setUp(self):
        super().setUp()
        self.listen = importlib.import_module('listen')

    def cfg_with(self, **kw):
        return tg_common.Config({**self.cfg, 'ALLOWED_RECIPIENTS': '', **kw})

    def test_dedicated_mode_takes_contacts_only_or_the_allowlist(self):
        contact = User(id=2, first_name='Maria', contact=True, access_hash=1)
        stranger = User(id=9, first_name='X', contact=False, access_hash=1)
        bot = User(id=8, first_name='B', bot=True, contact=True, access_hash=1)
        cfg = self.cfg_with(ACCOUNT_MODE='dedicated')
        self.assertTrue(self.listen.admitted(cfg, self.sdir, contact, None))
        self.assertFalse(self.listen.admitted(cfg, self.sdir, stranger, None))
        self.assertFalse(self.listen.admitted(cfg, self.sdir, bot, None))
        only_maria = self.cfg_with(ACCOUNT_MODE='dedicated', ALLOWED_RECIPIENTS='@mariar')
        self.assertTrue(self.listen.admitted(only_maria, self.sdir, MARIA, None))
        self.assertFalse(self.listen.admitted(only_maria, self.sdir, User(id=3, first_name='Mario', contact=True, access_hash=1), None))

    def test_authorized_contacts_only_in_dedicated_mode(self):
        contact = User(id=2, first_name='Maria', username='mariar', contact=True, access_hash=1)
        other = User(id=3, first_name='Mario', contact=True, access_hash=1)
        dedicated = self.cfg_with(ACCOUNT_MODE='dedicated', AUTHORIZED_CONTACTS='@mariar')
        self.assertTrue(self.listen.authorized(dedicated, contact))
        self.assertFalse(self.listen.authorized(dedicated, other))  # a generic contact: answers only
        self.assertTrue(self.listen.admitted(dedicated, self.sdir, other, None))
        # Personal mode: authorized too, but only what is meant for the agent reaches it.
        personal = self.cfg_with(ACCOUNT_MODE='personal', AUTHORIZED_CONTACTS='@mariar', AGENT_NAME='Arkimede, Archi')
        self.assertTrue(self.listen.authorized(personal, contact))
        self.assertTrue(self.listen.admitted(personal, self.sdir, contact, None, text='Arkimède, accendi la luce'))
        self.assertTrue(self.listen.admitted(personal, self.sdir, contact, None, text='archi spegni tutto'))
        self.assertFalse(self.listen.admitted(personal, self.sdir, contact, None, text='Arkimedeo è un nome?'))
        self.assertFalse(self.listen.admitted(personal, self.sdir, contact, None, text='ci vediamo stasera?'))  # yours
        # Only an authorized contact is admitted by the name; a generic one only by replying to the agent.
        self.assertFalse(self.listen.admitted(personal, self.sdir, other, None, text='Arkimede, accendi la luce'))
        # An authorized contact outside ALLOWED_RECIPIENTS is still admitted.
        narrow = self.cfg_with(ACCOUNT_MODE='dedicated', ALLOWED_RECIPIENTS='@someone', AUTHORIZED_CONTACTS='@mariar')
        self.assertTrue(self.listen.admitted(narrow, self.sdir, contact, None))
        with self.assertRaises(tg_common.SkillError):
            self.listen.authorized(self.cfg_with(ACCOUNT_MODE='dedicated', AUTHORIZED_CONTACTS='not a handle!'), contact)

    def test_personal_mode_takes_only_replies_to_the_agent(self):
        cfg = self.cfg_with(ACCOUNT_MODE='personal', REPLY_WINDOW_HOURS='24')
        now = 1_000_000.0
        self.assertFalse(self.listen.admitted(cfg, self.sdir, MARIA, None, now=now))  # the agent never wrote to her
        tg_common.record_sent(self.sdir, 2, [41, 42], now=now)
        self.assertTrue(self.listen.admitted(cfg, self.sdir, MARIA, None, now=now + 3600))
        self.assertFalse(self.listen.admitted(cfg, self.sdir, MARIA, None, now=now + 25 * 3600))
        self.assertTrue(self.listen.admitted(cfg, self.sdir, MARIA, 42, now=now + 25 * 3600))  # a reply to its message

    def test_a_script_runs_on_the_listeners_connection_through_the_spool(self):
        client = FakeClient('SAVED')
        request = {'script': 'send_message', 'data': {'to': 'maria', 'text': 'ciao'}, 'config': {**self.cfg}}
        r = asyncio.run(self.listen.serve(client, request))
        self.assertTrue(r['success'], r)
        self.assertEqual(client.sent, [(2, 'ciao', 'md')])
        self.assertEqual(len(FakeClient.instances), 1)  # no second connection
        for bad in ('login_finish', '../x', 'listen'):
            self.assertEqual(asyncio.run(self.listen.serve(client, {'script': bad}))['error'], 'bad_input')

    def test_via_daemon_round_trip(self):
        spool = tg_common.spool_dir(self.sdir)

        def answer():
            import threading, time as t
            def work():
                for _ in range(100):
                    reqs = list(spool.glob('*.req'))
                    if reqs:
                        req = json.loads(reqs[0].read_text())
                        reqs[0].unlink()
                        tg_common.write_private(spool / (reqs[0].stem + '.res'), json.dumps({'success': True, 'echo': req['script'], 'cfg': req['config'].get('DELIVERY_ADDRESS')}))
                        return
                    t.sleep(0.02)
            threading.Thread(target=work).start()
        answer()
        r = tg_common.via_daemon(self.sdir, 'send_message', {'text': 'x'}, tg_common.Config({'DELIVERY_ADDRESS': '42'}), timeout=5)
        self.assertEqual(r, {'success': True, 'echo': 'send_message', 'cfg': '42'})
        self.assertEqual(list(spool.iterdir()), [])
        self.assertFalse(tg_common.daemon_alive(self.sdir))
        (self.sdir / 'daemon.alive').touch()
        self.assertTrue(tg_common.daemon_alive(self.sdir))


class DeleteTests(Base):
    def test_withdraws_the_last_own_message_by_default(self):
        r = self.call('delete_message', {'to': 'maria'})
        self.assertTrue(r['success'], r)
        self.assertEqual(FakeClient.instances[-1].deleted, (2, [8], True))

    def test_only_own_messages_by_id(self):
        r = self.call('delete_message', {'to': 'maria', 'message_ids': [9, 7, 42]})
        self.assertEqual(r['deleted_ids'], [7])
        self.assertEqual(r['skipped_ids'], [9, 42])
        r = self.call('delete_message', {'to': 'maria', 'message_ids': [9]})
        self.assertEqual(r['error'], 'nothing_to_delete')

    def test_respects_the_allowlist_and_input(self):
        self.assertEqual(self.call('delete_message', {'to': 'luca'})['error'], 'recipient_not_allowed')
        self.assertEqual(self.call('delete_message', {'to': 'maria', 'message_ids': 'x'})['error'], 'bad_input')


class ReadAndFindTests(Base):
    def test_read_messages_oldest_first_and_allowlisted(self):
        r = self.call('read_messages', {'from': 'maria', 'limit': 500})
        self.assertEqual([m['id'] for m in r['messages']], [7, 8, 9])
        self.assertEqual(r['messages'][0]['from_me'], True)
        self.assertEqual(self.call('read_messages', {'from': 'luca'})['error'], 'recipient_not_allowed')

    def test_find_contact_never_lists_other_contacts(self):
        r = self.call('find_contact', {})
        self.assertEqual({c['id'] for c in r['contacts']}, {2, 3, 5})
        self.assertEqual([c['id'] for c in self.call('find_contact', {'query': 'bianchi'})['contacts']], [3])

    def test_open_mode_find_and_status(self):
        r = self.call('find_contact', {}, ALLOWED_RECIPIENTS='')
        self.assertEqual({c['id'] for c in r['contacts']}, {2, 3, 4})
        self.assertTrue(r['open'])
        self.assertEqual([c['id'] for c in self.call('find_contact', {'query': 'luca'}, ALLOWED_RECIPIENTS='')['contacts']], [4])
        self.assertEqual(self.call('status', {}, ALLOWED_RECIPIENTS='')['allowed_recipients'], 'all')

    def test_status_reports_unresolved_entries(self):
        r = self.call('status', {}, ALLOWED_RECIPIENTS='@mariar, @ghost_user')
        self.assertTrue(r['logged_in'])
        self.assertEqual(r['unresolved_entries'], ['@ghost_user'])
        (self.sdir / 'session').unlink()
        self.assertFalse(self.call('status', {})['logged_in'])


class LoginTests(Base):
    def setUp(self):
        super().setUp()
        (self.sdir / 'session').unlink()
        FakeClient.authorized = False

    def mode(self, name):
        return oct((self.sdir / name).stat().st_mode & 0o777)

    def test_login_code_only(self):
        r = self.call('login_start', {'phone': '+39 333 000 1111'})
        self.assertTrue(r['success'], r)
        self.assertEqual(FakeClient.instances[-1].code_phone, '+393330001111')
        self.assertEqual(self.mode('pending_login.json'), '0o600')
        r = self.call('login_finish', {'code': '12 345'})
        self.assertTrue(r['success'], r)
        self.assertEqual(FakeClient.instances[-1].sign_in_args['code'], '12345')
        self.assertEqual((self.sdir / 'session').read_text(), 'SESSION-STRING')
        self.assertEqual(self.mode('session'), '0o600')
        self.assertFalse((self.sdir / 'pending_login.json').exists())
        self.assertNotIn('SESSION-STRING', json.dumps(r))

    def test_login_with_two_step_password_in_two_calls(self):
        self.call('login_start', {'phone': '+393330001111'})
        FakeClient.sign_in_plan = [errors.SessionPasswordNeededError(request=None)]
        self.assertEqual(self.call('login_finish', {'code': '12345'})['error'], 'password_required')
        FakeClient.sign_in_plan = [errors.PasswordHashInvalidError(request=None)]
        self.assertEqual(self.call('login_finish', {'password': 'bad'})['error'], 'password_invalid')
        r = self.call('login_finish', {'password': 'good'})
        self.assertTrue(r['success'], r)
        self.assertEqual(FakeClient.instances[-1].sign_in_args, {'password': 'good'})

    def test_wrong_code_keeps_the_login_open(self):
        self.call('login_start', {'phone': '+393330001111'})
        FakeClient.sign_in_plan = [errors.PhoneCodeInvalidError(request=None)]
        self.assertEqual(self.call('login_finish', {'code': '1'})['error'], 'code_invalid')
        self.assertTrue(self.call('login_finish', {'code': '12345'})['success'])

    def test_guards(self):
        self.assertEqual(self.call('login_finish', {'code': '1'})['error'], 'no_pending_login')
        self.assertEqual(self.call('login_start', {'phone': '333'})['error'], 'bad_input')
        self.assertEqual(self.call('login_start', {'phone': '+393330001111'}, TELEGRAM_SESSION='X')['error'],
                         'session_in_config')
        (self.sdir / 'session').write_text('SAVED')
        FakeClient.authorized = True
        self.assertEqual(self.call('login_start', {'phone': '+393330001111'})['error'], 'already_logged_in')

    def test_logout_removes_local_state(self):
        (self.sdir / 'session').write_text('SAVED')
        FakeClient.authorized = True
        r = self.call('logout', {})
        self.assertTrue(r['logged_out'])
        self.assertFalse((self.sdir / 'session').exists())


class ContractTests(unittest.TestCase):
    """The real script, as any agent runs it: JSON in on stdin, JSON out on stdout."""

    def run_script(self, name, payload, env=None):
        proc = subprocess.run([sys.executable, str(SCRIPTS / name)], input=json.dumps(payload), text=True,
                              capture_output=True, env={**os.environ, **(env or {})}, timeout=60)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        lines = proc.stdout.strip().splitlines()
        self.assertEqual(len(lines), 1, proc.stdout)
        return json.loads(lines[0])

    def test_missing_api_credentials(self):
        with tempfile.TemporaryDirectory() as d:
            r = self.run_script('login_start.py', {'phone': '+393330001111', '_config': {'TELEGRAM_STATE_DIR': d}})
        self.assertEqual(r['error'], 'not_configured')

    def test_not_logged_in_via_env_config(self):
        with tempfile.TemporaryDirectory() as d:
            r = self.run_script('send_message.py', {'to': 'me', 'text': 'x'},
                                env={'TELEGRAM_API_ID': '1', 'TELEGRAM_API_HASH': 'h', 'TELEGRAM_STATE_DIR': d,
                                     'TELEGRAM_SESSION': ''})
        self.assertEqual(r['error'], 'not_logged_in')

    def test_bad_stdin(self):
        proc = subprocess.run([sys.executable, str(SCRIPTS / 'status.py')], input='not json', text=True,
                              capture_output=True, timeout=60)
        self.assertEqual(json.loads(proc.stdout)['error'], 'bad_input')


if __name__ == '__main__':
    unittest.main()
