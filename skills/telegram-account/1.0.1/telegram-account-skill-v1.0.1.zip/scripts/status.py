#!/usr/bin/env python3
"""
telegram-account — status: whether an account is linked, as whom, and which
recipients are allowed (all of them when ALLOWED_RECIPIENTS is empty).

Input:  {}
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (SkillError, StateLock, connect_authorized, parse_allowlist,
                       resolve_allowed, run, state_dir, summary)


async def main(data, config):
    sdir = state_dir(config)
    with StateLock(sdir):
        try:
            client = await connect_authorized(config, sdir)
        except SkillError as exc:
            if exc.code in ('not_logged_in', 'session_expired'):
                return {'logged_in': False, 'message': exc.message}
            raise
        try:
            me = await client.get_me()
            allow = parse_allowlist(config.get('ALLOWED_RECIPIENTS'))
            users, unresolved = await resolve_allowed(client, sdir, allow) if allow else ([], [])
        finally:
            await client.disconnect()
    if not allow:
        return {'logged_in': True, 'account': summary(me, is_self=True), 'allowed_recipients': 'all',
                'note': 'ALLOWED_RECIPIENTS is empty: any contact can be reached, and anyone else by @username.'}
    return {'logged_in': True, 'account': summary(me, is_self=True),
            'allowed_recipients': [summary(u) for u in users], 'unresolved_entries': unresolved}


if __name__ == '__main__':
    run(main)
