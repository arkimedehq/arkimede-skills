#!/usr/bin/env python3
"""
telegram-account — find an allowed recipient by name or username.

Searches only the recipients the account owner allowed (ALLOWED_RECIPIENTS), so
the rest of the address book is never exposed. Without a query it lists them.
With an empty ALLOWED_RECIPIENTS (open mode) it searches the whole address book.

Input:  {"query": "maria"}
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (StateLock, address_book, connect_authorized, name_matches, parse_allowlist,
                       resolve_allowed, run, state_dir, summary)

MAX_LISTED = 50


async def main(data, config):
    query = str(data.get('query') or '').strip()
    allow = parse_allowlist(config.get('ALLOWED_RECIPIENTS'))
    sdir = state_dir(config)
    with StateLock(sdir):
        client = await connect_authorized(config, sdir)
        try:
            if allow:
                users, unresolved = await resolve_allowed(client, sdir, allow)
            else:
                users, unresolved = await address_book(client), []
        finally:
            await client.disconnect()
    found = [summary(u) for u in users if not query or name_matches(u, query)]
    if not allow:
        return {'contacts': found[:MAX_LISTED], 'more': max(0, len(found) - MAX_LISTED), 'open': True,
                'note': "No allowlist: any contact can be reached, and anyone else by @username. "
                        "'me' (the account's own Saved Messages) works too."}
    return {'contacts': found, 'unresolved_entries': unresolved,
            'note': "'me' (the account's own Saved Messages) is always allowed too."}


if __name__ == '__main__':
    run(main)
