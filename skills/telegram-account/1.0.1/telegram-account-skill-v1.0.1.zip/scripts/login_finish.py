#!/usr/bin/env python3
"""
telegram-account — login, step 2 of 2 (run by the account owner, not by the agent).

Completes the login started by login_start with the code Telegram sent. If the
account has two-step verification, pass its password too (in the same call, or
in a second call after a "password_required" answer). The session is saved in
the state directory with mode 600 and never printed.

Input:  {"code": "12345", "password": "optional 2FA password"}
"""

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (PENDING_TTL_S, SkillError, StateLock, make_client,
                       remove_file, run, state_dir, summary, write_private)


async def main(data, config):
    from telethon.errors import (PasswordHashInvalidError, PhoneCodeExpiredError,
                                 PhoneCodeInvalidError, SessionPasswordNeededError)

    sdir = state_dir(config)
    pending_file = sdir / 'pending_login.json'
    code = ''.join(ch for ch in str(data.get('code') or '') if ch.isdigit())
    password = str(data.get('password') or '')

    with StateLock(sdir):
        try:
            pending = json.loads(pending_file.read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            raise SkillError('no_pending_login', 'No login in progress: run login_start first.')
        if time.time() - pending.get('created', 0) > PENDING_TTL_S:
            remove_file(pending_file)
            raise SkillError('code_expired', 'The login code has expired: run login_start again.')

        client = make_client(config, pending['session'])
        await client.connect()
        try:
            if pending.get('stage') == 'code':
                if not code:
                    raise SkillError('bad_input', "'code' is required: the login code Telegram sent you.")
                try:
                    await client.sign_in(phone=pending['phone'], code=code,
                                         phone_code_hash=pending['phone_code_hash'])
                except PhoneCodeInvalidError:
                    raise SkillError('code_invalid', 'Wrong code: check it and run login_finish again.')
                except PhoneCodeExpiredError:
                    remove_file(pending_file)
                    raise SkillError('code_expired', 'The login code has expired: run login_start again.')
                except SessionPasswordNeededError:
                    pending.update(stage='password', session=client.session.save())
                    write_private(pending_file, json.dumps(pending))
                    if not password:
                        raise SkillError('password_required',
                                         'The code is right, but the account has two-step verification: '
                                         'run login_finish again with your Telegram password.')
            if not await client.is_user_authorized():
                if not password:
                    raise SkillError('password_required', 'Run login_finish again with your Telegram password.')
                try:
                    await client.sign_in(password=password)
                except PasswordHashInvalidError:
                    raise SkillError('password_invalid', 'Wrong two-step verification password: try again.')

            me = await client.get_me()
            write_private(sdir / 'session', client.session.save())
            remove_file(pending_file)
            remove_file(sdir / 'peers.json')
        finally:
            await client.disconnect()

    return {'account': summary(me, is_self=True),
            'message': f'Logged in as {summary(me)["name"]}. The agent can now use this Telegram account.'}


if __name__ == '__main__':
    run(main)
