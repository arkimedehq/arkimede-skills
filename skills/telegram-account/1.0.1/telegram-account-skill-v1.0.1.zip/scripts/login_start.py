#!/usr/bin/env python3
"""
telegram-account — login, step 1 of 2 (run by the account owner, not by the agent).

Asks Telegram to send a login code for `phone`. The code arrives in the Telegram
app (or by SMS); pass it to login_finish within a few minutes.

Input:  {"phone": "+39 333 1234567", "force": false}
"""

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (SkillError, StateLock, load_session, make_client, run,
                       state_dir, write_private)


async def main(data, config):
    phone = ''.join(ch for ch in str(data.get('phone') or '') if ch.isdigit() or ch == '+')
    if not phone.startswith('+') or len(phone) < 8:
        raise SkillError('bad_input', "'phone' must be the account's number in international format, e.g. +39 333 1234567.")
    sdir = state_dir(config)
    if config.get('TELEGRAM_SESSION'):
        raise SkillError('session_in_config',
                         'TELEGRAM_SESSION is set in the configuration and takes precedence over a login: '
                         'clear it first if you want to log in here.')
    with StateLock(sdir):
        session, _ = load_session(config, sdir)
        force = str(data.get('force', '')).strip().lower() in ('true', '1', 'yes')
        if session and not force:
            client = make_client(config, session)
            await client.connect()
            try:
                if await client.is_user_authorized():
                    raise SkillError('already_logged_in',
                                     'An account is already linked. Run logout first, or pass "force": true to replace it.')
            finally:
                await client.disconnect()

        client = make_client(config)
        await client.connect()
        try:
            sent = await client.send_code_request(phone)
            pending = {'phone': phone, 'phone_code_hash': sent.phone_code_hash,
                       'session': client.session.save(), 'stage': 'code', 'created': time.time()}
            write_private(sdir / 'pending_login.json', json.dumps(pending))
        finally:
            await client.disconnect()

    where = type(sent.type).__name__.replace('SentCodeType', '').lower() or 'app'
    return {'code_sent_via': where,
            'message': 'Telegram sent a login code (look in the Telegram app on your other devices, '
                       'or in your SMS). Run login_finish with that code within a few minutes.'}


if __name__ == '__main__':
    run(main)
