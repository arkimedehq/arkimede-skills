#!/usr/bin/env python3
"""
telegram-account — find an allowed recipient by name or username.

Searches only the recipients the account owner allowed (ALLOWED_RECIPIENTS), so
the rest of the address book is never exposed. Without a query it lists them.

Input:  {"query": "maria"}
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (StateLock, connect_authorized, name_matches, parse_allowlist,
                       resolve_allowed, run, state_dir, summary)


async def main(data, config):
    query = str(data.get('query') or '').strip()
    sdir = state_dir(config)
    with StateLock(sdir):
        client = await connect_authorized(config, sdir)
        try:
            users, unresolved = await resolve_allowed(client, sdir, parse_allowlist(config.get('ALLOWED_RECIPIENTS')))
        finally:
            await client.disconnect()
    found = [summary(u) for u in users if not query or name_matches(u, query)]
    return {'contacts': found, 'unresolved_entries': unresolved,
            'note': "'me' (the account's own Saved Messages) is always allowed too."}


if __name__ == '__main__':
    run(main)
