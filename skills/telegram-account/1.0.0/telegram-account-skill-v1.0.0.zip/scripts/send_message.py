#!/usr/bin/env python3
"""
telegram-account — send a message from the linked Telegram account.

The recipient must be 'me' (Saved Messages) or one of ALLOWED_RECIPIENTS; it can
be designated by @username, +phone, numeric id or name. Long texts are split;
an optional file is sent as a document, with the text as caption when it fits.

Input:  {"to": "Maria", "text": "…", "file": "/path/to/file.pdf", "format": "markdown|plain"}
"""

import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from tg_common import (CAPTION_MAX, SkillError, StateLock, connect_authorized,
                       resolve_recipient, run, split_text, state_dir, summary,
                       throttle)


async def main(data, config):
    text = str(data.get('text') or '').strip()
    file = str(data.get('file') or '').strip()
    if not text and not file:
        raise SkillError('bad_input', "Give 'text', 'file' or both.")
    if file and not os.path.isfile(file):
        raise SkillError('file_not_found', f'File not found: {file}')
    suffix = config.get('MESSAGE_SUFFIX')
    if suffix and text:
        text = f'{text}\n\n{suffix}'
    parse_mode = None if str(data.get('format') or '').lower() == 'plain' else 'md'

    sdir = state_dir(config)
    with StateLock(sdir):
        client = await connect_authorized(config, sdir)
        try:
            user, is_self = await resolve_recipient(client, config, sdir, data.get('to'))
            throttle(config, sdir)
            ids = []
            if file and len(text) <= CAPTION_MAX:
                msg = await client.send_file(user, file, caption=text or None, parse_mode=parse_mode,
                                             force_document=True)
                ids.append(msg.id)
            else:
                for chunk in split_text(text):
                    ids.append((await client.send_message(user, chunk, parse_mode=parse_mode,
                                                          link_preview=False)).id)
                if file:
                    ids.append((await client.send_file(user, file, force_document=True)).id)
        finally:
            await client.disconnect()
    return {'sent_to': summary(user, is_self=is_self), 'message_ids': ids,
            'message': f'Message delivered on Telegram to {summary(user)["name"]}.'}


if __name__ == '__main__':
    run(main)
