# Coverage Check Skill

Analizza la **copertura funzionale** di un insieme di elementi rispetto a zone configurabili.
Supporta più profili di analisi (es. "negozio", "ristorante") — una sola installazione per
tutti i domini. Si integra opzionalmente con **als-recommender** per suggerimenti ML,
rilevamento anomalie per zona e profilo del cluster di appartenenza.

---

## Indice

- [Quando usarla](#quando-usarla)
- [Come funziona](#come-funziona)
- [Configurazione](#configurazione)
  - [PROFILES_CONFIG](#profiles_config)
  - [Variabili globali](#variabili-globali)
- [Utilizzo](#utilizzo)
  - [zones.py — scopri la configurazione](#1-zonesly--scopri-la-configurazione)
  - [analyze.py — analizza la copertura](#2-analyzepy--analizza-la-copertura)
- [Integrazione con als-recommender](#integrazione-con-als-recommender)
- [Invocazione da un'altra skill](#invocazione-da-unaltra-skill-inter-skill-bus)
- [Note tecniche](#note-tecniche)

---

## Quando usarla

- Verificare se un progetto/ordine/configurazione copre tutte le aree funzionali attese
- Rispondere a "cosa manca?", "siamo completi?", "qual è la copertura?"
- Rilevare elementi fuori contesto o anomalie di composizione
- Ottenere suggerimenti ML su cosa aggiungere alle zone mancanti

**Requisito:** `PROFILES_CONFIG` configurato dal pannello della skill.

---

## Come funziona

```
Input: rows (elementi) + profile + context + [subject_id]
         │
         ▼
  1. Risolve il profilo → zone + mapping + parametri ALS
         │
         ▼
  2. Classifica ogni elemento:
     mapping esatto (column_object → zona) → keyword matching → non classificato
         │
         ▼
  3. Valuta copertura per zona:
     • complete   → zone con ≥ min_items elementi
     • missing    → zone obbligatorie (required/required_if) senza elementi
     • optional_missing → zone opzionali senza elementi
         │
         ▼
  4. Score = zones_covered / zones_required × 100
         │
         ▼
  5. (opzionale, se ALS_SKILL_ID configurato)
     • recommend.py o similar.py → als_suggestions
     • cluster_profiles.py       → cluster_profile
     • anomalies.py per zona     → zone_anomalies
```

---

## Configurazione

### PROFILES_CONFIG

JSON con uno o più profili. Ogni profilo definisce colonne, parametri ALS, zone e mapping.

```json
{
  "negozio": {
    "column_subject": "cod_negozio",
    "column_id":      "cod_articolo",
    "column_name":    "descrizione",
    "column_object":  "categoria",

    "als_skill_id":          "UUID-als-recommender",
    "als_model_name":        "negozio",
    "als_top_n":             6,
    "als_suggest_mode":      "recommend",
    "als_anomaly_check":     true,
    "als_anomaly_threshold": 0.1,

    "zones": {
      "bancone": {
        "label":    "Bancone / Cassa",
        "icon":     "🏪",
        "required": true,
        "min_items": 1,
        "hint":     "bancone cassa checkout registratore",
        "keywords": ["bancone", "banco", "cassa", "checkout"]
      },
      "scaffalature": {
        "label":    "Scaffalature / Espositori",
        "icon":     "📦",
        "required": true,
        "min_items": 1,
        "hint":     "scaffale espositore gondola ripiano",
        "keywords": ["scaffal", "espositore", "gondola", "ripiano"]
      },
      "illuminazione": {
        "label":    "Illuminazione",
        "icon":     "💡",
        "required": false,
        "required_if": { "field": "mq", "op": "gte", "value": 30 },
        "min_items": 1,
        "hint":     "illuminazione led luce plafoniera",
        "keywords": ["illumin", "led", "luce", "plafoniera", "faretto"]
      },
      "cassa_self": {
        "label":    "Cassa Self-Service",
        "icon":     "🤖",
        "required": false,
        "required_if": {
          "logic": "and",
          "rules": [
            { "field": "mq",   "op": "gte", "value": 100 },
            { "field": "tipo", "op": "eq",  "value": "flagship" }
          ]
        },
        "min_items": 1,
        "hint":     "cassa automatica self service totem pagamento",
        "keywords": ["self", "automatica", "totem pagamento"]
      }
    },

    "mapping": {
      "Bancone Principale":    "bancone",
      "Banco Cassa":           "bancone",
      "Scaffalature Centrali": "scaffalature",
      "Gondole":               "scaffalature",
      "Illuminazione LED":     "illuminazione",
      "Plafoniere":            "illuminazione",
      "Cassa Automatica":      "cassa_self"
    }
  },

  "ristorante": {
    "column_subject": "id_ristorante",
    "column_id":      "id_elemento",
    "column_name":    "descrizione",
    "column_object":  "tipo_arredo",
    "als_model_name": "ristorante",
    "zones": {
      "cucina": {
        "label": "Zona Cucina", "icon": "👨‍🍳",
        "required": true, "min_items": 1,
        "hint": "piano cottura forno cucina",
        "keywords": ["cottura", "forno", "cucina", "frigo", "lavello"]
      },
      "sala": {
        "label": "Zona Sala", "icon": "🪑",
        "required": true, "min_items": 2,
        "hint": "tavolo sedia poltrona sala",
        "keywords": ["tavolo", "sedia", "poltrona", "sala"]
      }
    },
    "mapping": {
      "Piano Cottura Induzione": "cucina",
      "Forno Professionale":     "cucina",
      "Tavoli Quadrati":         "sala",
      "Sedie Impilabili":        "sala"
    }
  }
}
```

#### Schema di ogni zona

| Campo | Tipo | Descrizione |
|---|---|---|
| `label` | string | Nome leggibile nel report |
| `icon` | string | Emoji opzionale |
| `required` | bool | Zona sempre obbligatoria |
| `required_if` | object | Condizione contestuale per renderla obbligatoria |
| `min_items` | number | Minimo elementi per considerare la zona coperta (default: 1) |
| `hint` | string | Testo usato come seed ALS quando non ci sono elementi classificati |
| `keywords` | array | Parole chiave per keyword matching su `column_name` |

#### Operatori `required_if`

```json
// Condizione singola
{ "field": "mq", "op": "gte", "value": 40 }

// Condizioni multiple
{ "logic": "and", "rules": [
    { "field": "mq",   "op": "gte", "value": 100 },
    { "field": "tipo", "op": "eq",  "value": "flagship" }
]}
```

Operatori: `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `in`, `nin`, `contains`

### Variabili globali

Tutte sovrascrivibili per-profilo in `PROFILES_CONFIG`.

| Chiave | Default | Descrizione |
|---|---|---|
| `DEFAULT_PROFILE` | `default` | Profilo usato quando non specificato nell'input |
| `COLUMN_SUBJECT` | `""` | Colonna soggetto (es. id negozio/progetto/utente) — esposta in `columns.subject`, usata per auto-estrarre `subject_id` |
| `COLUMN_ID` | `id` | Colonna identificatore univoco elemento |
| `COLUMN_NAME` | `name` | Colonna descrizione testuale (per keyword matching) |
| `COLUMN_OBJECT` | `object` | Colonna oggetto (per mapping esatto e ALS seed) |
| `ALS_SKILL_ID` | `""` | UUID della skill als-recommender |
| `ALS_MODEL_NAME` | `default` | Nome modello ALS globale |
| `ALS_TOP_N` | `6` | Max suggerimenti ML |
| `ALS_SUGGEST_MODE` | `recommend` | `recommend` o `similar` |
| `ALS_ANOMALY_CHECK` | `false` | Attiva anomaly detection per zona |
| `ALS_ANOMALY_THRESHOLD` | `0.1` | Soglia anomalia 0.0–1.0 |

---

## Utilizzo

### 1. `zones.py` — scopri la configurazione

Chiama sempre `zones.py` **prima** di costruire la query SQL o chiamare `analyze.py`.
Restituisce le colonne esatte che `analyze.py` si aspetta — usale come alias `AS`.

```json
{ "profile": "negozio" }
```

Risposta:
```json
{
  "columns": {
    "subject": "cod_negozio",
    "id":      "cod_articolo",
    "name":    "descrizione",
    "object":  "categoria"
  },
  "zones": [...],
  "als_model_name": "negozio"
}
```

> **`columns.subject`** — includi sempre questa colonna nel `SELECT` come alias `AS`:
> `analyze.py` la usa per estrarre automaticamente `subject_id` da `rows[0]`
> senza che il LLM debba passarlo esplicitamente.

### 2. `analyze.py` — analizza la copertura

#### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|---|---|:---:|---|
| `rows` | array | ✅ | Elementi da analizzare (output SQL tool) |
| `profile` | string | ❌ | Profilo da usare. Default: `DEFAULT_PROFILE` |
| `context` | object | ❌ | Valori per `required_if` (es. `{"mq": 80, "tipo": "flagship"}`) |
| `subject_id` | string | ❌ | ID soggetto nel modello ALS. Se fornito, i suggerimenti usano il vettore soggetto salvato dal training (più preciso dei seed). Ignorato in modalità `similar`. |

#### Query SQL tipica

```sql
SELECT
  n.codice    AS cod_negozio,    -- ← columns.subject → subject_id auto-estratto
  e.codice    AS cod_articolo,   -- ← columns.id
  e.des_breve AS descrizione,    -- ← columns.name
  c.nome      AS categoria       -- ← columns.object
FROM elementi e
LEFT JOIN categorie c ON c.id = e.id_cat
LEFT JOIN negozi n    ON n.id = e.id_negozio
WHERE n.codice = 'N042'
```

#### Chiamata completa

```json
{
  "profile": "negozio",
  "rows": [
    { "cod_negozio": "N042", "cod_articolo": "ART001", "descrizione": "Bancone 200cm", "categoria": "Bancone Principale" },
    { "cod_negozio": "N042", "cod_articolo": "ART002", "descrizione": "LED Strip 3m",  "categoria": "Illuminazione LED"  }
  ],
  "context": { "mq": 80, "tipo": "standard" }
}
```
> `subject_id` viene estratto automaticamente da `rows[0]["cod_negozio"]` → `"N042"`.
```

#### Output completo

```json
{
  "success": true,
  "profile": "negozio",
  "score": 67,
  "zones_required": 3,
  "zones_covered": 2,

  "complete": [
    { "zone": "bancone",      "label": "🏪 Bancone / Cassa",   "count": 1, "examples": ["Bancone 200cm"] },
    { "zone": "illuminazione","label": "💡 Illuminazione",      "count": 1, "examples": ["LED Strip 3m"] }
  ],

  "missing": [
    { "zone": "scaffalature", "label": "📦 Scaffalature", "hint": "scaffale espositore gondola" }
  ],

  "optional_missing": [
    { "zone": "cassa_self", "label": "🤖 Cassa Self-Service", "hint": "cassa automatica self service" }
  ],

  "unclassified": [
    { "id": "ART099", "name": "Elemento Sconosciuto", "object": null }
  ],

  "als_suggestions": [
    { "object": "Scaffalature Centrali", "score": 0.89 },
    { "object": "Gondole",              "score": 0.74 }
  ],
  "als_source": "recommend_subject",

  "cluster_profile": {
    "cluster_id": 1,
    "cluster_name": "Segmento 1",
    "cluster_similarity": 0.73,
    "typical_objects": [
      { "object": "Bancone Principale",    "score": 1.24 },
      { "object": "Scaffalature Centrali", "score": 1.11 },
      { "object": "Illuminazione LED",     "score": 0.98 }
    ]
  },

  "zone_anomalies": [
    {
      "zone": "bancone",
      "label": "🏪 Bancone / Cassa",
      "anomalies": [
        {
          "object": "Sedie Ufficio",
          "score": 0.03,
          "reason": "Score previsto (0.03) inferiore alla soglia di anomalia (0.1)."
        }
      ],
      "context_coherence": {
        "Bancone 200cm": 0.82,
        "Sedie Ufficio": 0.03
      }
    }
  ],

  "context":    { "mq": 80, "tipo": "standard" },
  "subject_id": "proj_123",
  "elapsed_s":  0.34,
  "items_analyzed": 3
}
```

#### Come presentare il risultato

```
📊 Copertura funzionale [negozio]: 2/3 zone obbligatorie (67%)

✅ Zone coperte:
  🏪 Bancone / Cassa — 1 elemento (Bancone 200cm)
  💡 Illuminazione — 1 elemento (LED Strip 3m)

❌ Zone mancanti:
  📦 Scaffalature — nessun elemento

ℹ️ Zone opzionali non presenti:
  🤖 Cassa Self-Service (non richiesta con mq=80, tipo=standard)

📌 Profilo del tuo segmento (Segmento 1 — 73% affinità):
  Tipicamente include: Bancone Principale, Scaffalature Centrali, Illuminazione LED

🤖 Suggerimenti ML correlati:
  - Scaffalature Centrali (score: 0.89)
  - Gondole (score: 0.74)

⚠️ Anomalie rilevate in 🏪 Bancone / Cassa:
  - "Sedie Ufficio" — coerenza 3% → probabile errore di classificazione
```

---

## Integrazione con als-recommender

### Script richiamati e quando

| Script | Condizione di attivazione | Strategia |
|---|---|---|
| `recommend.py` | `ALS_SKILL_ID` presente, `als_suggest_mode=recommend` | `subject_id` → seed → hints |
| `cluster_profiles.py` | Dopo recommend riuscito con `cluster_id` nell'output | Filtra il cluster dell'output |
| `similar.py` | `ALS_SKILL_ID` presente, `als_suggest_mode=similar` | Max 3 zone coperte |
| `popular.py` | Cold-start: nessun seed/hint produce risultati | Oggetti più frequenti |
| `anomalies.py` | `als_anomaly_check=true`, zona con ≥ 2 elementi distinti | Per zona |

### Priorità dei suggerimenti (`als_source`)

```
recommend_subject   ← subject_id fornito e trovato nel modello (massima precisione)
recommend           ← seed dagli oggetti classificati
recommend_hints     ← hint delle zone mancanti come seed
similar             ← als_suggest_mode = "similar"
popular             ← cold-start finale
```

### Numero massimo di chiamate HTTP per esecuzione

| Script | Min | Max |
|---|---|---|
| `recommend.py` | 0 | 3 |
| `cluster_profiles.py` | 0 | 1 |
| `similar.py` | 0 | 3 |
| `popular.py` | 0 | 1 |
| `anomalies.py` | 0 | N zone |

`recommend` e `similar` sono mutualmente esclusivi (dipende da `als_suggest_mode`).

---

## Invocazione da un'altra skill (inter-skill bus)

```python
import os, json, urllib.request

def invoke_coverage_check(profile, rows, context=None, subject_id=None, timeout_s=15):
    skill_id = _config.get('COVERAGE_SKILL_ID', '').strip()
    if not skill_id:
        return None

    inp = {'profile': profile, 'rows': rows}
    if context:
        inp['context'] = context
    if subject_id:
        inp['subject_id'] = subject_id

    url  = f"{os.environ['BACKEND_INTERNAL_URL']}/internal/skills/{skill_id}/invoke"
    body = json.dumps({'script': 'analyze.py', 'input': inp}).encode()
    req  = urllib.request.Request(url, data=body, method='POST', headers={
        'Content-Type':       'application/json',
        'x-internal-token': os.environ['INTERNAL_TOKEN'],
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as r:
            return json.loads(r.read()).get('output')
    except Exception:
        return None


# Esempio d'uso
report = invoke_coverage_check(
    profile    = 'negozio',
    rows       = sql_rows,
    context    = {'mq': 80, 'tipo': 'flagship'},
    subject_id = 'proj_42',
)
if report:
    score    = report['score']            # es. 75
    missing  = report['missing']          # zone obbligatorie mancanti
    suggest  = report['als_suggestions']  # oggetti consigliati
    cluster  = report['cluster_profile']  # profilo del segmento (o None)
    anomalie = report['zone_anomalies']   # anomalie per zona
```

---

## Note tecniche

### Classificazione degli elementi

Per ogni elemento nei `rows`:
1. **Mapping esatto**: se `column_object` è una chiave nel `mapping` del profilo → zona assegnata
2. **Keyword matching**: scorre le zone cercando le keywords in `column_name` (case-insensitive, substring)
3. **Non classificato**: se nessuna delle due ha successo → finisce in `unclassified`

Il mapping ha priorità sul keyword matching.

### `required_if` e `context`

Le condizioni `required_if` vengono valutate sul dict `context` passato nell'input.
Un campo non presente nel context fa fallire la condizione (zona non richiesta).

```json
// required_if singolo
{ "field": "mq", "op": "gte", "value": 40 }
// → la zona è obbligatoria solo se context["mq"] >= 40

// required_if multiplo
{ "logic": "or", "rules": [
    { "field": "tipo", "op": "eq", "value": "flagship" },
    { "field": "mq",  "op": "gte","value": 200 }
]}
// → obbligatoria se tipo=flagship OPPURE mq≥200
```

### Score di copertura

```
zones_required = zone obbligatorie totali (required=true o required_if vera)
zones_covered  = zone obbligatorie con ≥ min_items elementi
score          = round(zones_covered / zones_required * 100)  [0-100]
```

Zone opzionali non influenzano lo score.

### `cluster_profile`

Disponibile solo quando:
1. `ALS_SKILL_ID` configurato
2. `als_suggest_mode = "recommend"`
3. `recommend.py` ha restituito `cluster_id` nell'output (modello con ≥ 12 soggetti nel training)

Il campo è `null` in tutti gli altri casi (modalità similar, popular, nessun ALS).

### `column_object` e `COLUMN_OBJECT`

`column_object` nel profilo (coverage-check) deve corrispondere a `COLUMN_OBJECT` nella
configurazione della skill als-recommender associata a quel profilo. È responsabilità
dell'utente garantire questa coerenza — coverage-check non la verifica automaticamente.

### `column_subject` e auto-estrazione di `subject_id`

`column_subject` nel profilo (e `COLUMN_SUBJECT` come fallback globale) indica la colonna
del soggetto (negozio, progetto, utente…) nel dataset. Il flusso completo:

1. `zones.py` espone `columns.subject` → il LLM sa quale alias usare nel `SELECT`
2. Il LLM include la colonna nel SELECT, i `rows` arrivano con quel campo valorizzato
3. `analyze.py` legge `rows[0]["cod_negozio"]` e lo imposta come `subject_id`
4. `recommend.py` riceve `subject_id` e usa il vettore soggetto salvato dal training

Se `subject_id` è già esplicitamente nell'input, ha la precedenza sull'auto-estrazione.
`column_subject` deve corrispondere a `COLUMN_SUBJECT` del modello ALS.

## Network

Nessuna connessione esterna. La skill opera in locale e/o tramite il backend interno (`BACKEND_INTERNAL_URL`, sempre raggiungibile e non soggetto all'allowlist egress).
