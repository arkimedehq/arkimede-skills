"""
analyze.py — Coverage Check Skill v2.5.0

Analizza la copertura funzionale di un insieme di elementi rispetto alle zone
del profilo selezionato (campo "profile" nell'input, default: DEFAULT_PROFILE).

Tutti i parametri ALS e le colonne dataset sono configurabili per-profilo in
PROFILES_CONFIG, con fallback automatico ai valori globali delle config var.

Gerarchia di risoluzione per ogni parametro:
  profilo.<campo>  →  config globale  →  valore hardcoded

Flusso:
  1. Risolve il profilo e costruisce il dict als_cfg con tutti i parametri ALS risolti
  2. Carica zone e mapping dal profilo
  3. Classifica ogni elemento: mapping esatto → keyword fallback → non classificato
  4. Valuta copertura per zona in base al contesto (required_if)
  5. Suggerimenti ML (als_cfg['skill_id'] presente):
     - recommend.py con priorità: subject_id → seed_objects → hints → popular.py
     - oppure similar.py (se als_suggest_mode = "similar"), fallback popular.py
     - anomalies.py per zona (se als_cfg['anomaly_check'] = true)
     - cluster_profiles.py per il profilo tipico del segmento (dopo ogni recommend.py)
  6. Restituisce report JSON strutturato

Input opzionale "subject_id":
  Se fornito esplicitamente, i suggerimenti ML usano il vettore soggetto ALS diretto
  (più preciso dei seed). Priorità massima in modalità recommend; ignorato in similar.
  Fallback automatico ai seed se il soggetto non è nel modello.
  Se non fornito ma il profilo ha "column_subject" configurato, viene estratto
  automaticamente da rows[0][column_subject] — il LLM include la colonna nel SELECT
  grazie a columns.subject restituito da zones.py.

Output JSON:
  success, profile, score, zones_required, zones_covered,
  complete, missing, optional_missing, unclassified,
  als_suggestions, als_source, cluster_profile, zone_anomalies,
  context, subject_id, elapsed_s, items_analyzed
"""
import json
import os
import sys
import time
import urllib.request

# ── Config ────────────────────────────────────────────────────────────────────

_stdin_raw: str = sys.stdin.read() if sys.stdin else ''
try:
    _stdin_data: dict = json.loads(_stdin_raw) if _stdin_raw.strip() else {}
except Exception:
    _stdin_data = {}

_config: dict = _stdin_data.get('_config', {})


def _cfg(key: str, default: str = '') -> str:
    return _config.get(key, default) or default


def _cfg_int(key: str, default: int) -> int:
    try:
        return int(_cfg(key, str(default)))
    except (ValueError, TypeError):
        return default


def _cfg_float(key: str, default: float) -> float:
    try:
        return float(_cfg(key, str(default)))
    except (ValueError, TypeError):
        return default


def _load_json_config(key: str, default):
    raw = _cfg(key, '').strip()
    if not raw or raw in ('{}', '[]', '""', "''"):
        return default
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        _err(f'Configurazione {key} non è JSON valido: {e}')


def _err(msg: str) -> None:
    print(json.dumps({'success': False, 'error': msg}))
    sys.exit(0)


# ── Fallback globali colonne ───────────────────────────────────────────────────

_DEFAULT_COL_ID   = _cfg('COLUMN_ID',      'id')
_DEFAULT_COL_NAME = _cfg('COLUMN_NAME',    'name')
_DEFAULT_COL_OBJ  = _cfg('COLUMN_OBJECT',  'object')
_DEFAULT_COL_SUBJ = _cfg('COLUMN_SUBJECT', '')

# ── Caricamento profili ───────────────────────────────────────────────────────

profiles: dict = _load_json_config('PROFILES_CONFIG', {})

if not profiles:
    _err(
        'PROFILES_CONFIG non configurato. '
        'Vai su Settings → Skill → coverage-check → Configurazione e definisci i profili.'
    )


def resolve_profile(name: str | None) -> tuple[str, dict]:
    """
    Risolve il nome del profilo e restituisce (nome_effettivo, profile_dict).
    Cascata: input "profile" → DEFAULT_PROFILE config → "default" → primo disponibile.
    """
    for c in [name, _cfg('DEFAULT_PROFILE', 'default'), 'default']:
        if c and c in profiles:
            return c, profiles[c]
    first = next(iter(profiles))
    return first, profiles[first]


def build_als_cfg(profile: dict) -> dict:
    """
    Costruisce il dict als_cfg con tutti i parametri ALS risolti.
    Per ogni campo: valore nel profilo → config globale → default hardcoded.

    Campi risolti:
      skill_id          str   — UUID als-recommender ('' = ALS disabilitato)
      model_name        str   — nome modello ALS
      top_n             int   — max suggerimenti ML
      suggest_mode      str   — 'recommend' | 'similar'
      anomaly_check     bool  — attiva rilevamento anomalie per zona
      anomaly_threshold float — soglia anomalia 0.0–1.0
    """
    def _p(key: str, default: str = '') -> str:
        """Valore dal profilo (snake_case) con fallback alla config globale."""
        return str(profile.get(key) or '').strip() or _cfg(key.upper(), default)

    skill_id = _p('als_skill_id')

    try:
        top_n = int(profile.get('als_top_n') or _cfg('ALS_TOP_N', '6') or 6)
    except (ValueError, TypeError):
        top_n = 6

    anomaly_raw = str(profile.get('als_anomaly_check') or _cfg('ALS_ANOMALY_CHECK', 'false'))
    anomaly_check = anomaly_raw.lower() in ('true', '1', 'yes')

    try:
        threshold = float(profile.get('als_anomaly_threshold') or _cfg('ALS_ANOMALY_THRESHOLD', '0.1') or 0.1)
    except (ValueError, TypeError):
        threshold = 0.1

    suggest_mode = str(
        profile.get('als_suggest_mode') or _cfg('ALS_SUGGEST_MODE', 'recommend')
    ).lower()

    model_name = str(
        profile.get('als_model_name') or _cfg('ALS_MODEL_NAME', 'default')
    )

    return {
        'skill_id':          skill_id,
        'model_name':        model_name,
        'top_n':             top_n,
        'suggest_mode':      suggest_mode,
        'anomaly_check':     anomaly_check,
        'anomaly_threshold': threshold,
    }


# ── Helpers condizioni required_if ────────────────────────────────────────────

def _eval_rule(rule: dict, context: dict) -> bool:
    field = rule.get('field', '')
    op    = rule.get('op', 'eq')
    value = rule.get('value')
    ctx   = context.get(field)
    if ctx is None:
        return False
    match op:
        case 'eq':       return ctx == value
        case 'neq':      return ctx != value
        case 'gt':       return ctx >  value
        case 'gte':      return ctx >= value
        case 'lt':       return ctx <  value
        case 'lte':      return ctx <= value
        case 'in':       return ctx in (value or [])
        case 'nin':      return ctx not in (value or [])
        case 'contains': return str(value) in str(ctx)
        case _:          return False


def is_zone_required(zone_def: dict, context: dict) -> bool:
    if zone_def.get('required'):
        return True
    cond = zone_def.get('required_if')
    if not cond:
        return False
    if 'rules' not in cond:
        return _eval_rule(cond, context)
    logic   = cond.get('logic', 'and')
    results = [_eval_rule(r, context) for r in cond['rules']]
    return all(results) if logic == 'and' else any(results)


# ── Classificazione ───────────────────────────────────────────────────────────

def classify(category: str | None, name: str, zones: dict, mapping: dict) -> str | None:
    """Mapping esatto → keyword matching → None."""
    if category:
        zone = mapping.get(category)
        if zone and zone in zones:
            return zone
    name_lower = (name or '').lower()
    for zone_id, zone_def in zones.items():
        if any(kw.lower() in name_lower for kw in zone_def.get('keywords', [])):
            return zone_id
    return None


# ── Inter-skill bus ───────────────────────────────────────────────────────────

def _call_als_raw(script: str, inp: dict, als_cfg: dict, timeout_s: int = 10) -> dict:
    """
    Chiamata generica ad als-recommender via inter-skill bus.
    Usa als_cfg['skill_id'] e als_cfg['model_name'] già risolti per il profilo corrente.
    Ritorna il dict 'output', o {} in caso di errore/non configurato.
    """
    skill_id = als_cfg.get('skill_id', '')
    if not skill_id:
        return {}

    model_name = als_cfg.get('model_name', 'default')
    if 'model_name' not in inp and model_name and model_name != 'default':
        inp = {**inp, 'model_name': model_name}

    backend_url  = os.environ.get('BACKEND_INTERNAL_URL', '').rstrip('/')
    internal_key = os.environ.get('INTERNAL_TOKEN', '')
    url  = f'{backend_url}/internal/skills/{skill_id}/invoke'
    body = json.dumps({'script': script, 'input': inp}).encode()
    req  = urllib.request.Request(
        url, data=body, method='POST',
        headers={'Content-Type': 'application/json', 'x-internal-token': internal_key},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as r:
            return json.loads(r.read()).get('output', {})
    except Exception:
        return {}


def _fetch_cluster_profile(
    cluster_id:         int,
    cluster_name:       str,
    cluster_similarity: float | None,
    als_cfg:            dict,
    top_n:              int,
) -> dict | None:
    """
    Recupera il profilo tipico del cluster identificato da recommend.py.
    Chiama cluster_profiles.py e filtra il cluster corrispondente.
    Ritorna None se il modello non ha dati di clustering o il cluster non esiste.
    """
    out = _call_als_raw('cluster_profiles.py', {'top_n': top_n}, als_cfg)
    if not out.get('success'):
        return None
    for c in out.get('clusters', []):
        if c.get('cluster_id') == cluster_id:
            return {
                'cluster_id':         cluster_id,
                'cluster_name':       cluster_name,
                'cluster_similarity': cluster_similarity,
                'typical_objects':    c.get('typical_objects', []),
            }
    return None


def build_als_suggestions(
    by_zone:    dict[str, list[dict]],
    missing:    list[dict],
    als_cfg:    dict,
    col_name:   str,
    col_obj:    str,
    subject_id: str | None = None,
) -> tuple[list[dict], str, dict | None]:
    """
    Suggerimenti ML per le zone mancanti.

    Legge suggest_mode, top_n e skill_id da als_cfg (già risolti per il profilo).
    col_obj è la colonna column_object del profilo — corrisponde a COLUMN_OBJECT del modello ALS.

    Ritorna: (suggestions, source, cluster_profile)
      suggestions     — lista di {object, score}
      source          — stringa che identifica la strategia usata
      cluster_profile — dict con cluster_id, cluster_name, cluster_similarity,
                        typical_objects (da cluster_profiles.py) oppure None
                        se il modello non ha clustering o la modalità è similar/popular.

    Strategie (recommend):
      1. subject_id   → recommend.py con il vettore soggetto salvato (più preciso).
                        Fallback automatico al seed se il soggetto non è nel modello.
      2. seed_objects → recommend.py con la media dei vettori degli item classificati.
      3. hints        → recommend.py con gli hint delle zone mancanti come seed.
      4. popular      → cold-start con popular.py (nessun cluster profile).

    Strategie (similar):
      similar.py sul primo item di ogni zona coperta (max 3 zone).
      Fallback: popular.py.
      (subject_id e cluster_profile non si applicano a similar)
    """
    if not als_cfg.get('skill_id'):
        return [], '', None

    suggest_mode  = als_cfg['suggest_mode']
    top_n         = als_cfg['top_n']
    missing_hints = [z['hint'] for z in missing if z.get('hint')]

    covered_items: list[str] = []
    covered_first_per_zone: list[str] = []
    for zone_items in by_zone.values():
        zone_first: str | None = None
        for row in zone_items:
            it = row.get(col_obj) or row.get(col_name, '')
            if it and it not in covered_items:
                covered_items.append(it)
            if it and zone_first is None:
                zone_first = it
        if zone_first:
            covered_first_per_zone.append(zone_first)

    # ── similar ───────────────────────────────────────────────────────────────
    if suggest_mode == 'similar':
        if covered_first_per_zone:
            merged: dict[str, float] = {}
            for ref in covered_first_per_zone[:3]:
                out = _call_als_raw('similar.py', {'reference_object': ref, 'top_n': top_n}, als_cfg)
                for s in out.get('similar_objects', []):
                    name = s.get('object', '')
                    sim  = float(s.get('similarity', 0))
                    if name and (name not in merged or sim > merged[name]):
                        merged[name] = sim
            if merged:
                sorted_s = sorted(merged.items(), key=lambda x: x[1], reverse=True)
                return [{'object': k, 'score': round(v, 4)} for k, v in sorted_s[:top_n]], 'similar', None
        out = _call_als_raw('popular.py', {'top_n': top_n}, als_cfg)
        popular = out.get('popular_objects', [])
        if popular:
            return [{'object': p['object'], 'score': None} for p in popular], 'popular', None
        return [], '', None

    # ── recommend — priorità: subject_id → seed → hints → popular ────────────
    # Cattura il cluster_id dalla prima chiamata recommend.py andata a buon fine.

    def _extract_cluster(rec_out: dict) -> dict | None:
        """Legge cluster_id/name/similarity dall'output di recommend.py e chiama cluster_profiles.py."""
        cid = rec_out.get('cluster_id')
        if cid is None:
            return None
        return _fetch_cluster_profile(
            cluster_id         = cid,
            cluster_name       = rec_out.get('cluster_name', f'Segmento {cid}'),
            cluster_similarity = rec_out.get('cluster_similarity'),
            als_cfg            = als_cfg,
            top_n              = top_n,
        )

    # 1. subject_id: usa il vettore soggetto salvato dal training (più preciso dei seed)
    if subject_id:
        out   = _call_als_raw('recommend.py', {'subject_id': subject_id, 'top_n': top_n}, als_cfg)
        items = out.get('objects', [])
        if items:
            return items, 'recommend_subject', _extract_cluster(out)
        # Fallback silenzioso: soggetto non trovato nel modello → continua con i seed

    # 2. seed dagli item classificati
    if covered_items:
        out   = _call_als_raw('recommend.py', {'seed_objects': covered_items[:20], 'top_n': top_n}, als_cfg)
        items = out.get('objects', [])
        if items:
            return items, 'recommend', _extract_cluster(out)

    # 3. hint delle zone mancanti come seed (nessun item classificato disponibile)
    if missing_hints:
        out   = _call_als_raw('recommend.py', {'seed_objects': missing_hints, 'top_n': top_n}, als_cfg)
        items = out.get('objects', [])
        if items:
            return items, 'recommend_hints', _extract_cluster(out)

    # 4. cold-start: nessun seed utilizzabile (nessun cluster profile disponibile)
    out = _call_als_raw('popular.py', {'top_n': top_n}, als_cfg)
    popular = out.get('popular_objects', [])
    if popular:
        return [{'object': p['object'], 'score': None} for p in popular], 'popular', None

    return [], '', None


def build_zone_anomalies(
    by_zone:  dict[str, list[dict]],
    zones:    dict,
    als_cfg:  dict,
    col_name: str,
    col_obj:  str,
) -> list[dict]:
    """
    Anomalie per zona tramite anomalies.py.
    Legge anomaly_check e anomaly_threshold da als_cfg (già risolti per il profilo).
    col_obj è la colonna column_object del profilo — corrisponde a COLUMN_OBJECT del modello ALS.
    """
    if not als_cfg.get('skill_id') or not als_cfg.get('anomaly_check'):
        return []

    threshold      = als_cfg['anomaly_threshold']
    zone_anomalies: list[dict] = []

    for zone_id, zone_items in by_zone.items():
        if len(zone_items) < 2:
            continue
        item_names: list[str] = []
        for row in zone_items:
            name = row.get(col_obj) or row.get(col_name, '')
            if name and name not in item_names:
                item_names.append(name)
        if len(item_names) < 2:
            continue

        out       = _call_als_raw('anomalies.py', {'seed_objects': item_names, 'threshold': threshold}, als_cfg)
        anomalies = out.get('anomalies', [])
        if not anomalies:
            continue

        zone_def = zones.get(zone_id, {})
        zone_anomalies.append({
            'zone':              zone_id,
            'label':             f"{zone_def.get('icon', '')} {zone_def.get('label', zone_id)}".strip(),
            'anomalies':         anomalies,
            'context_coherence': out.get('context_coherence', {}),
        })

    return zone_anomalies


# ── Main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    inp = _stdin_data

    rows       = inp.get('rows')
    context    = inp.get('context') or {}
    subject_id = inp.get('subject_id') or None

    if not isinstance(rows, list) or not rows:
        _err('Campo "rows" obbligatorio: array di oggetti con gli elementi da analizzare.')

    # ── Risoluzione profilo ───────────────────────────────────────────────────
    profile_name, profile = resolve_profile(inp.get('profile'))
    zones   = profile.get('zones', {})
    mapping = profile.get('mapping', {})

    if not zones:
        _err(
            f'Il profilo "{profile_name}" non ha zone definite. '
            f'Controlla PROFILES_CONFIG → "{profile_name}" → "zones".'
        )

    # Risolve tutti i parametri ALS e le colonne per questo profilo
    als_cfg  = build_als_cfg(profile)
    col_id   = str(profile.get('column_id')      or _DEFAULT_COL_ID)
    col_name = str(profile.get('column_name')    or _DEFAULT_COL_NAME)
    col_obj  = str(profile.get('column_object')  or _DEFAULT_COL_OBJ)
    col_subj = str(profile.get('column_subject') or _DEFAULT_COL_SUBJ)

    # ── Sanity check colonne e auto-detection ────────────────────────────────
    first_keys: set[str] = set(rows[0].keys()) if rows else set()

    if rows and not first_keys:
        aliases = f'{col_obj}, {col_id}, "{col_name}"' + (f', {col_subj}' if col_subj else '')
        _err(
            f'Le righe passate sono oggetti vuoti {{}}. '
            f'Passa il risultato SQL direttamente senza trasformarlo. '
            f'La query deve usare questi alias AS (da zones.py → columns): {aliases}. '
            f'Esempio: SELECT categoria AS {col_obj}, codice AS {col_id}, '
            f'descrizione AS "{col_name}" FROM ...'
        )

    if rows and col_obj not in first_keys:
        # Tenta auto-detection: cerca la colonna i cui valori matchano le chiavi del mapping
        detected_col: str | None = None
        mapping_keys = set(mapping.keys())
        for candidate in first_keys:
            sample = {str(r.get(candidate, '')) for r in rows[:30] if r.get(candidate)}
            if sample & mapping_keys:
                detected_col = candidate
                break
        if detected_col:
            col_obj = detected_col
        else:
            found = sorted(first_keys)
            _err(
                f'Colonna "{col_obj}" non trovata nelle righe (column_object del profilo). '
                f'Colonne disponibili: {found}. '
                f'Aggiungi alias nella query: SELECT categoria AS {col_obj} FROM ...'
            )

    # Auto-estrazione subject_id dal primo row se non passato esplicitamente
    # e column_subject è configurato — il LLM include la colonna nel SELECT grazie a columns.subject
    if not subject_id and col_subj and rows:
        subject_id = str(rows[0].get(col_subj, '') or '') or None

    t0 = time.time()

    # ── Classificazione ───────────────────────────────────────────────────────
    by_zone:      dict[str, list[dict]] = {}
    unclassified: list[dict]            = []

    for row in rows:
        elem_id   = row.get(col_id,   '')
        elem_name = row.get(col_name, '')
        elem_obj  = row.get(col_obj)  or None

        zone = classify(elem_obj, elem_name, zones, mapping)
        if zone:
            by_zone.setdefault(zone, []).append(row)
        else:
            unclassified.append({'id': elem_id, 'name': elem_name, 'object': elem_obj})

    # ── Valutazione copertura ─────────────────────────────────────────────────
    complete:         list[dict] = []
    missing:          list[dict] = []
    optional_missing: list[dict] = []

    for zone_id, zone_def in zones.items():
        items     = by_zone.get(zone_id, [])
        min_items = zone_def.get('min_items', 1)
        required  = is_zone_required(zone_def, context)
        icon      = zone_def.get('icon', '')
        label     = zone_def.get('label', zone_id)
        hint      = zone_def.get('hint', '')

        if len(items) >= min_items:
            examples = [
                r.get(col_name, r.get(col_id, ''))
                for r in items[:3]
                if r.get(col_name) or r.get(col_id)
            ]
            complete.append({
                'zone':     zone_id,
                'label':    f'{icon} {label}'.strip(),
                'count':    len(items),
                'examples': examples,
            })
        elif required:
            missing.append({'zone': zone_id, 'label': f'{icon} {label}'.strip(), 'hint': hint})
        else:
            optional_missing.append({'zone': zone_id, 'label': f'{icon} {label}'.strip(), 'hint': hint})

    # ── Score ─────────────────────────────────────────────────────────────────
    zones_required = len(missing) + sum(
        1 for z in complete if is_zone_required(zones[z['zone']], context)
    )
    zones_covered = sum(
        1 for z in complete if is_zone_required(zones[z['zone']], context)
    )
    score = round((zones_covered / zones_required * 100) if zones_required else 100)

    # ── ALS ───────────────────────────────────────────────────────────────────
    als_suggestions, als_source, cluster_profile = build_als_suggestions(by_zone, missing, als_cfg, col_name, col_obj, subject_id)
    zone_anomalies              = build_zone_anomalies(by_zone, zones, als_cfg, col_name, col_obj)

    # ── Output ────────────────────────────────────────────────────────────────
    result = {
        'success':          True,
        'profile':          profile_name,
        'score':            score,
        'zones_required':   zones_required,
        'zones_covered':    zones_covered,
        'complete':         complete,
        'missing':          missing,
        'optional_missing': optional_missing,
        'unclassified':     unclassified,
        'als_suggestions':  als_suggestions,
        'als_source':       als_source or None,
        'cluster_profile':  cluster_profile,
        'zone_anomalies':   zone_anomalies,
        'context':          context,
        'subject_id':       subject_id,
        'elapsed_s':        round(time.time() - t0, 2),
        'items_analyzed':   len(rows),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
