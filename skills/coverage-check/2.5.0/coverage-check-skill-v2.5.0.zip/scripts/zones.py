"""
zones.py — Coverage Check Skill v2.5.0

Restituisce i profili configurati e le zone di ciascuno.

Input (tutti opzionali):
  profile (string) — se specificato, mostra le zone di quel profilo in dettaglio.
                     Se omesso, elenca tutti i profili disponibili con un riepilogo.
  context (object) — contesto per valutare required_if (usato solo con profile specificato).

Output senza "profile":
  success   (bool)
  profiles  (list) — lista profili con {name, zone_count, als_model_name}
  total     (int)  — numero di profili configurati
  default   (str)  — profilo di default (DEFAULT_PROFILE config)

Output con "profile":
  success          (bool)
  profile          (str)
  zones            (list)  — zone del profilo con tutti i dettagli
  total            (int)
  required         (int)
  conditional      (int)
  optional         (int)
  als_model_name   (str)   — modello ALS del profilo (o fallback globale)
  columns          (dict)  — colonne risolte: subject, id, name, object
                             Usare come alias AS nella query SQL.
                             "subject" è la colonna del soggetto (es. id progetto/utente/negozio)
                             per estrarre automaticamente subject_id in analyze.py.
  context          (object) — se passato
  context_required (list)   — zone obbligatorie nel contesto (se context passato)
"""
import json
import sys


_stdin_raw: str = sys.stdin.read() if sys.stdin else ''
try:
    _stdin_data: dict = json.loads(_stdin_raw) if _stdin_raw.strip() else {}
except Exception:
    _stdin_data = {}

_config: dict = _stdin_data.get('_config', {})


def _cfg(key: str, default: str = '') -> str:
    return _config.get(key, default) or default


def _load_json_config(key: str, default):
    raw = _cfg(key, '').strip()
    if not raw or raw in ('{}', '[]', '""', "''"):
        return default
    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        print(json.dumps({'success': False, 'error': f'JSON non valido nella config "{key}": {e}'}))
        sys.exit(1)


def _eval_rule(rule: dict, context: dict) -> bool:
    field = rule.get('field', '')
    op    = rule.get('op', 'eq')
    value = rule.get('value')
    ctx   = context.get(field)
    if ctx is None:
        return False
    match op:
        case 'eq':       return ctx == value
        case 'neq':      return ctx != value
        case 'gt':       return ctx >  value
        case 'gte':      return ctx >= value
        case 'lt':       return ctx <  value
        case 'lte':      return ctx <= value
        case 'in':       return ctx in (value or [])
        case 'nin':      return ctx not in (value or [])
        case 'contains': return str(value) in str(ctx)
        case _:          return False


def is_zone_required(zone_def: dict, context: dict) -> bool:
    if zone_def.get('required'):
        return True
    cond = zone_def.get('required_if')
    if not cond:
        return False
    if 'rules' not in cond:
        return _eval_rule(cond, context)
    logic   = cond.get('logic', 'and')
    results = [_eval_rule(r, context) for r in cond['rules']]
    return all(results) if logic == 'and' else any(results)


def main() -> None:
    inp = _stdin_data

    profiles = _load_json_config('PROFILES_CONFIG', {})

    if not profiles:
        print(json.dumps({
            'success': False,
            'error': (
                'PROFILES_CONFIG non configurato. '
                'Vai su Settings → Skill → coverage-check → Configurazione.'
            ),
        }))
        return

    profile_name = inp.get('profile') or ''
    context      = inp.get('context') or {}
    default_prof = _cfg('DEFAULT_PROFILE', 'default')

    # ── Senza profile: lista tutti i profili ─────────────────────────────────
    if not profile_name:
        profile_list = []
        for pname, pdata in profiles.items():
            zones = pdata.get('zones', {})
            profile_list.append({
                'name':           pname,
                'zone_count':     len(zones),
                'als_model_name': pdata.get('als_model_name') or _cfg('ALS_MODEL_NAME', 'default'),
                'is_default':     pname == default_prof,
            })
        print(json.dumps({
            'success':  True,
            'profiles': profile_list,
            'total':    len(profile_list),
            'default':  default_prof,
        }, ensure_ascii=False, indent=2))
        return

    # ── Con profile: mostra zone in dettaglio ─────────────────────────────────
    if profile_name not in profiles:
        available = list(profiles.keys())
        print(json.dumps({
            'success': False,
            'error':   f'Profilo "{profile_name}" non trovato. Disponibili: {available}',
        }))
        return

    profile      = profiles[profile_name]
    zones        = profile.get('zones', {})
    als_model    = profile.get('als_model_name') or _cfg('ALS_MODEL_NAME', 'default')

    # Colonne risolte per il profilo (per-profilo → config globale → default hardcoded)
    columns = {
        'subject': profile.get('column_subject') or _cfg('COLUMN_SUBJECT', '') or '',
        'id':      profile.get('column_id')      or _cfg('COLUMN_ID',      'id'),
        'name':    profile.get('column_name')    or _cfg('COLUMN_NAME',    'name'),
        'object':  profile.get('column_object')  or _cfg('COLUMN_OBJECT',  'object'),
    }

    zone_list = []
    for zone_id, zone_def in zones.items():
        always_required = bool(zone_def.get('required'))
        has_condition   = bool(zone_def.get('required_if'))
        zone_list.append({
            'id':          zone_id,
            'label':       f"{zone_def.get('icon', '')} {zone_def.get('label', zone_id)}".strip(),
            'required':    always_required,
            'conditional': has_condition,
            'required_if': zone_def.get('required_if'),
            'min_items':   zone_def.get('min_items', 1),
            'hint':        zone_def.get('hint', ''),
            'keywords':    zone_def.get('keywords', []),
        })

    n_required    = sum(1 for z in zone_list if z['required'])
    n_conditional = sum(1 for z in zone_list if z['conditional'])
    n_optional    = len(zone_list) - n_required - n_conditional

    subj_alias = (f'... AS {columns["subject"]}, ' if columns['subject'] else '')
    sql_hint = (
        f'SELECT {subj_alias}... AS {columns["id"]}, '
        f'... AS "{columns["name"]}", ... AS {columns["object"]} FROM ...'
    )

    result: dict = {
        'success':        True,
        'profile':        profile_name,
        'zones':          zone_list,
        'total':          len(zone_list),
        'required':       n_required,
        'conditional':    n_conditional,
        'optional':       n_optional,
        'als_model_name': als_model,
        'columns':        columns,
        'sql_hint':       sql_hint,
    }

    if context:
        result['context']          = context
        result['context_required'] = [
            z['id'] for z in zone_list
            if is_zone_required(zones[z['id']], context)
        ]

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
