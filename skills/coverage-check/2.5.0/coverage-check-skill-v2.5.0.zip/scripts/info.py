#!/usr/bin/env python3
"""
Coverage Check — Info Script (mode: info)

Mostra lo stato della configurazione della skill:
profili definiti, zone per profilo, config ALS globale, colonne di fallback.
Viene eseguito automaticamente dall'UI all'apertura del drawer.
Non richiede input. Non viene esposto all'LLM.

Output JSON:
  {
    "configured": true,
    "profiles": [
      {
        "name": "negozio",
        "is_default": true,
        "zone_count": 5,
        "required_zones": 2,
        "conditional_zones": 2,
        "optional_zones": 1,
        "als_model": "negozio",
        "has_mapping": true,
        "mapping_count": 15
      }
    ],
    "total_profiles": 1,
    "default_profile": "negozio",
    "global_als": {
      "skill_id": "...",
      "model_name": "default",
      "top_n": 6,
      "suggest_mode": "recommend",
      "anomaly_check": false,
      "anomaly_threshold": 0.1
    },
    "global_columns": {
      "subject": "",
      "id": "id",
      "name": "name",
      "object": "object"
    }
  }
"""
import json
import os
import sys


_raw: dict = {}
try:
    _stdin = sys.stdin.read()
    if _stdin.strip():
        _raw = json.loads(_stdin)
except Exception:
    pass

_config: dict = _raw.get('_config', {})


def _cfg(key: str, default: str = '') -> str:
    return _config.get(key, default) or default


def _load_json_config(key: str, default):
    raw = _cfg(key, '').strip()
    if not raw or raw in ('{}', '[]', '""', "''"):
        return default
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return default


def main():
    profiles_raw = _load_json_config('PROFILES_CONFIG', {})

    if not profiles_raw:
        print(json.dumps({
            'configured': False,
            'warning': (
                'PROFILES_CONFIG non configurato. '
                'Vai su Settings → Skill → coverage-check → Configurazione.'
            ),
            'profiles':       [],
            'total_profiles': 0,
        }))
        return

    default_prof = _cfg('DEFAULT_PROFILE', 'default')

    profiles = [
        {'name': pname, 'is_default': pname == default_prof}
        for pname in profiles_raw
    ]

    print(json.dumps({
        'configured': True,
        'profiles':   profiles,
        'total':      len(profiles),
    }, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success':   False,
            'error':     str(e),
            'traceback': traceback.format_exc(),
        }))
        sys.exit(1)
