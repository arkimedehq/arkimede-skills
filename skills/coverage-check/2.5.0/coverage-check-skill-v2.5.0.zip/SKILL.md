---
name: coverage-check
description: |
  Analizza la copertura funzionale di un insieme di elementi rispetto a zone configurabili. Supporta più profili di analisi (es. "negozio", "ristorante") con zone, mapping e modello ALS dedicati per ciascuno — una sola installazione per tutti i domini. Classifica ogni elemento tramite lookup diretto o keyword matching, valuta quali zone sono coperte/mancanti e restituisce un report JSON strutturato con score, suggerimenti ML e anomalie per zona (opzionali, via inter-skill bus verso als-recommender).
version: 2.5.0
author: personalAgent
license: MIT
runtime:
  network: []
  config:
    - key: PROFILES_CONFIG
      type: json
      description: |
        Definizione dei profili di analisi. Ogni chiave è il nome di un profilo (es. "negozio", "ristorante", "ecommerce"). Il profilo da usare si specifica con "profile" nell'input di analyze.py/zones.py. Se omesso, viene usato DEFAULT_PROFILE (default: "default").
        ── SCHEMA PROFILO ────────────────────────────────────────────────────────
        COLONNE DATASET (opzionali — sovrascrivono i config globali COLUMN_*)
          column_subject    Colonna soggetto dell'elemento (es. id progetto/ordine/negozio/utente).
                            Esposta da zones.py in "columns.subject" — il LLM la usa come alias
                            AS nella query SQL così che analyze.py possa estrarre automaticamente
                            subject_id da rows[0][column_subject] senza che il LLM lo passi
                            esplicitamente. Deve corrispondere a COLUMN_SUBJECT del modello ALS.
                            Lascia vuoto per disabilitare l'auto-estrazione.
          column_id         Colonna identificatore univoco dell'elemento.
                            Usata per tracciare gli elementi non classificati nell'output.
          column_name       Colonna descrizione testuale dell'elemento.
                            Usata per il keyword matching (priorità bassa).
          column_object     Colonna oggetto dell'elemento.
                            Usata per il lookup esatto nel mapping (priorità alta) e come
                            seed per ALS (recommend, anomalies, similar).
                            Deve corrispondere a COLUMN_OBJECT del modello ALS associato
                            a questo profilo — l'utente garantisce la coerenza.

        PARAMETRI ALS (opzionali — sovrascrivono i config globali ALS_*)
          als_skill_id          UUID della skill als-recommender per questo profilo.
                                Utile se profili diversi usano istanze ALS diverse.
          als_model_name        Nome del modello ALS addestrato su questo dominio.
          als_top_n             Max suggerimenti ML da restituire (numero intero).
          als_suggest_mode      Strategia: "recommend" (default) | "similar".
                                recommend → recommend.py con seed dagli item classificati.
                                similar   → similar.py per item-item similarity coseno.
                                Entrambi: cold-start automatico con popular.py se nessun seed.
          als_anomaly_check     true | false — rileva item anomali per zona con anomalies.py.
          als_anomaly_threshold Soglia anomalia 0.0–1.0 (default globale: 0.1).

        ZONE (obbligatorio) — oggetto con ID zona → definizione zona
          Ogni zona ha:
          label         Nome leggibile nel report.
          icon          Emoji opzionale (mostrata nel report accanto al label).
          required      true = zona sempre obbligatoria.
          required_if   Condizione per renderla obbligatoria in base al context.
                        Condizione singola:  { "field": "mq", "op": "gte", "value": 40 }
                        Condizioni multiple: { "logic": "and"|"or", "rules": [...] }
                        Operatori: eq, neq, gt, gte, lt, lte, in, nin, contains
                        "field" è una chiave del dict "context" passato ad analyze.py.
          min_items     Minimo di elementi nella zona per considerarla coperta (default: 1).
          hint          Testo descrittivo della zona — usato come seed per als-recommender
                        quando non ci sono item classificati (modalità recommend_hints).
          keywords      Lista di parole chiave per il keyword matching sulla colonna
                        column_name (case-insensitive, substring match).

        MAPPING (opzionale) — lookup esatto categoria → ID zona
          Chiave:  valore esatto della colonna column_object nel dataset.
          Valore:  ID della zona in "zones".
          Il mapping ha priorità sul keyword matching: se la categoria dell'elemento
          corrisponde a una chiave, la zona è assegnata senza scorrere i keywords.
          Lascia {} per usare solo il keyword matching.

        ── GERARCHIA DI RISOLUZIONE ─────────────────────────────────────────────
          profilo.<campo>  →  config globale (ALS_* / COLUMN_*)  →  default hardcoded
          I campi omessi dal profilo ereditano automaticamente il valore globale.
          Questo permette di condividere als_skill_id e colonne tra tutti i profili
          e sovrascrivere solo ciò che differisce (es. als_model_name per profilo).

        ── ESEMPIO COMPLETO CON DUE PROFILI ─────────────────────────────────────
      required: true
      default: |
        {
          "negozio": {
            "column_subject": "cod_negozio",
            "column_id":      "cod_articolo",
            "column_name":    "descrizione",
            "column_object":  "categoria",
            "als_skill_id":           "",
            "als_model_name":         "negozio",
            "als_top_n":              6,
            "als_suggest_mode":       "recommend",
            "als_anomaly_check":      true,
            "als_anomaly_threshold":  0.1,
            "zones": {
              "bancone": {
                "label":    "Bancone / Cassa",
                "icon":     "🏪",
                "required": true,
                "min_items": 1,
                "hint":     "bancone cassa checkout registratore",
                "keywords": ["bancone", "banco", "cassa", "checkout"]
              },
              "scaffalature": {
                "label":    "Scaffalature / Espositori",
                "icon":     "📦",
                "required": true,
                "min_items": 1,
                "hint":     "scaffale espositore gondola ripiano",
                "keywords": ["scaffal", "espositore", "gondola", "ripiano", "rack"]
              },
              "illuminazione": {
                "label":    "Illuminazione",
                "icon":     "💡",
                "required": false,
                "required_if": { "field": "mq", "op": "gte", "value": 30 },
                "min_items": 1,
                "hint":     "illuminazione led luce plafoniera faretto",
                "keywords": ["illumin", "led", "luce", "plafoniera", "faretto", "strip"]
              },
              "segnaletica": {
                "label":    "Segnaletica / Comunicazione",
                "icon":     "🪧",
                "required": false,
                "required_if": { "field": "tipo", "op": "in", "value": ["flagship", "premium"] },
                "min_items": 1,
                "hint":     "segnaletica insegna cartello totem banner",
                "keywords": ["segnalet", "insegna", "cartello", "totem", "banner", "display"]
              },
              "cassa_self": {
                "label":    "Cassa Self-Service",
                "icon":     "🤖",
                "required": false,
                "required_if": {
                  "logic": "and",
                  "rules": [
                    { "field": "mq",   "op": "gte", "value": 100 },
                    { "field": "tipo", "op": "eq",  "value": "flagship" }
                  ]
                },
                "min_items": 1,
                "hint":     "cassa automatica self service self-checkout totem pagamento",
                "keywords": ["self", "automatica", "totem pagamento", "self-checkout"]
              }
            },
            "mapping": {
              "Bancone Principale":       "bancone",
              "Bancone Angolare":         "bancone",
              "Banco Cassa":              "bancone",
              "Scaffalature Centrali":    "scaffalature",
              "Scaffalature Parete":      "scaffalature",
              "Gondole":                  "scaffalature",
              "Espositori":               "scaffalature",
              "Illuminazione LED":        "illuminazione",
              "Illuminazione Generale":   "illuminazione",
              "Plafoniere":               "illuminazione",
              "Faretti":                  "illuminazione",
              "Insegna Luminosa":         "segnaletica",
              "Totem Segnaletica":        "segnaletica",
              "Cassa Automatica":         "cassa_self",
              "Self Checkout":            "cassa_self"
            }
          },

          "ristorante": {
            "column_subject": "id_ristorante",
            "column_id":      "id_elemento",
            "column_name":    "descrizione",
            "column_object":  "tipo_arredo",
            "als_model_name": "ristorante",
            "zones": {
              "cucina": {
                "label":    "Zona Cucina",
                "icon":     "👨‍🍳",
                "required": true,
                "min_items": 1,
                "hint":     "piano cottura forno cucina frigorigero lavello",
                "keywords": ["cottura", "forno", "cucina", "frigo", "lavello", "cappa"]
              },
              "sala": {
                "label":    "Zona Sala",
                "icon":     "🪑",
                "required": true,
                "min_items": 2,
                "hint":     "tavolo sedia poltrona sala arredo",
                "keywords": ["tavolo", "sedia", "poltrona", "sala", "arredo"]
              },
              "bar": {
                "label":    "Banco Bar",
                "icon":     "☕",
                "required": false,
                "required_if": { "field": "tipo", "op": "eq", "value": "bar_ristorante" },
                "min_items": 1,
                "hint":     "banco bar macchina caffe espresso",
                "keywords": ["banco bar", "bar", "caffe", "macchina caffe", "espresso"]
              },
              "dehors": {
                "label":    "Dehors / Esterno",
                "icon":     "☀️",
                "required": false,
                "required_if": { "field": "esterno", "op": "eq", "value": true },
                "min_items": 1,
                "hint":     "dehors esterno ombrellone tavolo esterno",
                "keywords": ["dehors", "esterno", "ombrellone", "gazebo"]
              }
            },
            "mapping": {
              "Piano Cottura Induzione": "cucina",
              "Piano Cottura Gas":       "cucina",
              "Forno Professionale":     "cucina",
              "Cella Frigorifera":       "cucina",
              "Lavello Inox":            "cucina",
              "Tavoli Quadrati":         "sala",
              "Tavoli Rotondi":          "sala",
              "Sedie Impilabili":        "sala",
              "Poltrone Sala":           "sala",
              "Banco Bar Dritto":        "bar",
              "Macchina Caffe":          "bar",
              "Tavoli Esterno":          "dehors",
              "Ombrelloni":              "dehors"
            }
          }
        }
      secret: false
    - key: DEFAULT_PROFILE
      description: |
        Nome del profilo usato da analyze.py e zones.py quando il campo "profile" non è specificato nell'input. Deve corrispondere esattamente a una chiave di PROFILES_CONFIG. Default: default
      required: false
      default: default
      secret: false
    - key: COLUMN_ID
      description: |
        Fallback globale: nome della colonna con l'identificatore univoco dell'elemento. Usato per tracciare gli elementi non classificati nell'output. Può essere sovrascritto per singolo profilo con "column_id" in PROFILES_CONFIG. Default: id
      required: false
      default: id
      secret: false
    - key: COLUMN_NAME
      description: |
        Fallback globale: nome della colonna con la descrizione testuale dell'elemento. Usata per il keyword matching quando la categoria non è nel mapping. Può essere sovrascritto per singolo profilo con "column_name" in PROFILES_CONFIG. Default: name
      required: false
      default: name
      secret: false
    - key: COLUMN_OBJECT
      description: |
        Fallback globale: nome della colonna oggetto dell'elemento. Usata per il lookup esatto nel mapping (priorità sul keyword matching) e come seed per ALS. Deve corrispondere a COLUMN_OBJECT del modello ALS. Può essere sovrascritto per singolo profilo con "column_object" in PROFILES_CONFIG. Default: object
      required: false
      default: object
      secret: false
    - key: COLUMN_SUBJECT
      description: |
        Fallback globale: nome della colonna soggetto dell'elemento (es. codice progetto, ID ordine, ID negozio, ID utente). Il valore viene esposto da zones.py in "columns.subject" — il LLM lo usa come alias AS nella query SQL, così analyze.py estrae automaticamente subject_id dal primo row senza che il LLM lo passi esplicitamente nell'input. Deve corrispondere a COLUMN_SUBJECT del modello ALS. Può essere sovrascritto per singolo profilo con "column_subject" in PROFILES_CONFIG. Lascia vuoto per disabilitare l'auto-estrazione (subject_id va passato a mano). Default: ""
      required: false
      default: ''
      secret: false
    - key: ALS_SKILL_ID
      description: |
        Fallback globale: UUID della skill als-recommender. Se vuoto, "als_suggestions" e "zone_anomalies" saranno assenti (la skill funziona ugualmente). Può essere sovrascritto per singolo profilo con "als_skill_id" in PROFILES_CONFIG.
        Come ottenere l'UUID: Settings → Skill → als-recommender → copia Skill ID dal drawer.
      required: false
      default: ''
      secret: false
    - key: ALS_MODEL_NAME
      description: |
        Fallback globale: modello als-recommender da usare. Può essere sovrascritto per singolo profilo con "als_model_name" in PROFILES_CONFIG. Default: default
      required: false
      default: default
      secret: false
    - key: ALS_TOP_N
      description: |
        Fallback globale: numero massimo di suggerimenti ML. Può essere sovrascritto per singolo profilo con "als_top_n" in PROFILES_CONFIG. Default: 6
      required: false
      default: '6'
      secret: false
    - key: ALS_SUGGEST_MODE
      description: |
        Fallback globale: strategia di suggerimento ML per le zone mancanti. Può essere sovrascritto per singolo profilo con "als_suggest_mode" in PROFILES_CONFIG.
        - recommend (default): seed = item classificati → recommend.py.
          Fallback 1: hint zone mancanti. Fallback 2: cold-start popular.py.
        - similar: similar.py sul primo item di ogni zona coperta (item-item coseno, max 3).
          Fallback: popular.py.

        Default: recommend
      required: false
      default: recommend
      secret: false
    - key: ALS_ANOMALY_CHECK
      description: |
        Fallback globale: attiva rilevamento anomalie per zona (anomalies.py). Può essere sovrascritto per singolo profilo con "als_anomaly_check" in PROFILES_CONFIG. Accetta: true | false. Default: false
      required: false
      default: 'false'
      secret: false
    - key: ALS_ANOMALY_THRESHOLD
      description: |
        Fallback globale: soglia anomalia (0.0 – 1.0). Può essere sovrascritto per singolo profilo con "als_anomaly_threshold" in PROFILES_CONFIG. Valori guida: 0.05 (evidenti) · 0.10 (default) · 0.20 (borderline inclusi). Default: 0.1
      required: false
      default: '0.1'
      secret: false
  scripts:
    - filename: scripts/analyze.py
      language: python
      llm_callable: true
      description: |
        Analizza la copertura funzionale di un insieme di elementi rispetto alle zone del profilo selezionato. Classifica ciascun elemento tramite mapping esatto o keyword matching, valuta la copertura per zona e restituisce un report JSON.
        Il profilo si specifica con il campo "profile" nell'input (es. "negozio"). Se omesso, usa DEFAULT_PROFILE (default: "default"). Ogni profilo ha zone, mapping e modello ALS propri — zero config da cambiare.
        Se ALS_SKILL_ID è configurato, arricchisce il report con: (1) Suggerimenti ML per le zone mancanti (recommend.py o similar.py, config ALS_SUGGEST_MODE),
            con cold-start automatico via popular.py se nessun seed disponibile.
            Se "subject_id" è fornito nell'input (o estratto automaticamente da rows[0] tramite
            columns.subject di zones.py), usa direttamente il vettore soggetto ALS
            (più preciso dei seed — priorità su tutti gli altri fallback).
        (2) Profilo del cluster di appartenenza via cluster_profiles.py: oggetti tipici
            del segmento a cui appartiene il soggetto corrente (complementare ai suggerimenti).
            Disponibile solo in modalità recommend, solo se il modello ha clustering (≥12 soggetti).
        (3) Anomalie per zona via anomalies.py (se ALS_ANOMALY_CHECK=true). Tutte le chiamate ALS sono non-bloccanti.
      input_schema:
        type: object
        required:
          - rows
        properties:
          profile:
            type: string
            description: |
              Nome del profilo da usare per l'analisi. Deve corrispondere a una chiave di PROFILES_CONFIG (es. "negozio", "ristorante"). Se omesso, usa il profilo indicato in DEFAULT_PROFILE (default: "default").
          rows:
            type: array
            description: |
              Array di oggetti rappresentanti gli elementi da analizzare. Ogni oggetto deve avere le colonne configurate in COLUMN_ID, COLUMN_NAME, COLUMN_OBJECT (default: id, name, object). Tipicamente è l'output diretto del SQL tool — passalo senza conversioni.
            items:
              type: object
          subject_id:
            type: string
            description: |
              ID del soggetto nel modello ALS (es. "proj_42", "order_789"). Se fornito, i suggerimenti ML usano il vettore soggetto salvato durante il training — più preciso della media dei seed, perché cattura l'intera storia del soggetto anziché solo gli item presenti nell'analisi corrente. Corrisponde a COLUMN_SUBJECT del modello ALS associato al profilo. Fallback automatico ai seed se il soggetto non è nel modello. Ignorato se als_suggest_mode = "similar". NOTA: se il profilo ha "column_subject" configurato e la query SQL usa columns.subject come alias (suggerito da zones.py), analyze.py estrae automaticamente subject_id da rows[0] — non è necessario passarlo a mano.
          context:
            type: object
            description: |
              Dizionario di valori contestuali per valutare le condizioni required_if (es. {"mq": 45, "tipo": "flagship"}).
    - filename: scripts/zones.py
      language: python
      llm_callable: true
      description: |
        Restituisce i profili configurati e le zone di ciascuno. Senza "profile": elenca tutti i profili disponibili con un riepilogo. Con "profile": mostra le zone dettagliate del profilo e il campo "columns" con i nomi esatti delle colonne attesi nei "rows" di analyze.py (subject, id, name, object risolti per il profilo). Chiamare SEMPRE prima di costruire la query SQL o chiamare analyze.py. Usare columns.subject, columns.id, columns.name, columns.object come alias AS nella query. columns.subject è la colonna soggetto (es. cod progetto/utente/negozio): includerla nel SELECT permette ad analyze.py di estrarre automaticamente subject_id per i suggerimenti ML.
      input_schema:
        type: object
        required: []
        properties:
          profile:
            type: string
            description: |
              Nome del profilo di cui mostrare le zone. Se omesso, restituisce la lista di tutti i profili disponibili.
          context:
            type: object
            description: |
              Contesto opzionale per valutare le condizioni required_if. Usato solo quando "profile" è specificato.
    - filename: scripts/info.py
      language: python
      mode: info
      llm_callable: false
      description: |
        Mostra lo stato della configurazione della skill: profili definiti, zone per profilo, configurazione ALS globale e colonne di fallback. Eseguito automaticamente dall'UI all'apertura del drawer.
---

# Coverage Check

Analizza la copertura funzionale di un insieme di elementi rispetto a **zone configurabili**.
Supporta **più profili** (es. "negozio", "ristorante") — una sola installazione per tutti i domini.
Classifica ogni elemento tramite lookup diretto o keyword matching e restituisce un report JSON
con score di copertura, suggerimenti ML e anomalie per zona (via als-recommender).

## Quando usare questa skill

- L'utente vuole sapere se un set di elementi copre tutte le aree funzionali del suo dominio
- L'utente chiede "cosa manca?", "siamo completi?", "qual è la copertura?"
- Un'altra skill chiede un'analisi di completezza via inter-skill bus

**Non** usarla senza aver configurato prima `PROFILES_CONFIG` dal pannello della skill.

---

## Rete (network)

Nessuna connessione esterna: la skill opera in locale e/o via backend interno.

<!-- @tool: zones.py -->

## Quando usare `zones.py`

Usa `zones.py` per **scoprire la configurazione** prima di analizzare.

**⚠️ Chiamala SEMPRE prima di costruire una query SQL o di chiamare `analyze.py`.**
L'output include il campo `columns` con i nomi esatti delle colonne attesi nei `rows`.
Usali come alias `AS` nella query SQL.

**Senza `profile`** → elenca tutti i profili disponibili:
```json
{ "profile": null }
```

**Con `profile`** → mostra zone + colonne del profilo:
```json
{ "profile": "negozio", "context": { "mq": 60 } }
```

### Output senza profile

```json
{
  "success": true,
  "profiles": [
    { "name": "negozio",    "zone_count": 5, "als_model_name": "negozio",    "is_default": true },
    { "name": "ristorante", "zone_count": 4, "als_model_name": "ristorante", "is_default": false }
  ],
  "total": 2,
  "default": "negozio"
}
```

### Output con profile

```json
{
  "success": true,
  "profile": "negozio",
  "zones": [
    {
      "id": "bancone",
      "label": "🏪 Bancone / Cassa",
      "required": true,
      "conditional": false,
      "min_items": 1,
      "hint": "bancone cassa checkout",
      "keywords": ["bancone", "cassa"]
    }
  ],
  "total": 5,
  "required": 3,
  "conditional": 1,
  "optional": 1,
  "als_model_name": "negozio",
  "columns": {
    "subject": "cod_negozio",
    "id":      "cod_articolo",
    "name":    "descrizione",
    "object":  "categoria"
  },
  "context": { "mq": 60 },
  "context_required": ["bancone", "illuminazione", "scaffalature"]
}
```

### Campo `columns`

Contiene i nomi delle colonne che `analyze.py` si aspetta nei `rows` per questo profilo.
Usali come alias `AS` nella query SQL:

```sql
SELECT
  n.codice    AS cod_negozio,    -- ← columns.subject (= COLUMN_SUBJECT del modello ALS)
  e.codice    AS cod_articolo,   -- ← columns.id
  e.des_breve AS descrizione,    -- ← columns.name
  c.nome      AS categoria       -- ← columns.object  (= COLUMN_OBJECT del modello ALS)
FROM elementi e
LEFT JOIN categorie c ON c.id = e.id_cat
LEFT JOIN negozi n    ON n.id = e.id_negozio
WHERE n.codice = 'N042'
```

> **`columns.subject`** — la colonna soggetto (es. codice negozio, ID progetto, ID utente).
> Includila nel SELECT: `analyze.py` leggerà automaticamente `rows[0]["cod_negozio"]`
> e lo userà come `subject_id` per i suggerimenti ML, senza che tu lo passi a mano.
>
> **`columns.object`** corrisponde a `COLUMN_OBJECT` del modello ALS associato al profilo.

---

<!-- @tool: analyze.py -->

## Quando usare `analyze.py`

Usa `analyze.py` per **analizzare la copertura** di un set di elementi.

### Flusso tipico con SQL tool

> "Analizza la copertura funzionale del progetto 123 (profilo negozio)"

**Step 1 — Scopri le colonne del profilo** chiamando `zones.py`:
```json
{ "profile": "negozio" }
```
Risposta → `columns: { "subject": "cod_negozio", "id": "cod_articolo", "name": "descrizione", "object": "categoria" }`

**Step 2 — Esegui la query SQL** usando i valori di `columns` come alias `AS`
(includi **sempre** `columns.subject` — permette l'auto-estrazione di `subject_id`):
```sql
SELECT
  n.codice    AS cod_negozio,    -- ← columns.subject → subject_id auto-estratto
  e.codice    AS cod_articolo,   -- ← columns.id
  e.des_breve AS descrizione,    -- ← columns.name
  c.nome      AS categoria       -- ← columns.object
FROM elementi e
LEFT JOIN categorie c ON c.id = e.id_cat
LEFT JOIN negozi n    ON n.id = e.id_negozio
WHERE n.codice = 'N042'
```

**Step 3 — Chiama `analyze.py`** con il risultato SQL:
```json
{
  "profile": "negozio",
  "rows": [
    { "cod_negozio": "N042", "cod_articolo": "ART001", "descrizione": "Bancone 200cm", "categoria": "Bancone Principale" },
    { "cod_negozio": "N042", "cod_articolo": "ART002", "descrizione": "LED Strip 3m",  "categoria": "Illuminazione LED"  }
  ],
  "context": { "mq": 60, "tipo": "flagship" }
}
```
> `subject_id` viene estratto automaticamente da `rows[0]["cod_negozio"]` → `"N042"`.
> Non è necessario passarlo esplicitamente se `columns.subject` è nel SELECT.
```

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|---|---|:---:|---|
| `profile` | string | ❌ | Profilo da usare (es. `"negozio"`). Default: `DEFAULT_PROFILE` config |
| `rows` | array | ✅ | Elementi da analizzare (output SQL tool) |
| `context` | object | ❌ | Valori per required_if (es. `{"mq": 45, "tipo": "flagship"}`) |
| `subject_id` | string | ❌ | ID soggetto nel modello ALS (es. `"N042"`). Se fornito, i suggerimenti ML usano il vettore soggetto salvato dal training — più preciso dei seed. **Auto-estratto** da `rows[0][columns.subject]` se `column_subject` è configurato nel profilo. Ignorato in modalità `similar`. |

### Output

```json
{
  "success": true,
  "profile": "negozio",
  "score": 75,
  "zones_required": 4,
  "zones_covered": 3,
  "complete": [
    { "zone": "bancone", "label": "🏪 Bancone / Cassa", "count": 1, "examples": ["Bancone 200cm"] }
  ],
  "missing": [
    { "zone": "scaffalature", "label": "📦 Scaffalature", "hint": "scaffale espositore" }
  ],
  "optional_missing": [
    { "zone": "cassa_self", "label": "🤖 Cassa Self-Service", "hint": "..." }
  ],
  "unclassified": [
    { "id": "ELEM099", "name": "Elemento sconosciuto", "object": null }
  ],
  "als_suggestions": [
    { "object": "Scaffalature Centrali", "score": 0.87 }
  ],
  "als_source": "recommend_subject",
  "cluster_profile": {
    "cluster_id": 1,
    "cluster_name": "Segmento 1",
    "cluster_similarity": 0.73,
    "typical_objects": [
      { "object": "Bancone Principale",    "score": 1.24 },
      { "object": "Scaffalature Centrali", "score": 1.11 }
    ]
  },
  "zone_anomalies": [
    {
      "zone": "bancone",
      "label": "🏪 Bancone / Cassa",
      "anomalies": [
        { "object": "Sedie Ufficio", "score": 0.03, "reason": "Score 0.03 < soglia 0.1" }
      ],
      "context_coherence": { "Bancone 200cm": 0.82, "Sedie Ufficio": 0.03 }
    }
  ],
  "context": { "mq": 60 },
  "subject_id": "proj_123",
  "elapsed_s": 0.21,
  "items_analyzed": 5
}
```

**Campo `als_source`** — strategia usata per i suggerimenti:

| Valore | Strategia |
|---|---|
| `recommend_subject` | Vettore soggetto ALS (subject_id fornito e trovato nel modello) |
| `recommend` | Seed dagli oggetti classificati |
| `recommend_hints` | Hint delle zone mancanti come seed |
| `similar` | Similarità coseno oggetto-oggetto |
| `popular` | Cold-start (oggetti più frequenti nel training) |

**Campo `cluster_profile`** — presente solo in modalità `recommend*` se il modello ha
clustering (≥ 12 soggetti nel training). Mostra gli oggetti tipici del segmento a cui
appartiene il soggetto corrente — complementare a `als_suggestions`.

### Come presentare il risultato

```
📊 Copertura funzionale [negozio]: 3/4 zone (75%)

✅ Zone coperte:
- 🏪 Bancone / Cassa — 1 elemento (es: Bancone 200cm)

❌ Zone mancanti (obbligatorie):
- 📦 Scaffalature — nessun elemento trovato

ℹ️ Zone opzionali non presenti:
- 🤖 Cassa Self-Service (non richiesta nel contesto)

🤖 Suggerimenti ML (Segmento 1 — 73% affinità):
- Scaffalature Centrali (score: 0.87)

📌 Tipico per il tuo segmento:
- Bancone Principale, Scaffalature Centrali

⚠️ Anomalie rilevate:
- 🏪 Bancone / Cassa: "Sedie Ufficio" ha coerenza del 3% → probabile errore
```

---

## Configurazione multi-profilo

### Struttura `PROFILES_CONFIG`

```json
{
  "negozio": {
    "column_id":     "cod_articolo",
    "column_name":   "descrizione",
    "column_object": "categoria",
    "als_skill_id":           "",
    "als_model_name":         "negozio",
    "als_top_n":              6,
    "als_suggest_mode":       "recommend",
    "als_anomaly_check":      true,
    "als_anomaly_threshold":  0.1,
    "zones": {
      "bancone": {
        "label": "Bancone / Cassa",
        "icon": "🏪",
        "required": true,
        "min_items": 1,
        "hint": "bancone cassa checkout",
        "keywords": ["bancone", "cassa", "checkout"]
      },
      "illuminazione": {
        "label": "Illuminazione",
        "icon": "💡",
        "required": false,
        "required_if": { "field": "mq", "op": "gte", "value": 30 },
        "min_items": 1,
        "hint": "illuminazione led luce",
        "keywords": ["illuminazione", "led", "luce", "plafoniera"]
      }
    },
    "mapping": {
      "Bancone Principale": "bancone",
      "Banco Cassa":        "bancone",
      "LED Strip":          "illuminazione"
    }
  }
}
```

### Gerarchia di risoluzione

```
profilo.<campo>  →  config globale (ALS_* / COLUMN_*)  →  default hardcoded
```

I campi omessi dal profilo ereditano il valore globale. Questo permette di
condividere `als_skill_id` tra tutti i profili e sovrascrivere solo `als_model_name`.

### Come aggiungere un nuovo profilo

1. Vai su Settings → coverage-check → `PROFILES_CONFIG`
2. Aggiungi la nuova chiave con zone e mapping
3. Addestra il modello ALS corrispondente con `train.py` e `model_name = als_model_name`
4. Passa `"profile": "nuovo_profilo"` nelle chiamate a `analyze.py`

Zero re-upload della skill — tutto configurabile dal pannello.

---

## Integrazione con als-recommender

| Config | Descrizione |
|---|---|
| `ALS_SKILL_ID` | UUID della skill als-recommender |
| `ALS_MODEL_NAME` | Modello globale di fallback (sovrascrivibile per-profilo) |
| `ALS_TOP_N` | Max suggerimenti da restituire (default: 6) |
| `ALS_SUGGEST_MODE` | `recommend` (default) o `similar` |
| `ALS_ANOMALY_CHECK` | `true` / `false` — attiva anomaly detection per zona |
| `ALS_ANOMALY_THRESHOLD` | Soglia anomalia 0.0–1.0 (default: 0.1) |

### Script ALS richiamati da `analyze.py`

| Script | Quando | Input inviato |
|---|---|---|
| `recommend.py` | Suggerimenti (modalità recommend) | `subject_id` o `seed_objects` |
| `cluster_profiles.py` | Dopo ogni recommend riuscito con cluster_id | `top_n` |
| `similar.py` | Suggerimenti (modalità similar) | `reference_object` per zona |
| `popular.py` | Cold-start fallback | `top_n` |
| `anomalies.py` | Per zona con ≥ 2 elementi (se anomaly_check=true) | `seed_objects`, `threshold` |

---

## Invocazione da un'altra skill (inter-skill bus)

```python
import os, json, urllib.request

def invoke_coverage_check(profile, rows, context=None, subject_id=None, timeout_s=15):
    skill_id = _config.get('COVERAGE_SKILL_ID', '').strip()
    if not skill_id:
        return None

    inp = {'profile': profile, 'rows': rows}
    if context:
        inp['context'] = context
    if subject_id:
        inp['subject_id'] = subject_id

    url  = f"{os.environ['BACKEND_INTERNAL_URL']}/internal/skills/{skill_id}/invoke"
    body = json.dumps({'script': 'analyze.py', 'input': inp}).encode()
    req  = urllib.request.Request(url, data=body, method='POST', headers={
        'Content-Type':       'application/json',
        'x-internal-token': os.environ['INTERNAL_TOKEN'],
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as r:
            return json.loads(r.read()).get('output')
    except Exception:
        return None
```
