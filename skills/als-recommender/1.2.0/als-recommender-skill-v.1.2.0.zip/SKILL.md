---
name: als-recommender
description: |
  Addestra e interroga un modello ALS (Alternating Least Squares) di Collaborative Filtering a partire da un dataset CSV caricato dall'utente. Supporta tre varianti: iALS (feedback implicito), ALS esplicito, ALS con bias. Il modello addestrato può essere invocato da altre skill via inter-skill bus (BACKEND_INTERNAL_URL/internal/skills/{SKILL_ID}/invoke).
version: 1.2.0
author: personalAgent
license: MIT
runtime:
  dependencies:
    python:
      - numpy>=1.26
      - scipy>=1.13
      - implicit>=0.7.2
  network: []
  config:
    - key: ALS_TYPE
      description: |
        Variante ALS da addestrare.
        - implicit  (iALS): feedback implicito — usa count/binario (presenze, acquisti, visite).
                            Formula confidenza: c_ui = 1 + alpha * count.
                            Ideale per: co-occorrenze prodotti/categorie, storico ordini,
                            log navigazione, qualsiasi dato senza rating espliciti.

        - explicit:         feedback esplicito — usa rating numerici (es. 1-5 stelle).
                            Minimizza ||R - UV^T||^2 sulle celle osservate + L2 regularization.
                            Ideale per: recensioni, valutazioni, sondaggi con punteggi.

        - biased:           feedback esplicito con bias.
                            Modello: r_ui ≈ mu + b_u + b_i + U_u·V_i
                            Corregge la popolarità globale (mu), il bias utente (b_u)
                            e il bias oggetto (b_i — elementi sempre presenti/assenti).
                            Ideale per: rating con forti effetti di popolarità,
                            o dati impliciti dove alcuni oggetti compaiono quasi sempre.

        Default: implicit
      required: true
      default: implicit
      secret: false
    - key: ALS_FACTORS
      description: |
        Dimensioni dello spazio latente (numero di fattori nascosti). Valori più alti catturano pattern più complessi ma aumentano il rischio di overfitting.
        Linee guida:
          - Dataset piccolo  (<100 oggetti):    8–32
          - Dataset medio   (100-1000 oggetti): 32–64
          - Dataset grande  (>1000 oggetti):    64–128

        Default: 32
      required: false
      default: '32'
      secret: false
    - key: ALS_ITERATIONS
      description: |
        Numero di iterazioni (epoche) dell'algoritmo ALS. Ogni iterazione aggiorna prima la matrice U (soggetti), poi la matrice V (oggetti). Convergenza tipica: 15-30 iterazioni. Aumentare se la loss non converge; diminuire per velocizzare il training.
        Default: 20
      required: false
      default: '20'
      secret: false
    - key: ALS_REGULARIZATION
      description: |
        Coefficiente di regolarizzazione L2 (lambda). Penalizza norme elevate dei vettori latenti — riduce overfitting. Valori tipici: 0.01 (poco regolarizzato) → 0.5 (molto regolarizzato).
        Default: 0.05
      required: false
      default: '0.05'
      secret: false
    - key: ALS_ALPHA
      description: |
        Moltiplicatore di confidenza per ALS_TYPE=implicit (iALS). Controlla quanto peso dare agli oggetti con count più alto:
          confidence_ui = 1 + alpha * count_ui
        Un alpha più alto amplifica la differenza tra count=1 e count=10. Ignorato da explicit e biased.
        Range tipico: 10–100. Default: 40
      required: false
      default: '40'
      secret: false
    - key: COLUMN_SUBJECT
      description: |
        Nome della colonna nel dataset che identifica il soggetto (asse righe della matrice ALS). Il soggetto raggruppa gli oggetti co-occorrenti nello stesso contesto.
        Esempi: "project_id", "order_id", "user_id", "session_id", "store_id"
        Il dataset deve avere questa struttura minima:
          {COLUMN_SUBJECT},{COLUMN_OBJECT}[,{COLUMN_VALUE}]
          proj_1,Bancone Principale,1
          proj_1,Illuminazione LED,2
          proj_2,Bancone Principale,1

        Default: subject_id
      required: false
      default: subject_id
      secret: false
    - key: COLUMN_OBJECT
      description: |
        Nome della colonna nel dataset che identifica l'oggetto (asse colonne della matrice ALS). È il valore che viene raccomandato, ricercato per similarità o analizzato per anomalie.
        Esempi: "product_id", "category", "cod_prod", "book_id", "tag"
        Deve corrispondere a column_object nel profilo della skill coverage-check, se usata.
        Default: object_id
      required: false
      default: object_id
      secret: false
    - key: COLUMN_VALUE
      description: |
        Nome della colonna nel CSV con il valore numerico dell'interazione.
        Per ALS_TYPE=implicit:
          Count di interazioni (es. quante volte l'oggetto è apparso nel soggetto).
          Se la colonna mancante o vuota → assume 1 (presenza binaria).

        Per ALS_TYPE=explicit o biased:
          Rating esplicito (es. 1-5 stelle). La colonna è obbligatoria.
          Valori non numerici in questa colonna vengono ignorati.

        Default: value
      required: false
      default: value
      secret: false
    - key: MODEL_NAME
      description: |
        Nome del modello da addestrare o usare per le raccomandazioni. Permette di gestire più modelli distinti nella stessa istanza della skill. Ogni modello viene salvato in una sotto-directory separata:
          SKILLS_OUTPUT_DIR/als-recommender/{SKILL_ID}/{MODEL_NAME}/model.pkl

        Esempi:
          "default"    — un solo modello (comportamento standard)
          "negozio"    — modello addestrato su dati di un punto vendita
          "ristorante" — modello addestrato su dati ristorazione
          "clienteXYZ" — modello dedicato a un cliente specifico

        Può essere sovrascritto per-chiamata passando "model_name" nell'input (utile quando una skill chiama recommend.py via inter-skill bus con modelli diversi a seconda del contesto).
        Default: default
      required: false
      default: default
      secret: false
  scripts:
    - filename: scripts/info.py
      language: python
      mode: info
      llm_callable: false
      description: |
        Script di stato: elenca i modelli ALS addestrati per questa istanza della skill. Mostra nome, tipo ALS, numero di oggetti/soggetti, fattori latenti e data di training. Viene eseguito automaticamente dall'UI — non richiede input e non è esposto all'LLM.
    - filename: scripts/train.py
      language: python
      llm_callable: true
      description: |
        Addestra il modello ALS sul dataset fornito e salva il modello pkl. Salva in SKILLS_OUTPUT_DIR/als-recommender/{SKILL_ID}/{model_name}/model.pkl. Il tipo di modello è determinato dalla config ALS_TYPE (implicit/explicit/biased). Supporta più modelli distinti tramite il campo model_name (default: "default").
        Accetta i dati in tre formati (in ordine di priorità):
          1. rows        — array JSON di oggetti, output diretto del SQL tool.
                           Ideale per dataset grandi: bypassa il context dell'LLM.
          2. csv_content — stringa CSV inline. Per dataset piccoli (< 500 righe).
          3. csv_path    — path assoluto di un file CSV già uploadato su disco.
      input_schema:
        type: object
        required: []
        properties:
          model_name:
            type: string
            description: |
              Nome del modello da addestrare. Permette di gestire più modelli distinti nella stessa istanza della skill, uno per cliente/dominio/contesto.
              Il modello viene salvato in:
                SKILLS_OUTPUT_DIR/als-recommender/{SKILL_ID}/{model_name}/model.pkl

              Esempi: "default", "negozio", "ristorante", "clienteXYZ"
              Se non specificato, usa il valore della config MODEL_NAME (default: "default"). Passarlo esplicitamente permette di addestrare modelli diversi senza cambiare la configurazione della skill.
          rows:
            type: array
            description: |
              Array JSON di oggetti — output diretto del SQL tool o di qualsiasi sorgente dati strutturata. Formato prioritario: se presente, ignora csv_content e csv_path.
              Le chiavi degli oggetti devono corrispondere alle config COLUMN_SUBJECT, COLUMN_OBJECT e opzionalmente COLUMN_VALUE.
              Esempio (output SQL tool):
                [
                  {"subject_id": "proj_1", "object_id": "Bancone Principale",    "value": 1},
                  {"subject_id": "proj_1", "object_id": "Scaffalature Centrali", "value": 2},
                  {"subject_id": "proj_2", "object_id": "Bancone Principale",    "value": 1}
                ]

              Pipeline tipica SQL tool → training:
                1. SQL tool: SELECT p.id AS subject_id, c.categoria AS object_id
                             FROM progetti p JOIN ... WHERE p.completato=1
                2. train.py: { "rows": <risultato SQL>, "model_name": "negozio" }

              IMPORTANTE: le chiavi degli oggetti devono usare gli stessi nomi configurati in COLUMN_SUBJECT (default: subject_id) e COLUMN_OBJECT (default: object_id). Usare AS negli alias SQL.
          csv_content:
            type: string
            description: |
              Contenuto del CSV come stringa (inline). Usare per dataset piccoli (< 500 righe) o quando si incolla il CSV direttamente in chat. Ignorato se rows è presente.
              Esempio:
                subject_id,object_id,value
                proj_1,Bancone Principale,1
                proj_1,Scaffalature Centrali,2
          csv_path:
            type: string
            description: |
              Path assoluto del file CSV già salvato su disco (es. da un upload). Ignorato se rows o csv_content sono presenti.
    - filename: scripts/recommend.py
      language: python
      llm_callable: true
      description: |
        Raccomanda oggetti correlati usando il modello ALS addestrato. Funziona con tutti e tre i tipi (implicit, explicit, biased). Restituisce una lista di {object, score} ordinata per rilevanza.
        Supporta due modalità di input (almeno una è obbligatoria):
          - seed_objects: lista oggetti noti → pseudo-soggetto come media dei vettori seed
            (o ALS One-Step per implicit — mode: "seed_cold_start").
            Funziona anche con combinazioni di oggetti mai viste nel training.
          - subject_id:  ID soggetto esistente → usa il vettore soggetto salvato.
            Più preciso quando il soggetto è nel training; non richiede seed.

        Il campo "mode" nell'output indica la strategia usata:
          - "seed"             — media semplice dei vettori seed
          - "seed_cold_start"  — ALS One-Step per implicit (più accurato)
          - "subject"          — vettore soggetto salvato durante il training

        Se il modello include clustering KMeans (dataset con ≥ 12 soggetti), l'output include anche: cluster_id, cluster_name, cluster_similarity.
        Può essere invocato dall'LLM oppure da altre skill via POST /internal/skills/{SKILL_ID}/invoke.
      input_schema:
        type: object
        required: []
        properties:
          model_name:
            type: string
            description: |
              Nome del modello da usare per le raccomandazioni. Deve corrispondere al model_name usato durante il training. Se non specificato, usa il valore della config MODEL_NAME (default: "default"). Esempi: "negozio", "ristorante", "clienteXYZ"
          seed_objects:
            type: array
            description: |
              Lista degli oggetti già presenti nel contesto (modalità seed). Devono corrispondere ai valori della colonna COLUMN_OBJECT del training. Obbligatorio se subject_id non è fornito. Esempio: ["Bancone Principale", "Illuminazione LED"]
          subject_id:
            type: string
            description: |
              ID di un soggetto esistente nel dataset di training (modalità subject). Usa direttamente il vettore soggetto salvato durante il training — nessun seed da specificare. Obbligatorio se seed_objects non è fornito. Esempio: "proj_42"
          top_n:
            type: number
            description: 'Numero massimo di raccomandazioni da restituire. Default: 6'
          exclude:
            type: array
            description: Oggetti aggiuntivi da escludere dai risultati (oltre ai seed stessi).
          min_score:
            type: number
            description: 'Score minimo (0.0-1.0) per includere una raccomandazione. Default: 0.0'
    - filename: scripts/similar.py
      language: python
      llm_callable: true
      description: |
        Trova oggetti simili a un oggetto di riferimento nello spazio latente ALS usando la similarità coseno tra vettori oggetto (object-object similarity).
        A differenza di recommend.py (che costruisce un pseudo-soggetto), similar.py misura la vicinanza geometrica: due oggetti sono simili se compaiono in contesti analoghi nel training.
        Utile per: trovare alternative/varianti, diagnosi del modello, suggerire complementi a partire da un singolo oggetto noto.
      input_schema:
        type: object
        required:
          - reference_object
        properties:
          reference_object:
            type: string
            description: |
              Oggetto di riferimento per la similarità. Deve corrispondere a un valore nella colonna COLUMN_OBJECT del training. Esempio: "Bancone Principale"
          model_name:
            type: string
            description: |
              Nome del modello da usare. Se non specificato, usa il valore della config MODEL_NAME (default: "default").
          top_n:
            type: number
            description: 'Numero massimo di oggetti simili da restituire. Default: 10'
          exclude:
            type: array
            description: Oggetti aggiuntivi da escludere dai risultati.
          min_similarity:
            type: number
            description: |
              Soglia minima di similarità coseno (range -1.0 a 1.0). Default: -1.0 (nessun filtro). Usa 0.5+ per risultati molto affini.
    - filename: scripts/cluster_profiles.py
      language: python
      llm_callable: true
      description: |
        Analizza i cluster generati durante l'addestramento e restituisce i profili tipici (gli oggetti più rappresentativi) per ogni segmento identificato dal K-Means. Utile per dare un significato semantico ai cluster (es. capire cosa caratterizza il "Segmento 0").
      input_schema:
        type: object
        required: []
        properties:
          model_name:
            type: string
            description: 'Nome del modello da interrogare (default: config MODEL_NAME).'
          top_n:
            type: number
            description: 'Numero di oggetti tipici da estrarre per ogni cluster. Default: 5.'
    - filename: scripts/anomalies.py
      language: python
      llm_callable: true
      description: |
        Analizza una lista di oggetti (es. un progetto in corso o un carrello) e trova le anomalie. Un'anomalia è un oggetto che è presente nella lista fornita, ma il cui score matematico previsto dal modello ALS è estremamente basso rispetto al resto degli elementi. Utile per trovare errori di data-entry, scelte fuori dagli schemi o composizioni atipiche.
        Algoritmo: costruisce il profilo del gruppo come media dei vettori seed, calcola lo score di ciascun oggetto rispetto al profilo, normalizza in [0, 1] e segnala come anomalia ogni oggetto con score < threshold.
        ⚠ Richiede almeno 2 oggetti in seed_objects per poter calcolare un profilo di gruppo.
      input_schema:
        type: object
        required:
          - seed_objects
        properties:
          seed_objects:
            type: array
            description: |
              La lista degli oggetti presenti nel contesto da analizzare. Minimo 2 oggetti (con 1 solo oggetto non si può calcolare l'anomalia di contesto).
          threshold:
            type: number
            description: 'Soglia (0.0 - 1.0) sotto la quale un oggetto è considerato anomalo. Default: 0.1'
          model_name:
            type: string
            description: 'Nome del modello da usare (default: config MODEL_NAME).'
    - filename: scripts/popular.py
      language: python
      llm_callable: true
      description: |
        Fornisce la lista degli oggetti globalmente più popolari (frequenti) nel dataset di addestramento. Si usa ESCLUSIVAMENTE come strategia di Cold Start (fallback): usalo quando devi fare una raccomandazione per un utente/progetto completamente nuovo di cui non conosci ancora nessun seed/oggetto.
      input_schema:
        type: object
        required: []
        properties:
          top_n:
            type: number
            description: 'Numero di oggetti popolari da restituire. Default: 10.'
          model_name:
            type: string
            description: 'Nome del modello da interrogare (default: config MODEL_NAME).'
---

# ALS Recommender

Skill di Collaborative Filtering basata su ALS (Alternating Least Squares).
Addestra un modello di raccomandazione su dati tabulari e suggerisce
oggetti correlati ai seed forniti. Supporta tre varianti algoritmiche.

## Varianti disponibili (config `ALS_TYPE`)

| Variante | Quando usarla | Colonna value |
|---|---|---|
| `implicit` | Co-occorrenze, acquisti, presenze binarie | count (opzionale, default 1) |
| `explicit` | Rating espliciti (1-5 stelle, punteggi) | rating (obbligatorio) |
| `biased`   | Rating con correzione popolarità | rating (obbligatorio) |

---

## Funzionalità avanzate

### Cold-Start (ALS One-Step)
Quando si forniscono `seed_objects` mai visti insieme nel training, `recommend.py` usa
**ALS One-Step**: risolve un sistema lineare per stimare il profilo latente più probabile,
più accurato della semplice media vettoriale.

### Segmentazione automatica (Clustering)
Se il dataset ha ≥ 12 soggetti, il training esegue un clustering KMeans.
Ogni risposta di `recommend.py` include:
- `cluster_id`: ID del cluster assegnato.
- `cluster_name`: Nome del segmento (es. "Segmento 2").
- `cluster_similarity`: Affinità con il centroide del cluster.

---

## Rete (network)

Nessuna connessione esterna: la skill opera in locale e/o via backend interno.

<!-- @tool: train.py -->

## Quando usare `train.py`

Usa questo script **solo** quando l'utente vuole addestrare il modello:
- Fornisce un file CSV o dati con lo storico
- Dice esplicitamente "addestra", "train", "aggiorna il modello"
- Il modello non esiste ancora (prima esecuzione)

**Non** chiamarlo per fare raccomandazioni — usa `recommend.py`.

## Come usare `train.py`

Tre formati di input (in ordine di priorità):

| Campo | Tipo | Priorità | Quando usarlo |
|---|---|:---:|---|
| `rows` | array JSON | 1 ← | Output diretto SQL tool, dataset grandi |
| `csv_content` | string | 2 | CSV incollato in chat, dataset piccoli |
| `csv_path` | string | 3 | File CSV già uploadato su disco |

### Formato 1 — `rows` (consigliato per dati dal gestionale)

Pipeline completa:
> "Esegui questa query sul gestionale e addestra il modello ALS con nome 'negozio'"

1. Chiama il SQL tool → ottieni array di righe
2. Chiama `train.py` con `{ "rows": <risultato SQL>, "model_name": "negozio" }`

```json
{
  "model_name": "negozio",
  "rows": [
    {"subject_id": "proj_1", "object_id": "Bancone Principale"},
    {"subject_id": "proj_1", "object_id": "Scaffalature Centrali"},
    {"subject_id": "proj_2", "object_id": "Bancone Principale"}
  ]
}
```

**⚠️ Regola alias SQL**: le colonne devono usare gli stessi nomi delle config
`COLUMN_SUBJECT` e `COLUMN_OBJECT` (default: `subject_id`, `object_id`):

```sql
SELECT p.id         AS subject_id,   -- ← deve matchare COLUMN_SUBJECT
       c.categoria  AS object_id     -- ← deve matchare COLUMN_OBJECT
FROM progetti p
JOIN righe_progetto r ON r.id_progetto = p.id
JOIN catalogo_prodotti cp ON cp.cod_prodotto = r.cod_prodotto
LEFT JOIN categorie c ON c.id_categoria = cp.id_categoria
WHERE p.completato = 1
GROUP BY p.id, c.categoria
```

### Formato 2 — `csv_content` (dataset piccoli)

```
subject_id,object_id,value
proj_1,Bancone Principale,1
proj_1,Scaffalature Centrali,2
proj_2,Bancone Principale,1
```

### Formato 3 — `csv_path`

```json
{ "csv_path": "/app/uploads/training_data.csv" }
```

### Output

```json
{
  "success": true,
  "model_name": "negozio",
  "als_type": "implicit",
  "subjects": 842,
  "objects": 37,
  "interactions": 4210,
  "elapsed_s": 2.3,
  "message": "Modello 'negozio' IMPLICIT addestrato: 842 soggetti, 37 oggetti in 2.3s"
}
```

Presenta il risultato così:
```
✅ Modello addestrato con successo!
- Tipo: IMPLICIT (iALS)
- Soggetti: 842 | Oggetti: 37 | Interazioni: 4.210
- Tempo: 2.3s
Ora puoi usarlo per raccomandazioni.
```

---

<!-- @tool: recommend.py -->

## Quando usare `recommend.py`

Usa questo script quando:
- L'utente chiede "cosa mi consigli", "cosa manca", "suggerimenti correlati"
- L'utente ha una lista di oggetti e vuole sapere cosa aggiungere
- Un'altra skill chiede raccomandazioni via inter-skill bus

## Come usare `recommend.py`

Almeno uno tra `seed_objects` e `subject_id` è obbligatorio.

| Campo | Tipo | Obbligatorio | Descrizione |
|---|---|:---:|---|
| `seed_objects` | array[string] | ✅ se no subject_id | Oggetti già presenti nel contesto (modalità seed) |
| `subject_id` | string | ✅ se no seed_objects | ID soggetto esistente nel training (modalità subject) |
| `model_name` | string | ❌ | Nome modello (default: config MODEL_NAME) |
| `top_n` | number | ❌ | Max raccomandazioni (default: 6) |
| `exclude` | array[string] | ❌ | Oggetti aggiuntivi da escludere |
| `min_score` | number | ❌ | Score minimo 0.0-1.0 (default: 0.0) |

### Modalità seed (default)

```json
{ "seed_objects": ["Bancone Principale", "Illuminazione LED"], "top_n": 5 }
```

### Modalità subject

Usa il vettore soggetto salvato durante il training — più preciso dei seed.

```json
{ "subject_id": "proj_42", "top_n": 5 }
```

### Output

```json
{
  "success": true,
  "objects": [
    { "object": "Zona Consulenza",       "score": 0.87 },
    { "object": "Scaffalature Centrali", "score": 0.61 }
  ],
  "als_type": "implicit",
  "mode": "seed_cold_start",
  "model_name": "negozio",
  "model_objects": 37,
  "seeds_found": 2,
  "seeds_missing": [],
  "cluster_id": 2,
  "cluster_name": "Segmento 2",
  "cluster_similarity": 0.891
}
```

**Valori del campo `mode`:**
- `"seed"` — media vettoriale dei seed
- `"seed_cold_start"` — ALS One-Step per implicit (più accurato)
- `"subject"` — vettore soggetto salvato dal training

In modalità `subject`, l'output include `"subject_id"` invece di `seeds_found/seeds_missing`.
I campi cluster sono presenti solo se il modello ha clustering (≥ 12 soggetti nel training).

---

<!-- @tool: similar.py -->

## Quando usare `similar.py`

Usa questo script quando:
- L'utente chiede "cosa è simile a X", "alternative a X", "varianti di X"
- Vuoi capire come il modello ha raggruppato gli oggetti nello spazio latente
- Vuoi suggerire complementi partendo da un singolo oggetto

**Differenza rispetto a `recommend.py`:**
`recommend.py` costruisce un profilo soggetto e chiede "cosa si abbina a questi oggetti?".
`similar.py` misura la distanza geometrica e chiede "quali oggetti si comportano come X nel training?".

## Come usare `similar.py`

| Campo | Tipo | Obbligatorio | Descrizione |
|---|---|:---:|---|
| `reference_object` | string | ✅ | Oggetto di riferimento |
| `model_name` | string | ❌ | Nome modello (default: config MODEL_NAME) |
| `top_n` | number | ❌ | Max oggetti simili (default: 10) |
| `exclude` | array[string] | ❌ | Oggetti aggiuntivi da escludere |
| `min_similarity` | number | ❌ | Soglia coseno -1.0–1.0 (default: -1.0, nessun filtro) |

### Output

```json
{
  "success": true,
  "reference_object": "Bancone Principale",
  "similar_objects": [
    { "object": "Zona Consulenza",      "similarity": 0.94 },
    { "object": "Scaffalature Centrali","similarity": 0.81 }
  ],
  "als_type": "implicit",
  "model_name": "negozio",
  "model_objects": 37
}
```

### Risposta all'utente

```
🔍 Oggetti simili a "Bancone Principale":
- Zona Consulenza (94% simile)
- Scaffalature Centrali (81% simile)
```

---

<!-- @tool: cluster_profiles.py -->

## Quando usare `cluster_profiles.py`

Usa questo script quando:
- L'utente chiede "quali sono i profili tipici?", "cosa caratterizza ogni segmento?"
- Vuoi dare un significato semantico ai cluster
- Un'altra skill vuole conoscere gli archetipi per personalizzare il comportamento

**Prerequisito:** dataset di **almeno 12 soggetti** nel training.

## Come usare `cluster_profiles.py`

| Campo | Tipo | Obbligatorio | Descrizione |
|---|---|:---:|---|
| `model_name` | string | ❌ | Nome modello (default: config MODEL_NAME) |
| `top_n` | number | ❌ | Oggetti tipici per cluster (default: 5) |

```json
{ "model_name": "negozio", "top_n": 5 }
```

### Output

```json
{
  "success": true,
  "model_name": "negozio",
  "clusters": [
    {
      "cluster_id": 0,
      "cluster_name": "Segmento 0",
      "typical_objects": [
        { "object": "Bancone Principale",    "score": 1.24 },
        { "object": "Scaffalature Centrali", "score": 1.11 }
      ]
    },
    {
      "cluster_id": 1,
      "cluster_name": "Segmento 1",
      "typical_objects": [
        { "object": "Zona Consulenza", "score": 0.98 }
      ]
    }
  ]
}
```

### Risposta all'utente

```
📊 Profili dei segmenti (modello 'negozio'):

Segmento 0 — Allestimento completo
  • Bancone Principale, Scaffalature Centrali, Illuminazione LED

Segmento 1 — Focalizzato sul servizio
  • Zona Consulenza, Cassa, Sedute
```

> **Nota:** i nomi dei segmenti sono generici ("Segmento 0", ecc.).
> È compito dell'LLM assegnare etichette semantiche basandosi sugli oggetti tipici.

---

<!-- @tool: anomalies.py -->

## Quando usare `anomalies.py`

Usa questo script quando:
- L'utente chiede "c'è qualcosa di strano?", "questi elementi vanno insieme?"
- Vuoi rilevare errori di data-entry in una lista di oggetti
- Vuoi segnalare scelte fuori dagli schemi tipici del modello

⚠ **Richiede almeno 2 oggetti** in `seed_objects`.

## Come usare `anomalies.py`

| Campo | Tipo | Obbligatorio | Descrizione |
|---|---|:---:|---|
| `seed_objects` | array[string] | ✅ (min 2) | Lista degli oggetti da analizzare |
| `threshold` | number | ❌ | Soglia 0.0–1.0 sotto cui un oggetto è anomalo (default: 0.1) |
| `model_name` | string | ❌ | Nome modello (default: config MODEL_NAME) |

**Algoritmo:** costruisce il profilo del gruppo come media dei vettori seed, calcola lo score
di ogni oggetto rispetto al profilo, normalizza in [0,1]. Score < `threshold` → anomalia.

```json
{
  "seed_objects": ["Bancone Principale", "Illuminazione LED", "Sedie Ufficio"],
  "threshold": 0.15,
  "model_name": "negozio"
}
```

### Output

```json
{
  "success": true,
  "model_name": "negozio",
  "analyzed_items": 3,
  "anomalies_found": 1,
  "anomalies": [
    {
      "object": "Sedie Ufficio",
      "score": 0.04,
      "reason": "Score previsto (0.04) inferiore alla soglia di anomalia (0.15)."
    }
  ],
  "context_coherence": {
    "Bancone Principale": 0.82,
    "Illuminazione LED":  0.76,
    "Sedie Ufficio":      0.04
  }
}
```

### Risposta all'utente

```
⚠️ Anomalia rilevata:
- "Sedie Ufficio" appare fuori contesto (coerenza: 4%).
  Potrebbe essere un errore di data-entry o una scelta atipica.

✅ Oggetti coerenti: Bancone Principale (82%), Illuminazione LED (76%)
```

---

<!-- @tool: popular.py -->

## Quando usare `popular.py`

Usa questo script **esclusivamente come Cold Start** (fallback), quando:
- L'utente è completamente nuovo (nessun seed noto al modello)
- Tutti i seed di `recommend.py` sono in `seeds_missing`

**Non** usarlo se hai anche un solo seed valido — usa `recommend.py`.

## Come usare `popular.py`

| Campo | Tipo | Obbligatorio | Descrizione |
|---|---|:---:|---|
| `top_n` | number | ❌ | Oggetti popolari da restituire (default: 10) |
| `model_name` | string | ❌ | Nome modello (default: config MODEL_NAME) |

```json
{ "top_n": 8, "model_name": "negozio" }
```

### Output

```json
{
  "success": true,
  "model_name": "negozio",
  "popular_objects": [
    { "object": "Bancone Principale",    "occurrences": 412 },
    { "object": "Illuminazione LED",     "occurrences": 389 },
    { "object": "Scaffalature Centrali", "occurrences": 301 }
  ]
}
```

### Risposta all'utente

```
📈 Elementi più frequenti (non conosco ancora le tue preferenze):
1. Bancone Principale (presente in 412 progetti)
2. Illuminazione LED (presente in 389 progetti)
3. Scaffalature Centrali (presente in 301 progetti)
```

---

## Invocazione da un'altra skill (inter-skill bus)

```python
import os, json, urllib.request

def _call_als(script: str, inp: dict, timeout_s: int = 10) -> dict:
    """Chiamata generica a als-recommender via inter-skill bus."""
    als_skill_id = _config.get('ALS_SKILL_ID', '').strip()
    if not als_skill_id:
        return {}
    url  = f"{os.environ['BACKEND_INTERNAL_URL']}/internal/skills/{als_skill_id}/invoke"
    body = json.dumps({'script': script, 'input': inp}).encode()
    req  = urllib.request.Request(url, data=body, method='POST', headers={
        'Content-Type':       'application/json',
        'x-internal-token': os.environ['INTERNAL_TOKEN'],
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as r:
            return json.loads(r.read()).get('output', {})
    except Exception:
        return {}


def recommend_by_seed(seed_objects, top_n=6, model_name=None):
    """Raccomanda da lista di oggetti noti (modalità seed)."""
    inp = {'seed_objects': seed_objects, 'top_n': top_n}
    if model_name:
        inp['model_name'] = model_name
    return _call_als('recommend.py', inp).get('objects', [])


def recommend_by_subject(subject_id, top_n=6, model_name=None):
    """Raccomanda per un soggetto esistente nel training (modalità subject)."""
    inp = {'subject_id': str(subject_id), 'top_n': top_n}
    if model_name:
        inp['model_name'] = model_name
    return _call_als('recommend.py', inp).get('objects', [])


def similar_objects(reference_object, top_n=10, model_name=None, min_similarity=-1.0):
    """Trova oggetti simili per similarità coseno nello spazio latente."""
    inp = {'reference_object': reference_object, 'top_n': top_n,
           'min_similarity': min_similarity}
    if model_name:
        inp['model_name'] = model_name
    return _call_als('similar.py', inp).get('similar_objects', [])


# ── Esempi d'uso ───────────────────────────────────────────────────────────

# Modalità seed
suggest = recommend_by_seed(['Bancone Principale', 'Scaffalature Centrali'],
                             top_n=6, model_name='negozio')
# → [{"object": "Cassettiere", "score": 0.87}, ...]

# Modalità subject (soggetto già nel gestionale)
suggest = recommend_by_subject('proj_42', top_n=6, model_name='negozio')
# → [{"object": "Illuminazione LED", "score": 0.91}, ...]

# Similarità oggetto-oggetto
simili = similar_objects('Bancone Principale', top_n=5, model_name='negozio')
# → [{"object": "Zona Consulenza", "similarity": 0.94}, ...]
```

**Come ottenere l'UUID della skill:**
Vai su Impostazioni → Skill → als-recommender → copia l'ID dal drawer.
Incollalo nella config var `ALS_SKILL_ID` della skill chiamante.
