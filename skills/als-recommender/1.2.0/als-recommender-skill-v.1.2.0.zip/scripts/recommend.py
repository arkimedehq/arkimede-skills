#!/usr/bin/env python3
"""
ALS Recommender — Recommendation Script

Carica il modello pkl addestrato da train.py e raccomanda oggetti correlati.
Funziona con tutte e tre le varianti ALS (implicit, explicit, biased).

Supporta due modalità di input, selezionate automaticamente:

  seed  (default) — lista di oggetti già presenti nel contesto.
                    Costruisce un pseudo-soggetto come media dei vettori oggetto
                    dei seed, poi raccomanda gli oggetti più vicini.
                    Funziona anche con oggetti mai visti insieme nel training.

  subject         — ID di un soggetto esistente nel dataset di training.
                    Usa direttamente il vettore soggetto salvato durante il
                    training — nessun seed da specificare.
                    Utile quando il soggetto è già nel gestionale e si vuole
                    raccomandare cosa aggiungere al progetto esistente.

Strategia di scoring (uniforme per tutte le varianti):
  1. Ottieni il vettore pseudo-soggetto (da seed o da soggetto)
  2. score_i = item_factors[i] · pseudo_soggetto  (dot product)
  3. Per biased: score_i += item_bias[i]
  4. Normalizza in [0, 1], restituisce top-N

Invocazione da altra skill via POST /internal/skills/{SKILL_ID}/invoke:
  { "script": "recommend.py", "input": { "seed_objects": [...], "model_name": "negozio" } }
  { "script": "recommend.py", "input": { "subject_id": "proj_42", "model_name": "negozio" } }
"""
import json
import os
import pickle
import sys

import numpy as np


def main():
    data = json.load(sys.stdin)
    _config = data.get('_config', {})

    seed_objects = data.get('seed_objects') or []
    subject_id = data.get('subject_id') or None
    top_n = int(data.get('top_n', 6))
    exclude_extra = data.get('exclude', [])
    min_score = float(data.get('min_score', 0.0))

    # ── Risolvi MODEL_NAME ──────────────────────────────────────────────────────
    # Priorità: input["model_name"] > config MODEL_NAME > "default"
    model_name = (
                         data.get('model_name')
                         or _config.get('MODEL_NAME', 'default')
                         or 'default'
                 ).strip() or 'default'

    # ── Validazione: almeno una sorgente richiesta ──────────────────────────────
    if not seed_objects and subject_id is None:
        print(json.dumps({
            'success': False,
            'error': (
                "Fornisci almeno uno tra: "
                "'seed_objects' (lista oggetti noti) oppure "
                "'subject_id' (ID soggetto esistente nel training)."
            ),
        }))
        sys.exit(0)

    # ── Carica modello ──────────────────────────────────────────────────────────
    skills_output_dir = os.environ.get('SKILLS_OUTPUT_DIR', './skills-output')
    skill_id = os.environ.get('SKILL_ID', 'local')
    model_path = os.path.join(
        skills_output_dir, 'als-recommender', skill_id, model_name, 'model.pkl'
    )

    if not os.path.exists(model_path):
        print(json.dumps({
            'success': False,
            'objects': [],
            'model_name': model_name,
            'error': (
                f"Modello '{model_name}' non ancora addestrato. "
                f"Chiama prima train.py con {{ \"model_name\": \"{model_name}\" }} "
                f"e il tuo dataset CSV."
            ),
        }))
        sys.exit(0)  # exit 0 — non bloccante per l'agente

    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    item_names = model['item_names']  # list[str]
    item_index = model['item_index']  # dict[str, int]
    item_factors = model['item_factors']  # np.ndarray (n_items, factors)
    als_type = model.get('als_type', 'implicit')

    # ── Costruisci pseudo-utente ────────────────────────────────────────────────

    mode = 'seed'
    exclude_set = set(exclude_extra)
    missing_seeds = []
    resolved_subject = None

    if subject_id is not None and not seed_objects:
        # ── Modalità SUBJECT ───────────────────────────────────────────────────
        # Recupera direttamente il vettore soggetto salvato da train.py.
        # Richiede subject_index e subject_factors nel pkl (train.py >= 2.0.0).
        # Fallback su session_index/user_factors per modelli addestrati con train.py < 2.0.0.
        mode = 'subject'
        subject_index = model.get('subject_index') or model.get('session_index', {})
        subject_factors = model.get('subject_factors') or model.get('user_factors')

        if subject_factors is None or not subject_index:
            print(json.dumps({
                'success': False, 'objects': [], 'model_name': model_name,
                'error': (
                    "Il modello non contiene i vettori soggetto. "
                    "Riaddestralo con train.py per generare subject_index e subject_factors."
                ),
            }))
            sys.exit(0)

        key = str(subject_id)
        if key not in subject_index:
            sample = list(subject_index.keys())[:8]
            print(json.dumps({
                'success': False, 'objects': [], 'model_name': model_name,
                'error': (
                    f"subject_id '{subject_id}' non trovato nel modello. "
                    f"Esempi di soggetti validi: {sample}"
                ),
            }))
            sys.exit(0)

        u_idx = subject_index[key]
        pseudo_user = subject_factors[u_idx].astype(np.float32)
        resolved_subject = key

    else:
        # ── Modalità SEED ───────────────────────────────────────────────────────
        # Pseudo-soggetto = media dei vettori oggetto dei seed.
        # I seed stessi vengono automaticamente esclusi dai risultati.
        exclude_set |= set(seed_objects)
        seed_factors = []

        for item in seed_objects:
            idx = item_index.get(item)
            if idx is not None:
                seed_factors.append(item_factors[idx])
            else:
                missing_seeds.append(item)

        if not seed_factors:
            print(json.dumps({
                'success': True,
                'objects': [],
                'als_type': als_type,
                'warning': (
                    f'Nessuno dei {len(seed_objects)} seed trovato nel modello. '
                    f'Assicurati che i valori corrispondano a quelli usati nel training. '
                    f'Primi seed mancanti: {missing_seeds[:5]}'
                ),
            }))
            sys.exit(0)

        # ── Cold-Start ALS One-Step (se richiesto o se possibile) ─────────────────
        # Se abbiamo ALPHA e REG nel modello, possiamo calcolare un profilo migliore
        # della semplice media (simile a segment_project nello script MCP).
        if 'ALPHA' in model and 'REG' in model and als_type == 'implicit':
            ALPHA = float(model['ALPHA'])
            REG = float(model['REG'])
            FACTORS = int(item_factors.shape[1])

            # Per semplicità usiamo peso 1.0 per tutti i seed (feedback binario)
            idxs = [item_index[c] for c in seed_objects if c in item_index]
            Y_seen = item_factors[idxs]
            conf = 1.0 + ALPHA * np.ones(len(idxs), dtype=np.float32)

            # A = (Y.T * C) @ Y + lambda * I
            # b = (Y.T * C) @ p  => (Y.T * conf).sum(axis=1)
            A = (Y_seen * conf[:, None]).T @ Y_seen + REG * np.eye(FACTORS, dtype=np.float32)
            b = (Y_seen * conf[:, None]).sum(axis=0)
            pseudo_user = np.linalg.solve(A, b).astype(np.float32)
            mode = 'seed_cold_start'
        else:
            pseudo_user = np.mean(seed_factors, axis=0).astype(np.float32)

    # ── Clustering (se disponibile) ──────────────────────────────────────────
    cluster_info = {}
    if 'km_centers' in model:
        try:
            centers = model['km_centers']
            norm_val = float(np.linalg.norm(pseudo_user))
            u_unit = pseudo_user / (norm_val + 1e-10)
            sims = centers @ u_unit
            best_cluster = int(np.argmax(sims))

            cluster_info = {
                'cluster_id': best_cluster,
                'cluster_name': f"Segmento {best_cluster}",  # ← Nome generico
                'cluster_similarity': round(float(sims[best_cluster]), 4)
            }
        except Exception:
            pass

    # ── Calcola scores ─────────────────────────────────────────────────────────
    # Score base: dot product con tutti i vettori oggetto
    scores = item_factors @ pseudo_user  # (n_objects,)

    # Biased ALS: aggiunge object bias per correggere la popolarità
    if als_type == 'biased' and 'item_bias' in model:
        scores = scores + model['item_bias']

    # ── Normalizza in [0, 1] ───────────────────────────────────────────────────
    s_min, s_max = scores.min(), scores.max()
    if s_max > s_min:
        scores = (scores - s_min) / (s_max - s_min)
    else:
        scores = np.zeros_like(scores)

    # ── Top-N escludendo seed/exclude ──────────────────────────────────────────
    sorted_idx = np.argsort(-scores)
    results = []

    for idx in sorted_idx:
        name = item_names[idx]
        score = float(scores[idx])

        if name in exclude_set:
            continue
        if score < min_score:
            break  # scores sono già in ordine decrescente

        results.append({'object': name, 'score': round(score, 4)})

        if len(results) >= top_n:
            break

    output = {
        'success': True,
        'objects': results,
        'model_name': model_name,
        'als_type': als_type,
        'mode': mode,
        'model_objects': len(item_names),
        **cluster_info,
    }
    if mode == 'subject':
        output['subject_id'] = resolved_subject
    else:
        output['seeds_found'] = len(seed_objects) - len(missing_seeds)
        output['seeds_missing'] = missing_seeds

    print(json.dumps(output))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback

        print(json.dumps({
            'success': False,
            'objects': [],
            'error': str(e),
            'traceback': traceback.format_exc(),
        }))
        sys.exit(1)
