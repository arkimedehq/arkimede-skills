#!/usr/bin/env python3
"""
ALS Recommender — Info Script (mode: info)

Elenca i modelli ALS addestrati per questa istanza della skill.
Viene eseguito automaticamente dall'UI all'apertura del drawer.
Non richiede input. Non viene esposto all'LLM.

Output JSON:
  {
    "models": [
      {
        "name":       "negozio",
        "als_type":   "implicit",
        "n_items":    37,
        "n_sessions": 842,
        "factors":    32,
        "size_kb":    12.4,
        "trained_at": "2025-05-27 14:30:00"
      }
    ],
    "total": 1
  }
"""
import sys
import json
import os
import pickle
import glob
import time


def main():
    skills_output_dir = os.environ.get('SKILLS_OUTPUT_DIR', './skills-output')
    skill_id          = os.environ.get('SKILL_ID', 'local')

    models_base = os.path.join(skills_output_dir, 'als-recommender', skill_id)

    models = []

    if os.path.isdir(models_base):
        # Trova tutti i model.pkl nelle sotto-directory (una per model_name)
        pattern = os.path.join(models_base, '*/model.pkl')
        for model_pkl in sorted(glob.glob(pattern)):
            model_name = os.path.basename(os.path.dirname(model_pkl))
            try:
                with open(model_pkl, 'rb') as f:
                    data = pickle.load(f)

                trained_at_ts = os.path.getmtime(model_pkl)
                trained_at    = time.strftime('%Y-%m-%d %H:%M', time.localtime(trained_at_ts))
                size_kb       = round(os.path.getsize(model_pkl) / 1024, 1)

                models.append({
                    'name':       model_name,
                    'als_type':   data.get('als_type',   'unknown'),
                    'n_items':    data.get('n_items',    0),
                    'n_sessions': data.get('n_sessions', 0),
                    'factors':    data.get('factors',    0),
                    'size_kb':    size_kb,
                    'trained_at': trained_at,
                })
            except Exception as e:
                # Mostra il modello come "corrotto" invece di bloccarlo tutto
                models.append({
                    'name':  model_name,
                    'error': f'Impossibile leggere il modello: {e}',
                })

    print(json.dumps({
        'models': models,
        'total':  len(models),
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success':   False,
            'error':     str(e),
            'traceback': traceback.format_exc(),
        }))
        sys.exit(1)
