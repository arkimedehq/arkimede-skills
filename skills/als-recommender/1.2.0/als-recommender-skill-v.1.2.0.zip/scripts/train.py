#!/usr/bin/env python3
"""
ALS Recommender — Training Script

Addestra un modello di Collaborative Filtering ALS dal CSV fornito.
Supporta tre varianti:

  implicit (iALS) — Hu, Koren & Volinsky (2008)
    Matrice di preferenza binaria p_ui = 1 se count > 0
    Matrice di confidenza c_ui = 1 + alpha * count_ui
    Minimizza: sum_ui c_ui(p_ui - U_u·V_i)^2 + lambda*(||U||^2+||V||^2)
    Usa la libreria `implicit` (ottimizzata in Cython).

  explicit — ALS classico per rating espliciti
    Minimizza: sum_{(u,i) osservati} (r_ui - U_u·V_i)^2 + lambda*(||U||^2+||V||^2)
    Implementazione numpy con soluzione closed-form per ogni riga.

  biased — ALS con bias globale, utente e item
    Modello: r_ui ≈ mu + b_u + b_i + U_u·V_i
    Minimizza: sum_{obs} (r_ui - mu - b_u - b_i - U_u·V_i)^2
             + lambda*(||U||^2 + ||V||^2 + b_u^2 + b_i^2)
    Corregge item popolari (alto b_i) e utenti severi/generosi (b_u).
"""
import sys
import json
import os
import csv
import io
import time
import pickle

import numpy as np


# ─── Entry point ──────────────────────────────────────────────────────────────

def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    # ── Parametri di configurazione ────────────────────────────────────────────
    als_type       = _config.get('ALS_TYPE', 'implicit').lower().strip()
    factors        = int(_config.get('ALS_FACTORS', '32'))
    iterations     = int(_config.get('ALS_ITERATIONS', '20'))
    regularization = float(_config.get('ALS_REGULARIZATION', '0.05'))
    alpha          = float(_config.get('ALS_ALPHA', '40'))
    col_subject    = _config.get('COLUMN_SUBJECT', 'subject_id')
    col_object     = _config.get('COLUMN_OBJECT',  'object_id')
    col_value      = _config.get('COLUMN_VALUE',   'value')

    if als_type not in ('implicit', 'explicit', 'biased'):
        _fail(f"ALS_TYPE '{als_type}' non valido. Valori ammessi: implicit, explicit, biased")

    # ── Sorgente dati — tre formati supportati ────────────────────────────────
    #
    #  1. rows       — array JSON di oggetti (output diretto del SQL tool)
    #                  [{"subject_id": "p1", "object_id": "Bancone", "value": 1}, ...]
    #                  Priorità massima: bypassa il context dell'LLM, ideale per
    #                  dataset grandi (migliaia di righe dal gestionale).
    #
    #  2. csv_content — stringa CSV inline (dataset piccoli, paste in chat)
    #                  "subject_id,object_id\nproj_1,Bancone\n..."
    #
    #  3. csv_path   — path assoluto di un file CSV già uploadato su disco
    #                  "/app/uploads/dataset.csv"
    #
    rows_json   = data.get('rows')        # list[dict] | None
    csv_content = data.get('csv_content', '')
    csv_path    = data.get('csv_path', '')

    if rows_json is not None:
        # ── Formato 1: array JSON diretto (SQL tool output) ──────────────────
        if not isinstance(rows_json, list) or len(rows_json) == 0:
            _fail("Il campo 'rows' deve essere un array JSON non vuoto.")
        rows = [r for r in rows_json if r.get(col_subject) and r.get(col_object)]

    elif csv_content:
        # ── Formato 2: CSV inline ─────────────────────────────────────────────
        reader = csv.DictReader(io.StringIO(csv_content))
        rows = [r for r in reader if r.get(col_subject) and r.get(col_object)]

    elif csv_path and os.path.exists(csv_path):
        # ── Formato 3: file CSV su disco ──────────────────────────────────────
        with open(csv_path, 'r', encoding='utf-8') as f:
            csv_content = f.read()
        reader = csv.DictReader(io.StringIO(csv_content))
        rows = [r for r in reader if r.get(col_subject) and r.get(col_object)]

    else:
        _fail(
            "Nessuna sorgente dati fornita. Usa uno di:\n"
            "  - rows: [{subject_id, object_id, value?}, ...]  ← output SQL tool\n"
            "  - csv_content: 'subject_id,object_id\\nproj1,Bancone\\n...'\n"
            "  - csv_path: '/app/uploads/dataset.csv'"
        )

    if not rows:
        _fail(
            f"Nessuna riga valida trovata. "
            f"Controlla che le colonne '{col_subject}' e '{col_object}' siano presenti "
            f"e non vuote nei tuoi dati."
        )

    # Verifica colonne obbligatorie (solo per CSV — per rows_json le chiavi sono flessibili)
    if rows_json is None:
        headers = list(rows[0].keys())
        for col in [col_subject, col_object]:
            if col not in headers:
                _fail(f"Colonna '{col}' non trovata. Colonne disponibili: {headers}")

    has_value = col_value in (rows[0].keys() if rows else [])
    if als_type in ('explicit', 'biased') and not has_value:
        _fail(
            f"ALS_TYPE='{als_type}' richiede la colonna '{col_value}' con i rating. "
            f"Chiavi disponibili: {list(rows[0].keys()) if rows else '(nessuna)'}"
        )

    # ── Costruisci indici oggetti e soggetti ───────────────────────────────────
    # Normalizza sempre a str: il SQL tool può restituire int (es. 101),
    # il CSV restituisce già str. Stringhe garantiscono:
    #   - sorted() senza TypeError su tipi misti
    #   - chiavi consistenti con recommend.py (che fa str(subject_id))
    subjects  = sorted(set(str(r[col_subject]) for r in rows))
    objects   = sorted(set(str(r[col_object])  for r in rows))
    subj_idx  = {s: i for i, s in enumerate(subjects)}
    obj_idx   = {o: i for i, o in enumerate(objects)}
    n_subj, n_obj = len(subjects), len(objects)

    # ── Training ───────────────────────────────────────────────────────────────
    t0 = time.perf_counter()

    if als_type == 'implicit':
        model_data = _train_implicit(
            rows, subj_idx, obj_idx, n_subj, n_obj,
            col_subject, col_object, col_value, has_value,
            factors, iterations, regularization, alpha,
        )
    elif als_type == 'explicit':
        model_data = _train_explicit(
            rows, subj_idx, obj_idx, n_subj, n_obj,
            col_subject, col_object, col_value,
            factors, iterations, regularization,
        )
    else:  # biased
        model_data = _train_biased(
            rows, subj_idx, obj_idx, n_subj, n_obj,
            col_subject, col_object, col_value,
            factors, iterations, regularization,
        )

    elapsed = time.perf_counter() - t0

    # ── Risolvi MODEL_NAME ─────────────────────────────────────────────────────
    # Priorità: input["model_name"] > config MODEL_NAME > "default"
    # Questo permette di addestrare modelli diversi nella stessa istanza skill:
    #   train.py { "model_name": "negozio" }   → .../negozio/model.pkl
    #   train.py { "model_name": "ristorante"} → .../ristorante/model.pkl
    model_name = (
        data.get('model_name')                   # override per-chiamata
        or _config.get('MODEL_NAME', 'default')  # config UI
        or 'default'
    ).strip() or 'default'

    # Sicurezza: solo caratteri alfanumerici, trattini e underscore
    import re
    if not re.match(r'^[a-zA-Z0-9_-]{1,64}$', model_name):
        _fail(
            f"model_name '{model_name}' non valido. "
            f"Usa solo lettere, cifre, trattini e underscore (max 64 caratteri)."
        )

    # ── Salva pkl ──────────────────────────────────────────────────────────────
    skills_output_dir = os.environ.get('SKILLS_OUTPUT_DIR', './skills-output')
    skill_id          = os.environ.get('SKILL_ID', 'local')
    model_dir  = os.path.join(skills_output_dir, 'als-recommender', skill_id, model_name)
    os.makedirs(model_dir, exist_ok=True)
    model_path = os.path.join(model_dir, 'model.pkl')

    # ── KMeans Clustering (6 Cluster archetipi) ───────────────────────────────
    # Aggiunge segmentazione automatica se abbiamo abbastanza soggetti
    km_data = {}
    if 'subject_factors' in model_data and len(model_data['subject_factors']) >= 12:
        try:
            from scipy.cluster.vq import kmeans2, whiten
            U = model_data['subject_factors'].astype(np.float32)
            # Normalizza i vettori per clustering basato su similarità coseno
            norms = np.linalg.norm(U, axis=1, keepdims=True)
            norms[norms == 0] = 1e-10
            U_norm = U / norms

            centroids, labels = kmeans2(U_norm, 6, iter=20, minit='points', seed=42)
            km_data = {
                'km_centers': centroids.astype(np.float32),
                'km_labels':  labels.astype(np.int32),
                'km_k':       6
            }
        except Exception as e:
            # Non bloccante
            print(f"Warning: KMeans clustering fallito: {e}", file=sys.stderr)

    obj_counts = np.zeros(n_obj, dtype=np.int32)
    for r in rows:
        o = obj_idx[str(r[col_object])]
        obj_counts[o] += 1

    payload = {
        'als_type':       als_type,
        'item_names':     objects,    # ← lista oggetti (compatibile con recommend/similar/popular)
        'item_index':     obj_idx,    # ← mappa object_id → indice in item_factors
        'item_counts':    obj_counts,
        'subject_names':  subjects,   # ← lista soggetti
        'subject_index':  subj_idx,   # ← mappa subject_id → indice in subject_factors
        'n_subjects':     n_subj,
        'n_objects':      n_obj,
        'factors':        factors,
        'ALPHA':          alpha if als_type == 'implicit' else 40,  # salvato per cold-start
        'REG':            regularization,                           # salvato per cold-start
        **model_data,
        **km_data,
    }
    with open(model_path, 'wb') as f:
        pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)

    print(json.dumps({
        'success':      True,
        'model_name':   model_name,
        'als_type':     als_type,
        'subjects':     n_subj,
        'objects':      n_obj,
        'interactions': len(rows),
        'factors':      factors,
        'iterations':   iterations,
        'elapsed_s':    round(elapsed, 2),
        'model_path':   model_path,
        'message': (
            f"Modello '{model_name}' ({als_type.upper()}) addestrato: "
            f"{n_subj} soggetti, {n_obj} oggetti, {len(rows)} interazioni in {elapsed:.1f}s"
        ),
    }))


# ─── Variante 1: iALS (Implicit ALS) ─────────────────────────────────────────

def _train_implicit(rows, subj_idx, obj_idx, n_subj, n_obj,
                    col_subject, col_object, col_value, has_value,
                    factors, iterations, regularization, alpha):
    """
    iALS — Hu, Koren & Volinsky (2008).

    Matrice di preferenza binaria: p_ui = 1 se count_ui > 0, 0 altrimenti.
    Matrice di confidenza:         c_ui = 1 + alpha * count_ui

    Questo permette di distinguere "presente con 1 acquisto" (bassa confidenza)
    da "presente con 10 acquisti" (alta confidenza) pur mantenendo preferenza binaria.

    alpha=0 → tutti i pesi uguali (pura presenza/assenza).
    alpha alto → item frequenti pesano molto di più.
    """
    import implicit
    import scipy.sparse as sp

    row_v, col_v, val_v = [], [], []
    for r in rows:
        s = subj_idx[str(r[col_subject])]
        o = obj_idx[str(r[col_object])]
        v = _parse_float(r.get(col_value), default=1.0) if has_value else 1.0
        row_v.append(s); col_v.append(o); val_v.append(max(v, 0.0))

    matrix = sp.csr_matrix(
        (val_v, (row_v, col_v)),
        shape=(n_subj, n_obj),
        dtype=np.float32,
    )

    model = implicit.als.AlternatingLeastSquares(
        factors=factors,
        iterations=iterations,
        regularization=regularization,
        alpha=alpha,
        use_gpu=False,
        random_state=42,
    )
    model.fit(matrix)

    return {
        'item_factors':    model.item_factors,   # (n_objects, factors) — vettori oggetto
        'subject_factors': model.user_factors,   # (n_subjects, factors) — vettori soggetto
    }


# ─── Variante 2: Explicit ALS ─────────────────────────────────────────────────

def _train_explicit(rows, subj_idx, obj_idx, n_subj, n_obj,
                    col_subject, col_object, col_value,
                    factors, iterations, regularization):
    """
    ALS classico per feedback esplicito.

    Minimizza: sum_{(u,i) osservati} (r_ui - U_u·V_i)^2 + lambda*(||U||^2+||V||^2)

    Aggiornamento closed-form per ogni riga di U:
      (V_obs^T V_obs + lambda*I) u_i = V_obs^T r_obs

    Idem per V. Complessità per iterazione: O(n_subjects*k^2 + n_objects*k^2)
    dove k=factors — efficiente per dataset piccoli (<10k item).
    """
    R, W = _build_rating_matrix(rows, subj_idx, obj_idx, n_subj, n_obj,
                                col_subject, col_object, col_value)

    np.random.seed(42)
    U   = (np.random.randn(n_subj, factors) * 0.01).astype(np.float32)
    V   = (np.random.randn(n_obj,  factors) * 0.01).astype(np.float32)
    lam = regularization * np.eye(factors, dtype=np.float32)

    for _ in range(iterations):
        # Aggiorna U: per ogni soggetto i
        for i in range(n_subj):
            obs = np.where(W[i])[0]
            if len(obs) == 0:
                continue
            V_obs = V[obs]
            A = V_obs.T @ V_obs + lam
            b = V_obs.T @ R[i, obs]
            U[i] = np.linalg.solve(A, b)

        # Aggiorna V: per ogni oggetto j
        for j in range(n_obj):
            obs = np.where(W[:, j])[0]
            if len(obs) == 0:
                continue
            U_obs = U[obs]
            A = U_obs.T @ U_obs + lam
            b = U_obs.T @ R[obs, j]
            V[j] = np.linalg.solve(A, b)

    return {'item_factors': V, 'subject_factors': U}


# ─── Variante 3: ALS con Bias ─────────────────────────────────────────────────

def _train_biased(rows, subj_idx, obj_idx, n_subj, n_obj,
                  col_subject, col_object, col_value,
                  factors, iterations, regularization):
    """
    ALS con bias — estende il modello esplicito con tre termini addizionali:

      r_ui ≈ mu + b_u + b_i + U_u·V_i

      mu   — bias globale (media dei rating osservati)
      b_u  — bias sessione/utente (es. un progetto "ricco" tende a includere più aree)
      b_i  — bias item (es. "Bancone" appare quasi sempre → alto b_i)

    Minimizza:
      sum_{obs} (r_ui - mu - b_u - b_i - U_u·V_i)^2
      + lambda*(||U||^2 + ||V||^2 + sum b_u^2 + sum b_i^2)

    I bias vengono aggiornati prima dei fattori latenti (closed-form scalare).
    Le raccomandazioni includono b_i nella score finale: item popolari ma non
    ancora presenti vengono opportunamente valorizzati (o penalizzati se
    la popolarità non è rilevante — regolare alpha/lambda di conseguenza).
    """
    R, W = _build_rating_matrix(rows, subj_idx, obj_idx, n_subj, n_obj,
                                col_subject, col_object, col_value)

    # Bias globale = media dei rating osservati
    observed = R[W]
    mu = float(observed.mean()) if len(observed) > 0 else 0.0

    b_u = np.zeros(n_subj, dtype=np.float32)   # bias soggetto
    b_i = np.zeros(n_obj,  dtype=np.float32)   # bias oggetto

    np.random.seed(42)
    U   = (np.random.randn(n_subj, factors) * 0.01).astype(np.float32)
    V   = (np.random.randn(n_obj,  factors) * 0.01).astype(np.float32)
    lam = regularization * np.eye(factors, dtype=np.float32)

    for _ in range(iterations):

        # ── Aggiorna bias soggetto b_u ──────────────────────────────────────
        for i in range(n_subj):
            obs = np.where(W[i])[0]
            if len(obs) == 0:
                continue
            res = R[i, obs] - mu - b_i[obs] - (U[i] @ V[obs].T)
            b_u[i] = res.sum() / (len(obs) + regularization)

        # ── Aggiorna bias oggetto b_i ───────────────────────────────────────
        for j in range(n_obj):
            obs = np.where(W[:, j])[0]
            if len(obs) == 0:
                continue
            res = R[obs, j] - mu - b_u[obs] - (U[obs] @ V[j])
            b_i[j] = res.sum() / (len(obs) + regularization)

        # ── Aggiorna fattori latenti U (per soggetto) ───────────────────────
        for i in range(n_subj):
            obs = np.where(W[i])[0]
            if len(obs) == 0:
                continue
            V_obs = V[obs]
            r_adj = R[i, obs] - mu - b_u[i] - b_i[obs]
            A = V_obs.T @ V_obs + lam
            b = V_obs.T @ r_adj
            U[i] = np.linalg.solve(A, b)

        # ── Aggiorna fattori latenti V (per oggetto) ────────────────────────
        for j in range(n_obj):
            obs = np.where(W[:, j])[0]
            if len(obs) == 0:
                continue
            U_obs = U[obs]
            r_adj = R[obs, j] - mu - b_u[obs] - b_i[j]
            A = U_obs.T @ U_obs + lam
            b = U_obs.T @ r_adj
            V[j] = np.linalg.solve(A, b)

    return {
        'item_factors':    V,
        'mu':              mu,
        'item_bias':       b_i,
        'subject_factors': U,
        'subject_bias':    b_u,
    }


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _build_rating_matrix(rows, subj_idx, obj_idx, n_subj, n_obj,
                         col_subject, col_object, col_value):
    """Costruisce la matrice densa (n_subj, n_obj) con NaN per celle non osservate."""
    R = np.full((n_subj, n_obj), np.nan, dtype=np.float32)
    for r in rows:
        s = subj_idx[str(r[col_subject])]
        o = obj_idx[str(r[col_object])]
        v = _parse_float(r.get(col_value))
        if v is not None:
            R[s, o] = v
    W = ~np.isnan(R)
    R_filled = np.nan_to_num(R, nan=0.0)
    return R_filled, W


def _parse_float(val, default=None):
    """Converte stringa in float; restituisce default in caso di errore."""
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


def _fail(msg):
    print(json.dumps({'success': False, 'error': msg}))
    sys.exit(1)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success':   False,
            'error':     str(e),
            'traceback': traceback.format_exc(),
        }))
        sys.exit(1)
