#!/usr/bin/env python3
"""
ALS Recommender — Popularity Baseline Script

Restituisce gli oggetti più popolari (frequenti) nel dataset di training.
Questo script non usa l'intelligenza del modello spaziale, ma è fondamentale
come strategia di fallback (Cold Start) quando un utente non ha alcuno storico
e non possiamo costruire un vettore ALS.

Invocazione via POST:
  { "script": "popular.py", "input":  { "top_n": 10 } }
"""
import json
import os
import pickle
import sys

import numpy as np


def main():
    data = json.load(sys.stdin)
    _config = data.get('_config', {})

    top_n = int(data.get('top_n', 10))
    model_name = (
                         data.get('model_name')
                         or _config.get('MODEL_NAME', 'default')
                         or 'default'
                 ).strip() or 'default'

    skills_output_dir = os.environ.get('SKILLS_OUTPUT_DIR', './skills-output')
    skill_id = os.environ.get('SKILL_ID', 'local')
    model_path = os.path.join(skills_output_dir, 'als-recommender', skill_id, model_name, 'model.pkl')

    if not os.path.exists(model_path):
        print(json.dumps({'success': False, 'error': "Modello non trovato."}))
        sys.exit(0)

    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    if 'item_counts' not in model:
        print(json.dumps({
            'success': False,
            'error': "I dati di popolarità non sono presenti. Riavvia train.py con la versione aggiornata."
        }))
        sys.exit(0)

    item_names = model['item_names']
    item_counts = model['item_counts']

    # Ordina per conteggio decrescente
    sorted_idx = np.argsort(-item_counts)

    results = []
    for idx in sorted_idx[:top_n]:
        results.append({
            'object': item_names[idx],
            'occurrences': int(item_counts[idx])
        })

    print(json.dumps({
        'success': True,
        'model_name': model_name,
        'popular_objects': results
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback

        print(json.dumps({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc(),
        }))
        sys.exit(1)
