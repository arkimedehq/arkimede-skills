#!/usr/bin/env python3
"""
ALS Recommender — Object Similarity Script

Dato un oggetto di riferimento, restituisce i top-N oggetti più simili
nello spazio latente ALS usando la similarità coseno tra vettori oggetto:

  sim(i, j) = (V_i · V_j) / (‖V_i‖ · ‖V_j‖)

A differenza di recommend.py (che costruisce un pseudo-soggetto e raccomanda
oggetti "co-occorrenti"), similar.py misura la vicinanza geometrica nello spazio
latente — due oggetti sono simili se compaiono in contesti analoghi nel training.

Casi d'uso:
  - Trovare alternative o varianti di un oggetto
  - Capire la struttura dello spazio latente
  - Suggerire complementi a partire da un singolo oggetto noto
  - Diagnosi del modello (clustering implicito tra oggetti)

Invocazione da altra skill via POST /internal/skills/{SKILL_ID}/invoke:
  {
    "script": "similar.py",
    "input":  { "reference_object": "Bancone Principale", "top_n": 5 }
  }
"""
import sys
import json
import os
import pickle

import numpy as np


def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    # reference_object è il nome canonico; reference_item accettato per retrocompatibilità
    reference_object = (data.get('reference_object') or data.get('reference_item') or '').strip()
    top_n          = int(data.get('top_n', 10))
    exclude_extra  = data.get('exclude', [])
    min_similarity = float(data.get('min_similarity', -1.0))

    # ── Risolvi MODEL_NAME ──────────────────────────────────────────────────────
    model_name = (
        data.get('model_name')
        or _config.get('MODEL_NAME', 'default')
        or 'default'
    ).strip() or 'default'

    if not reference_object:
        print(json.dumps({
            'success': False,
            'error':   "'reference_object' è obbligatorio.",
        }))
        sys.exit(1)

    # ── Carica modello ──────────────────────────────────────────────────────────
    skills_output_dir = os.environ.get('SKILLS_OUTPUT_DIR', './skills-output')
    skill_id          = os.environ.get('SKILL_ID', 'local')
    model_path = os.path.join(
        skills_output_dir, 'als-recommender', skill_id, model_name, 'model.pkl'
    )

    if not os.path.exists(model_path):
        print(json.dumps({
            'success': False,
            'error': (
                f"Modello '{model_name}' non ancora addestrato. "
                f"Chiama prima train.py."
            ),
        }))
        sys.exit(0)

    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    item_names   = model['item_names']    # list[str]
    item_index   = model['item_index']    # dict[str, int]
    item_factors = model['item_factors']  # np.ndarray (n_items, factors)
    als_type     = model.get('als_type', 'implicit')

    # ── Trova oggetto di riferimento ────────────────────────────────────────────
    if reference_object not in item_index:
        print(json.dumps({
            'success':        False,
            'reference_object': reference_object,
            'error': (
                f"Oggetto '{reference_object}' non trovato nel modello. "
                f"Primi oggetti disponibili: {item_names[:10]}"
            ),
        }))
        sys.exit(0)

    ref_idx  = item_index[reference_object]
    ref_vec  = item_factors[ref_idx].astype(np.float32)   # (factors,)

    # ── Similarità coseno ───────────────────────────────────────────────────────
    # sim(i, ref) = (V_i · V_ref) / (‖V_i‖ · ‖V_ref‖)
    # In [−1, 1]: 1 = identici nello spazio latente, 0 = ortogonali, −1 = opposti
    norms    = np.linalg.norm(item_factors, axis=1)         # (n_items,)
    norms    = np.where(norms == 0, 1e-10, norms)
    ref_norm = float(np.linalg.norm(ref_vec)) or 1e-10

    similarities          = (item_factors @ ref_vec) / (norms * ref_norm)
    similarities[ref_idx] = -np.inf   # escludi sempre l'oggetto di riferimento

    # ── Applica esclusioni e soglia minima ─────────────────────────────────────
    exclude_set = {reference_object} | set(exclude_extra)
    sorted_idx  = np.argsort(-similarities)
    results     = []

    for idx in sorted_idx:
        name = item_names[idx]
        sim  = float(similarities[idx])

        if name in exclude_set:
            continue
        if sim < min_similarity:
            break   # già in ordine decrescente

        results.append({'object': name, 'similarity': round(sim, 4)})

        if len(results) >= top_n:
            break

    print(json.dumps({
        'success':        True,
        'reference_object': reference_object,
        'similar_objects':  results,
        'model_name':     model_name,
        'als_type':       als_type,
        'model_objects':    len(item_names),
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success':       False,
            'similar_objects': [],
            'error':         str(e),
            'traceback':     traceback.format_exc(),
        }))
        sys.exit(1)
