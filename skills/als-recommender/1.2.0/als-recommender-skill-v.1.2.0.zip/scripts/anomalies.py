#!/usr/bin/env python3
"""
ALS Recommender — Anomaly Detection Script

Dato un elenco di oggetti (es. un progetto esistente o un carrello),
calcola la coerenza del gruppo. Segnala come "anomalie" gli oggetti
effettivamente presenti ma che il modello prevede con uno score
molto basso rispetto al resto del contesto.

Invocazione da altra skill via POST /internal/skills/{SKILL_ID}/invoke:
  {
    "script": "anomalies.py",
    "input":  { "seed_objects": ["A", "B", "C"], "threshold": 0.1 }
  }
  (alias legacy: "seed_categories" accettato come sinonimo di "seed_objects")
"""
import json
import os
import pickle
import sys

import numpy as np


def main():
    data = json.load(sys.stdin)
    _config = data.get('_config', {})

    # seed_objects è il nome canonico; seed_categories accettato per retrocompatibilità
    seed_objects = data.get('seed_objects') or data.get('seed_categories') or []
    threshold = float(data.get('threshold', 0.1))

    model_name = (
                         data.get('model_name')
                         or _config.get('MODEL_NAME', 'default')
                         or 'default'
                 ).strip() or 'default'

    if not seed_objects or len(seed_objects) < 2:
        print(json.dumps({
            'success': False,
            'error': "Fornisci almeno 2 'seed_objects' per poter calcolare un'anomalia di contesto."
        }))
        sys.exit(0)

    # ── Carica modello ──────────────────────────────────────────────────────────
    skills_output_dir = os.environ.get('SKILLS_OUTPUT_DIR', './skills-output')
    skill_id = os.environ.get('SKILL_ID', 'local')
    model_path = os.path.join(skills_output_dir, 'als-recommender', skill_id, model_name, 'model.pkl')

    if not os.path.exists(model_path):
        print(json.dumps({'success': False, 'error': "Modello non trovato."}))
        sys.exit(0)

    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    item_names = model['item_names']
    item_index = model['item_index']
    item_factors = model['item_factors']
    als_type = model.get('als_type', 'implicit')

    # ── Trova i vettori degli oggetti forniti ──────────────────────────────────
    seed_factors = []
    valid_seeds = []

    for it in seed_objects:
        idx = item_index.get(it)
        if idx is not None:
            seed_factors.append(item_factors[idx])
            valid_seeds.append(it)

    if not seed_factors:
        print(json.dumps({'success': True, 'anomalies': [], 'message': "Nessun oggetto noto al modello."}))
        sys.exit(0)

    # ── Costruisci il profilo e ricalcola gli score ────────────────────────────
    pseudo_user = np.mean(seed_factors, axis=0).astype(np.float32)
    scores = item_factors @ pseudo_user

    if als_type == 'biased' and 'item_bias' in model:
        scores = scores + model['item_bias']

    # Normalizza gli score tra 0 e 1 per avere una scala leggibile
    s_min, s_max = scores.min(), scores.max()
    if s_max > s_min:
        scores = (scores - s_min) / (s_max - s_min)
    else:
        scores = np.zeros_like(scores)

    # ── Identifica le anomalie ─────────────────────────────────────────────────
    anomalies = []
    coherence_scores = {}

    for item in valid_seeds:
        idx = item_index[item]
        score = float(scores[idx])
        coherence_scores[item] = round(score, 4)

        if score < threshold:
            anomalies.append({
                'object': item,
                'score': round(score, 4),
                'reason': f"Score previsto ({round(score, 4)}) inferiore alla soglia di anomalia ({threshold})."
            })

    print(json.dumps({
        'success': True,
        'model_name': model_name,
        'analyzed_items': len(valid_seeds),
        'anomalies_found': len(anomalies),
        'anomalies': anomalies,
        'context_coherence': coherence_scores
    }))


if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback

        print(json.dumps({'success': False, 'error': str(e), 'traceback': traceback.format_exc()}))
        sys.exit(1)
