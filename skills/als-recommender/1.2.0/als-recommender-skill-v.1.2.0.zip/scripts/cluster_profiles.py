#!/usr/bin/env python3
"""
ALS Recommender — Cluster Profiles Script

Estrae i profili tipici dei cluster generati durante il training.
Moltiplica i centroidi del K-Means per la matrice dei fattori latenti degli item
per scoprire quali item sono più rappresentativi per ciascun segmento.

Invocazione da altra skill via POST /internal/skills/{SKILL_ID}/invoke:
  {
    "script": "cluster_profiles.py",
    "input":  { "top_n": 5, "model_name": "default" }
  }
"""
import sys
import json
import os
import pickle
import numpy as np

def main():
    data    = json.load(sys.stdin)
    _config = data.get('_config', {})

    top_n = int(data.get('top_n', 5))
    model_name = (
        data.get('model_name')
        or _config.get('MODEL_NAME', 'default')
        or 'default'
    ).strip() or 'default'

    # ── Carica modello ──────────────────────────────────────────────────────────
    skills_output_dir = os.environ.get('SKILLS_OUTPUT_DIR', './skills-output')
    skill_id          = os.environ.get('SKILL_ID', 'local')
    model_path = os.path.join(
        skills_output_dir, 'als-recommender', skill_id, model_name, 'model.pkl'
    )

    if not os.path.exists(model_path):
        print(json.dumps({
            'success': False,
            'error': f"Modello '{model_name}' non trovato. Esegui prima il training."
        }))
        sys.exit(0)

    with open(model_path, 'rb') as f:
        model = pickle.load(f)

    if 'km_centers' not in model:
        print(json.dumps({
            'success': False,
            'error': "Il modello non contiene dati di clustering. Assicurati di avere un dataset con abbastanza sessioni per attivare il KMeans durante il training."
        }))
        sys.exit(0)

    item_names   = model['item_names']
    item_factors = model['item_factors']
    centers      = model['km_centers']
    als_type     = model.get('als_type', 'implicit')

    profiles = []

    # Per ogni centroide, calcola il dot product con tutti gli item
    for cluster_id, centroid in enumerate(centers):
        scores = item_factors @ centroid

        # Aggiungi il bias se è un modello biased
        if als_type == 'biased' and 'item_bias' in model:
            scores = scores + model['item_bias']

        # Trova gli indici con i punteggi più alti
        sorted_idx = np.argsort(-scores)[:top_n]

        top_objects = [
            {'object': item_names[idx], 'score': round(float(scores[idx]), 4)}
            for idx in sorted_idx
        ]

        profiles.append({
            'cluster_id': cluster_id,
            'cluster_name': f"Segmento {cluster_id}",
            'typical_objects': top_objects
        })

    print(json.dumps({
        'success': True,
        'model_name': model_name,
        'clusters': profiles
    }))

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        import traceback
        print(json.dumps({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc(),
        }))
        sys.exit(1)