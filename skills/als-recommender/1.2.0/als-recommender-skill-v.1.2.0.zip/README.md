# ALS Recommender Skill

Skill di **Collaborative Filtering** basata su ALS (Alternating Least Squares).
Addestra un modello di raccomandazione su qualsiasi dataset CSV tabulare e offre
sei modalità di inferenza: raccomandazione da seed, raccomandazione da soggetto
esistente, similarità oggetto-oggetto, profili dei cluster, rilevamento anomalie
e oggetti popolari (cold start).

Progettata per essere usata da sola (l'LLM chiama direttamente `train`, `recommend`, ecc.)
o come **servizio richiamabile da altre skill** via inter-skill bus interno.

---

## Indice

- [Quando usarla](#quando-usarla)
- [Terminologia](#terminologia)
- [Le tre varianti ALS](#le-tre-varianti-als)
- [Formato del dataset](#formato-del-dataset)
- [Configurazione](#configurazione)
- [Utilizzo](#utilizzo)
  - [Training](#1-training)
  - [Raccomandazione](#2-raccomandazione)
  - [Similarità oggetto-oggetto](#3-similarità-oggetto-oggetto)
  - [Profili dei cluster](#4-profili-dei-cluster)
  - [Rilevamento anomalie](#5-rilevamento-anomalie)
  - [Oggetti popolari (cold start)](#6-oggetti-popolari-cold-start)
  - [Inter-skill bus](#7-invocazione-da-unaltra-skill-inter-skill-bus)
- [Esempi di dataset](#esempi-di-dataset)
- [Guida alla scelta della variante](#guida-alla-scelta-della-variante)
- [Dipendenze](#dipendenze)
- [Note tecniche](#note-tecniche)

---

## Quando usarla

Usa questa skill quando vuoi raccomandare elementi correlati basandoti su uno
**storico di co-occorrenze o valutazioni**. La terminologia è universale:

| Dominio | Soggetto (COLUMN_SUBJECT) | Oggetto (COLUMN_OBJECT) | Tipo ALS |
|---|---|---|---|
| Allestimento negozi  | Progetto | Categoria prodotto | `implicit` |
| E-commerce | Ordine | Prodotto acquistato | `implicit` |
| Streaming | Utente | Film/serie visto | `implicit` |
| Valutazioni prodotti | Utente | Prodotto con stelle | `explicit` / `biased` |
| Biblioteche | Utente | Libro letto | `implicit` |
| Ristorazione | Ristorante | Tipo arredo | `implicit` |

---

## Terminologia

| Termine | Significato | Config | Default |
|---|---|---|---|
| **Soggetto** | Asse righe della matrice ALS — raggruppa gli oggetti co-occorrenti | `COLUMN_SUBJECT` | `subject_id` |
| **Oggetto** | Asse colonne — l'elemento che viene raccomandato, cercato per similarità o analizzato | `COLUMN_OBJECT` | `object_id` |
| **Valore** | Peso dell'interazione (count per implicit, rating per explicit/biased) | `COLUMN_VALUE` | `value` |

---

## Le tre varianti ALS

### `implicit` — iALS (Hu, Koren & Volinsky, 2008)

**Per feedback implicito**: dati senza rating espliciti (presenze, acquisti, click).

```
preferenza:  p_ui = 1  se count_ui > 0,  0 altrimenti
confidenza:  c_ui = 1 + alpha × count_ui
```

Minimizza:
```
Σ_ui  c_ui · (p_ui − U_u · V_i)²  +  λ · (‖U‖² + ‖V‖²)
```

**Parametro chiave:** `ALS_ALPHA` — amplifica il peso degli oggetti frequenti vs. rari.

---

### `explicit` — ALS classico per rating espliciti

**Per feedback esplicito**: ogni interazione ha un rating numerico (1–5 stelle).

Minimizza l'errore solo sulle celle **osservate**:
```
Σ_{(u,i) osservati}  (r_ui − U_u · V_i)²  +  λ · (‖U‖² + ‖V‖²)
```

**Parametro chiave:** `ALS_REGULARIZATION`.

---

### `biased` — ALS con bias

**Estende `explicit`** con tre termini di distorsione:
```
r_ui  ≈  μ  +  b_u  +  b_i  +  U_u · V_i
```

| Termine | Descrizione |
|---|---|
| `μ` | Bias globale (media di tutti i rating) |
| `b_u` | Bias soggetto (generoso vs. severo) |
| `b_i` | Bias oggetto (popolare vs. di nicchia) |

**Quando usarla:** rating espliciti con forti effetti di popolarità su alcuni oggetti.

---

## Formato del dataset

Almeno due colonne (tre per explicit/biased):

```csv
subject_id,object_id,value
proj_001,Bancone Principale,1
proj_001,Scaffalature Centrali,2
proj_001,Illuminazione LED,1
proj_002,Bancone Principale,1
proj_002,Cassettiere,3
```

| Colonna | Config | Descrizione |
|---|---|---|
| `subject_id` | `COLUMN_SUBJECT` | Raggruppa gli oggetti (progetto, ordine, utente…) |
| `object_id` | `COLUMN_OBJECT` | L'elemento da raccomandare (categoria, prodotto, tag…) |
| `value` | `COLUMN_VALUE` | Count per `implicit`; rating per `explicit`/`biased`. Opzionale per `implicit` (default: 1) |

**I nomi delle colonne sono configurabili** — il dataset non deve essere rinominato.

---

## Configurazione

### Variabili principali

| Chiave | Default | Descrizione |
|---|---|---|
| `ALS_TYPE` | `implicit` | Variante ALS: `implicit` · `explicit` · `biased` |
| `ALS_FACTORS` | `32` | Dimensioni spazio latente. Più alto = più espressivo ma più lento |
| `ALS_ITERATIONS` | `20` | Iterazioni di training. Convergenza tipica: 15–30 |
| `ALS_REGULARIZATION` | `0.05` | Penalità L2. Aumentare se overfitting |
| `ALS_ALPHA` | `40` | Moltiplicatore di confidenza (solo `implicit`) |
| `COLUMN_SUBJECT` | `subject_id` | Nome colonna soggetto nel CSV |
| `COLUMN_OBJECT` | `object_id` | Nome colonna oggetto nel CSV |
| `COLUMN_VALUE` | `value` | Nome colonna valore nel CSV |
| `MODEL_NAME` | `default` | Nome del modello di default (sovrascrivibile per-chiamata) |

### Linee guida per `ALS_FACTORS`

| Dimensione dataset | Oggetti unici | Fattori consigliati |
|---|---|---|
| Piccolo | < 50 | 8 – 32 |
| Medio | 50 – 500 | 32 – 64 |
| Grande | > 500 | 64 – 128 |

### Linee guida per `ALS_ALPHA` (solo `implicit`)

| Scenario | Alpha consigliato |
|---|---|
| Dati binari (presenza/assenza) | 1 – 10 |
| Count con range 1–10 | 20 – 40 |
| Count con range 1–100+ | 40 – 100 |

---

## Utilizzo

### 1. Training

`train.py` accetta i dati in tre formati.

#### A) Via SQL tool — dataset grandi (consigliato)

```sql
SELECT p.id         AS subject_id,   -- ← deve matchare COLUMN_SUBJECT
       c.categoria  AS object_id     -- ← deve matchare COLUMN_OBJECT
FROM progetti p
JOIN righe_progetto r ON r.id_progetto = p.id
JOIN catalogo_prodotti cp ON cp.cod_prodotto = r.cod_prodotto
LEFT JOIN categorie c ON c.id_categoria = cp.id_categoria
WHERE p.completato = 1
GROUP BY p.id, c.categoria
```

L'LLM esegue la query e passa il risultato come `rows`:
```json
{
  "model_name": "negozio",
  "rows": [{"subject_id": "101", "object_id": "Bancone Principale"}, ...]
}
```

#### B) CSV inline — dataset piccoli (< 500 righe)

```
Addestra il modello ALS chiamato 'negozio' con questi dati:
subject_id,object_id
proj_1,Bancone Principale
proj_1,Scaffalature Centrali
```

#### C) File CSV uploadato

```
"Addestra il modello ALS con il file CSV che ho appena caricato."
```

Output:
```json
{
  "success": true,
  "model_name": "negozio",
  "als_type": "implicit",
  "subjects": 842,
  "objects": 37,
  "interactions": 4210,
  "elapsed_s": 2.3
}
```

```
✅ Modello 'negozio' addestrato con successo!
- Tipo: IMPLICIT (iALS)  |  Soggetti: 842  |  Oggetti: 37  |  Tempo: 2.3s
```

> Il modello persiste in `SKILLS_OUTPUT_DIR`. Non riaddestrare ad ogni conversazione
> — solo quando i dati cambiano. Modelli diversi (es. `negozio`, `ecommerce`)
> coesistono nella stessa skill.

---

### 2. Raccomandazione

`recommend.py` supporta due modalità — almeno una è obbligatoria.

#### Modalità seed (default)

Fornisci gli oggetti già presenti nel contesto. Il modello costruisce uno
**pseudo-soggetto** come media dei vettori latenti e raccomanda gli oggetti più vicini.
Funziona con qualsiasi combinazione, anche mai vista nel training.

```
Con il modello 'negozio', dato che ho già "Bancone Principale" e "Scaffalature Centrali",
cosa mi consigli di aggiungere?
```

Output:
```json
{
  "success": true,
  "objects": [
    { "object": "Zona Consulenza",   "score": 0.87 },
    { "object": "Illuminazione LED", "score": 0.74 }
  ],
  "mode": "seed_cold_start",
  "model_name": "negozio",
  "model_objects": 37,
  "seeds_found": 2,
  "seeds_missing": [],
  "cluster_id": 2,
  "cluster_name": "Segmento 2",
  "cluster_similarity": 0.891
}
```

**Valori del campo `mode`:**

| Valore | Quando | Strategia |
|---|---|---|
| `seed` | explicit/biased, o implicit senza REG/ALPHA salvato | Media semplice dei vettori seed |
| `seed_cold_start` | implicit con ALPHA e REG disponibili | ALS One-Step — risolve il sistema lineare |
| `subject` | `subject_id` fornito | Vettore soggetto salvato durante il training |

I campi `cluster_id`, `cluster_name`, `cluster_similarity` sono presenti solo se il modello
include clustering KMeans (training con ≥ 12 soggetti).

#### Modalità subject

Fornisci l'ID di un soggetto **già presente nel training**.
Il modello usa direttamente il vettore soggetto salvato — più preciso dei seed.

```
Con il modello 'negozio', per il progetto "proj_42", cosa consigli di aggiungere?
```

Output:
```json
{
  "success": true,
  "objects": [
    { "object": "Cassettiere",       "score": 0.91 },
    { "object": "Illuminazione LED", "score": 0.63 }
  ],
  "mode": "subject",
  "model_name": "negozio",
  "model_objects": 37,
  "subject_id": "proj_42"
}
```

---

### 3. Similarità oggetto-oggetto

`similar.py` trova gli oggetti più simili a uno di riferimento usando la
**similarità coseno** tra vettori latenti:

```
sim(i, j) = (V_i · V_j) / (‖V_i‖ · ‖V_j‖)
```

Diverso da `recommend.py`: non costruisce un profilo soggetto, misura la
**vicinanza geometrica nello spazio latente**.

```
Con il modello 'negozio', quali oggetti sono simili a "Bancone Principale"?
```

Output:
```json
{
  "success": true,
  "reference_object": "Bancone Principale",
  "similar_objects": [
    { "object": "Zona Consulenza",      "similarity": 0.94 },
    { "object": "Scaffalature Centrali","similarity": 0.81 }
  ],
  "model_name": "negozio",
  "model_objects": 37
}
```

| Parametro | Tipo | Default | Descrizione |
|---|---|---|---|
| `reference_object` | string | — | Oggetto di riferimento (obbligatorio) |
| `top_n` | number | 10 | Max oggetti simili da restituire |
| `exclude` | array | `[]` | Oggetti aggiuntivi da escludere |
| `min_similarity` | number | -1.0 | Soglia coseno minima (0.5+ per risultati molto affini) |

---

### 4. Profili dei cluster

`cluster_profiles.py` rivela il significato semantico dei segmenti generati durante
il training. Per ogni cluster, restituisce gli oggetti più rappresentativi.

> **Prerequisito:** training con almeno **12 soggetti** per abilitare il clustering KMeans.

```
Con il modello 'negozio', quali sono i profili tipici dei segmenti?
```

Output:
```json
{
  "success": true,
  "model_name": "negozio",
  "clusters": [
    {
      "cluster_id": 0,
      "cluster_name": "Segmento 0",
      "typical_objects": [
        { "object": "Bancone Principale",    "score": 1.24 },
        { "object": "Scaffalature Centrali", "score": 1.11 },
        { "object": "Illuminazione LED",     "score": 0.98 }
      ]
    },
    {
      "cluster_id": 1,
      "cluster_name": "Segmento 1",
      "typical_objects": [
        { "object": "Zona Consulenza",  "score": 1.05 },
        { "object": "Cassa Automatica", "score": 0.87 }
      ]
    }
  ]
}
```

| Parametro | Tipo | Default | Descrizione |
|---|---|---|---|
| `top_n` | number | 5 | Oggetti tipici per cluster |
| `model_name` | string | config MODEL_NAME | Nome del modello |

> I nomi dei cluster ("Segmento 0", "Segmento 1", …) sono generici.
> L'LLM assegna etichette semantiche basandosi sugli oggetti tipici e sul dominio.

---

### 5. Rilevamento anomalie

`anomalies.py` analizza una lista di oggetti e segnala quelli "fuori contesto".
Utile per validare composizioni, rilevare errori di data-entry o scelte atipiche.

> ⚠️ Richiede almeno **2 oggetti** in `seed_objects`.

```
Controlla se questi oggetti vanno insieme: Bancone, Illuminazione LED, Sedie Ufficio
```

Output:
```json
{
  "success": true,
  "model_name": "negozio",
  "analyzed_items": 3,
  "anomalies_found": 1,
  "anomalies": [
    {
      "object": "Sedie Ufficio",
      "score": 0.04,
      "reason": "Score previsto (0.04) inferiore alla soglia di anomalia (0.1)."
    }
  ],
  "context_coherence": {
    "Bancone Principale": 0.82,
    "Illuminazione LED":  0.76,
    "Sedie Ufficio":      0.04
  }
}
```

| Parametro | Tipo | Default | Descrizione |
|---|---|---|---|
| `seed_objects` | array | — | Lista oggetti da analizzare (min 2, obbligatorio) |
| `threshold` | number | 0.1 | Soglia anomalia 0.0–1.0 |
| `model_name` | string | config MODEL_NAME | Nome del modello |

---

### 6. Oggetti popolari (cold start)

`popular.py` restituisce gli oggetti globalmente più frequenti nel dataset.
**Usalo esclusivamente come fallback di cold start** — se hai anche un solo seed
valido, usa `recommend.py` che è molto più personalizzato.

Output:
```json
{
  "success": true,
  "model_name": "negozio",
  "popular_objects": [
    { "object": "Bancone Principale",    "occurrences": 412 },
    { "object": "Illuminazione LED",     "occurrences": 389 },
    { "object": "Scaffalature Centrali", "occurrences": 301 }
  ]
}
```

| Parametro | Tipo | Default | Descrizione |
|---|---|---|---|
| `top_n` | number | 10 | Oggetti popolari da restituire |
| `model_name` | string | config MODEL_NAME | Nome del modello |

---

### 7. Invocazione da un'altra skill (inter-skill bus)

Questa skill può fungere da **servizio ML** per altre skill tramite il bus interno.

**Nella skill chiamante** (`skill.yaml`):
```yaml
config:
  - key: ALS_SKILL_ID
    description: "UUID della skill als-recommender."
    required: false
    default: ""
```

**Nello script Python** della skill chiamante:
```python
import os, json, urllib.request

def _call_als(script: str, inp: dict, timeout_s: int = 10) -> dict:
    als_skill_id = _config.get('ALS_SKILL_ID', '').strip()
    if not als_skill_id:
        return {}
    url  = f"{os.environ['BACKEND_INTERNAL_URL']}/internal/skills/{als_skill_id}/invoke"
    body = json.dumps({'script': script, 'input': inp}).encode()
    req  = urllib.request.Request(url, data=body, method='POST', headers={
        'Content-Type':       'application/json',
        'x-internal-token': os.environ['INTERNAL_TOKEN'],
    })
    try:
        with urllib.request.urlopen(req, timeout=timeout_s) as r:
            return json.loads(r.read()).get('output', {})
    except Exception:
        return {}


# Raccomanda da seed
objects = _call_als('recommend.py', {
    'seed_objects': ['Bancone Principale', 'Illuminazione LED'],
    'top_n': 6,
    'model_name': 'negozio',
}).get('objects', [])

# Raccomanda da soggetto esistente
objects = _call_als('recommend.py', {
    'subject_id': 'proj_42',
    'top_n': 6,
    'model_name': 'negozio',
}).get('objects', [])

# Oggetti simili
similar = _call_als('similar.py', {
    'reference_object': 'Bancone Principale',
    'top_n': 5,
    'model_name': 'negozio',
}).get('similar_objects', [])

# Anomalie
anomalies = _call_als('anomalies.py', {
    'seed_objects': ['Bancone Principale', 'LED Strip', 'Sedie Ufficio'],
    'threshold': 0.1,
}).get('anomalies', [])
```

---

## Esempi di dataset

### Allestimento negozi (implicit)
```csv
subject_id,object_id
proj_1,Bancone Principale
proj_1,Esposizione Parete
proj_1,Illuminazione LED
proj_2,Bancone Principale
proj_2,Scaffalature Centrali
```
Config: `ALS_TYPE=implicit`, `COLUMN_SUBJECT=subject_id`, `COLUMN_OBJECT=object_id`

### E-commerce con quantità (implicit)
```csv
order_id,product,quantity
1001,iPhone Case,2
1001,Screen Protector,1
1002,iPhone Case,1
1002,AirPods,1
```
Config: `ALS_TYPE=implicit`, `ALS_ALPHA=20`, `COLUMN_SUBJECT=order_id`, `COLUMN_OBJECT=product`, `COLUMN_VALUE=quantity`

### Valutazioni film (explicit)
```csv
user_id,movie,rating
user_1,Inception,5
user_1,Interstellar,4
user_2,Inception,4
user_2,The Dark Knight,5
```
Config: `ALS_TYPE=explicit`, `COLUMN_SUBJECT=user_id`, `COLUMN_OBJECT=movie`, `COLUMN_VALUE=rating`

### Valutazioni con bias di popolarità (biased)
Stesso dataset dei film con `ALS_TYPE=biased` per correggere l'effetto popolarità.

---

## Guida alla scelta della variante

```
Hai rating espliciti (1-5 stelle, punteggi)?
│
├─ NO  → usa implicit
│        (presenze, acquisti, click, co-occorrenze)
│
└─ SÌ → Alcuni oggetti hanno molte più interazioni di altri?
         │
         ├─ NO  → usa explicit
         │
         └─ SÌ → usa biased  (corregge l'effetto popolarità con b_i)
```

---

## Dipendenze

| Pacchetto | Versione | Usata da |
|---|---|---|
| `numpy` | ≥ 1.26 | tutti gli script |
| `scipy` | ≥ 1.13 | `implicit` (matrici sparse) + KMeans in `train.py` |
| `implicit` | ≥ 0.7.2 | variante `implicit` (iALS) |

Le varianti `explicit` e `biased`, e gli script di inferenza (`recommend.py`, `similar.py`,
`cluster_profiles.py`, `anomalies.py`, `popular.py`, `info.py`) usano solo `numpy`.

---

## Note tecniche

### Persistenza del modello

```
{SKILLS_OUTPUT_DIR}/als-recommender/{SKILL_ID}/{model_name}/model.pkl
```

Il modello persiste tra sessioni. Ogni `train.py` con lo stesso `model_name` sovrascrive
il precedente. Modelli con nomi diversi coesistono nella stessa skill.

### Pipeline di scoring (`recommend.py`)

**Modalità seed:**
1. Recupera i vettori `V_i ∈ ℝ^k` per ciascun seed
2. Pseudo-soggetto: `ū = mean(V_seed₁, V_seed₂, ...)` (o ALS One-Step per implicit)

**Modalità subject:**
1. Carica `U_u ∈ ℝ^k` da `subject_factors[subject_index[subject_id]]`

**Pipeline comune:**
3. Score: `s_i = V_i · ū`
4. Per `biased`: `s_i += b_i`
5. Normalizza in `[0, 1]`
6. Restituisce top-N escludendo seed / lista `exclude`

### Similarità coseno (`similar.py`)

```
sim(i, ref) = (V_i · V_ref) / (‖V_i‖ · ‖V_ref‖)   ∈ [−1, 1]
```

Il bias `b_i` **non** è incluso: misura la struttura latente, non la popolarità assoluta.

### Normalizzazione dei tipi ID

`subject_id` e `object_id` vengono convertiti a `str` durante il training,
garantendo coerenza tra `train.py` (che salva) e gli script di inferenza (che leggono).

### Multi-modello

```
{SKILLS_OUTPUT_DIR}/als-recommender/{SKILL_ID}/
  default/model.pkl
  negozio/model.pkl
  ecommerce/model.pkl
```

### Clustering

Il clustering KMeans viene eseguito automaticamente sui vettori soggetto durante il training
se il dataset ha ≥ 12 soggetti. I centroidi sono salvati nel pkl (`km_centers`).
- `recommend.py` → assegna il soggetto corrente al cluster più vicino
- `cluster_profiles.py` → mostra gli oggetti tipici di ogni cluster

### Condivisione della skill

**Modello condiviso:** admin installa la skill con `scope: shared`. Tutti accedono
agli stessi modelli — un unico `SKILL_ID` da riferire nelle skill client.

**Modello personale:** ogni utente installa la propria copia — dati privati, modelli separati.

### Limitazioni

- `explicit` e `biased` usano matrici dense — non adatte a dataset con > 50.000 oggetti.
- Oggetti mai visti nel training non possono essere raccomandati né usati come seed.
- `anomalies.py` richiede almeno 2 `seed_objects`.
- Il clustering richiede ≥ 12 soggetti nel training.
- Il bias `b_i` non è incluso in `similar.py` — oggetti molto popolari possono risultare
  meno simili del previsto. In quel caso usare `recommend.py` con un singolo seed.

## Network

Nessuna connessione esterna. La skill opera in locale e/o tramite il backend interno (`BACKEND_INTERNAL_URL`, sempre raggiungibile e non soggetto all'allowlist egress).
