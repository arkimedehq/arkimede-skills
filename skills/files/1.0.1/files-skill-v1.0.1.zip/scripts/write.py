#!/usr/bin/env python3
"""write.py — scrive/crea un file in una sorgente (content testo UTF-8 o content_base64).

'source' identifica la sorgente (default 'local').
"""
import base64
from _common import load_input, file_op, ok, fail


def main():
    data, _config = load_input()
    path = data.get('path')
    if not path:
        fail("Parametro 'path' obbligatorio.")
    source = data.get('source') or 'local'

    if data.get('content') is not None:
        raw = str(data['content']).encode('utf-8')
    elif data.get('content_base64'):
        raw = base64.b64decode(data['content_base64'])
    else:
        fail("Fornisci 'content' (testo UTF-8) oppure 'content_base64' (binario).")

    b64 = base64.b64encode(raw).decode('ascii')
    res = file_op(source, {'op': 'write', 'path': path, 'content': b64})
    row = (res.get('rows') or [{}])[0]
    ok(op='write', source=source, path=path, size=row.get('size', len(raw)),
       message=f"Scritto '{path}'.")


if __name__ == '__main__':
    try:
        main()
    except Exception as e:  # noqa: BLE001
        fail(e)
