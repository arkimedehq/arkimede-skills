"""
_common.py — helper condivisi dagli script della skill `files`.

NON è uno script invocabile dall'LLM: è un modulo importato dagli altri script
(stessa cartella → su sys.path automaticamente).

Modello: i file vivono in una o più "sorgenti" (source) file-share, tutte esposte
in modo uniforme dal backend interno:
  - 'local'  → filesystem del backend (SKILLS_OUTPUT_DIR), sempre presente
  - <id ds>  → DataSource file-share di rete (SMB/SFTP/WebDAV) configurata dall'utente

L'I/O passa SEMPRE dal backend interno (BACKEND_INTERNAL_URL): la skill non si
connette mai direttamente alla rete o al filesystem.

Contratto runtime:
  - env:    INTERNAL_TOKEN (token di run firmato), BACKEND_INTERNAL_URL
  - stdin:  JSON con i parametri + `_config` (config vars della skill + system vars)
"""
import os
import sys
import json
import urllib.request
import urllib.error


def load_input():
    """Ritorna (data, config) leggendo lo stdin JSON."""
    raw = sys.stdin.read()
    data = json.loads(raw) if raw.strip() else {}
    return data, data.get('_config', {})


def _backend():
    return os.environ.get('BACKEND_INTERNAL_URL', 'http://localhost:3000').rstrip('/')


def _token():
    t = os.environ.get('INTERNAL_TOKEN', '')
    if not t:
        raise RuntimeError(
            "INTERNAL_TOKEN assente: lo script non sta girando dentro un'esecuzione valida."
        )
    return t


def _request(method, path, body=None):
    url = f"{_backend()}{path}"
    payload = json.dumps(body).encode('utf-8') if body is not None else None
    req = urllib.request.Request(url, data=payload, method=method, headers={
        'Content-Type':     'application/json',
        'x-internal-token': _token(),
    })
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        detail = e.read().decode('utf-8', 'replace')
        raise RuntimeError(f"backend HTTP {e.code}: {detail[:400]}")


def list_sources():
    """Elenco delle sorgenti file-share accessibili: [{id, name, engine, family}, ...].

    Antepone sempre la sorgente 'local'. Il backend applica lo scope dell'utente.
    """
    res = _request('GET', '/internal/datasources?family=fileshare')
    return res.get('sources', [])


def file_op(source_id, spec):
    """Esegue un'operazione file su una sorgente (per id). Ritorna il JSON del backend."""
    return _request('POST', f"/internal/datasources/{source_id}/query", {'file': spec})


def vector_ingest(config, items, recreate=False):
    coll = config.get('VECTOR_COLLECTION') or os.environ.get('VECTOR_COLLECTION', '')
    if not coll:
        raise RuntimeError("VECTOR_COLLECTION non configurato: richiesto per mode='embed'.")
    return _request('POST', '/internal/vector/ingest', {
        'collection': coll, 'recreate': recreate, 'items': items,
    })


def ingest_datasource_file(config, source, path, collection=None):
    """Indicizza un file di una sorgente nel vector store usando la capacità del
    backend (POST /internal/embed/datasource): è il BE a leggere il file, estrarne
    il testo (PDF/DOCX/XLSX/testo/OCR), fare chunk e indicizzare. La skill fornisce
    solo (source, path) e, opzionalmente, la collection.

    Collection: precedenza all'argomento esplicito (scelto dall'utente/agente), poi
    la config var VECTOR_COLLECTION; se nessuna delle due è valorizzata si OMETTE e
    il backend usa la sua collection di default (e la crea se non esiste).
    Ritorna {chunks, collection}."""
    coll = (collection
            or config.get('VECTOR_COLLECTION')
            or os.environ.get('VECTOR_COLLECTION', '')
            or '').strip()
    body = {'source': source, 'path': path}
    if coll:
        body['collection'] = coll
    return _request('POST', '/internal/embed/datasource', body)


def ok(**fields):
    print(json.dumps({'success': True, **fields}))


def fail(message):
    print(json.dumps({'success': False, 'error': str(message)}))
    sys.exit(1)
