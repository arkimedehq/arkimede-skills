#!/usr/bin/env python3
"""delete.py — elimina un file (o cartella con recursive) da una sorgente. Richiede confirm.

'source' identifica la sorgente (default 'local').
"""
from _common import load_input, file_op, ok, fail


def main():
    data, _config = load_input()
    path = data.get('path')
    if not path:
        fail("Parametro 'path' obbligatorio.")
    if not data.get('confirm'):
        fail("Cancellazione non confermata: passa confirm=true per eliminare.")
    source = data.get('source') or 'local'
    recursive = bool(data.get('recursive', False))

    file_op(source, {'op': 'delete', 'path': path, 'recursive': recursive})
    ok(op='delete', source=source, path=path, recursive=recursive,
       message=f"Eliminato '{path}'.")


if __name__ == '__main__':
    try:
        main()
    except Exception as e:  # noqa: BLE001
        fail(e)
