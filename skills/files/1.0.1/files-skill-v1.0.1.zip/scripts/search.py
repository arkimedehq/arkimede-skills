#!/usr/bin/env python3
"""search.py — cerca file per nome in TUTTE le sorgenti (locale + share di rete).

Default: fan-out su ogni sorgente file-share accessibile. Ogni risultato è taggato
con la sorgente (source / source_name) così read/write/delete possono riusarla.
Passa 'source' per restringere a una sola sorgente.
"""
import fnmatch
from _common import load_input, list_sources, file_op, ok, fail


def _matches(name, query):
    if not query:
        return True
    if any(ch in query for ch in '*?['):
        return fnmatch.fnmatch(name, query)
    return query.lower() in name.lower()


def _search_one(source, start, query, recursive, remaining):
    """Cerca dentro una singola sorgente; ritorna lista di entry annotate."""
    found = []

    def walk(path, depth):
        if len(found) >= remaining:
            return
        try:
            res = file_op(source['id'], {'op': 'list', 'path': path})
        except Exception as e:  # noqa: BLE001 — una sorgente irraggiungibile non blocca le altre
            found.append({'_error': str(e), 'source': source['id'], 'source_name': source['name']})
            return
        for entry in res.get('rows', []):
            if len(found) >= remaining:
                break
            if entry.get('type') == 'file' and _matches(entry.get('name', ''), query):
                found.append({**entry, 'source': source['id'], 'source_name': source['name']})
            elif recursive and entry.get('type') == 'dir' and depth > 0:
                walk(entry.get('path', ''), depth - 1)

    walk(start, 12 if recursive else 0)
    return found


def main():
    data, _config = load_input()
    start = data.get('path') or ''
    query = data.get('query') or ''
    recursive = bool(data.get('recursive', False))
    max_results = int(data.get('max_results') or 200)
    only_source = data.get('source')

    sources = list_sources()
    if only_source:
        sources = [s for s in sources if s['id'] == only_source]
        if not sources:
            fail(f"Sorgente '{only_source}' non trovata o non accessibile.")

    results = []
    errors = []
    for src in sources:
        if len(results) >= max_results:
            break
        for entry in _search_one(src, start, query, recursive, max_results - len(results)):
            if '_error' in entry:
                errors.append({'source': entry['source'], 'source_name': entry['source_name'],
                               'error': entry['_error']})
            else:
                results.append(entry)

    ok(count=len(results), files=results,
       searched=[{'id': s['id'], 'name': s['name']} for s in sources],
       errors=errors)


if __name__ == '__main__':
    try:
        main()
    except Exception as e:  # noqa: BLE001
        fail(e)
