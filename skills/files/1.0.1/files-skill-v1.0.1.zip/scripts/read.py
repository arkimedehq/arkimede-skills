#!/usr/bin/env python3
"""read.py — legge/apre un file da una sorgente: mode text | attach | view | embed.

'source' identifica la sorgente (default 'local'); usa l'id restituito da search.
"""
import base64
import os
import time
from urllib.parse import quote
from _common import load_input, file_op, ingest_datasource_file, ok, fail

MAX_TEXT_CHARS = 50_000


def main():
    data, config = load_input()
    path = data.get('path')
    if not path:
        fail("Parametro 'path' obbligatorio.")
    source = data.get('source') or 'local'
    mode = (data.get('mode') or 'text').lower()

    # ── mode='view': NON legge il file — costruisce solo il link di streaming. ──
    # Il backend (/api/files/stream) trasmette il file a chunk con supporto Range,
    # quindi funziona anche con file enormi (es. video da decine di GB) senza mai
    # caricarli in memoria. Niente lettura qui = nessun rischio di OOM/crash.
    if mode == 'view':
        src = quote(str(source), safe='')
        p = quote(str(path), safe='')
        view_url = f"/api/files/stream?source={src}&path={p}"
        ok(mode='view', source=source, path=path,
           filename=os.path.basename(str(path).rstrip('/')),
           view_url=view_url, message=f"Apri/visualizza: {view_url}")
        return

    # ── mode='embed': delega TUTTO al backend (capacità di prima classe del BE).
    # La skill fornisce solo (source, path); il BE legge il file, ne estrae il testo
    # (PDF/DOCX/XLSX/testo/OCR), fa chunk e indicizza. Niente lettura/decodifica qui.
    if mode == 'embed':
        # collection: scelta a runtime (l'utente/agente può indicarla). Se omessa,
        # ripiega su VECTOR_COLLECTION (config) e infine sulla collection di default
        # del backend, che la crea se non esiste.
        collection = data.get('collection')
        # L'indicizzazione è ASINCRONA: il backend accoda il lavoro e lo svolge in
        # background (estrazione testo + embedding possono richiedere tempo). Ritorna
        # subito; l'utente riceve una notifica a fine. Niente attesa/timeout qui.
        r = ingest_datasource_file(config, source, path, collection)
        if r.get('status') == 'inline':
            # Fallback senza coda (Redis assente): eseguito subito.
            chunks = r.get('chunks', 0)
            if not chunks:
                fail("Nessun testo estraibile dal file (formato non supportato o documento vuoto/immagine senza testo).")
            ok(mode='embed', source=source, path=path, status='done',
               chunks=chunks, collection=r.get('collection'))
        else:
            ok(mode='embed', source=source, path=path, status='queued',
               collection=collection,
               message="Indicizzazione avviata in background: riceverai una notifica al termine.")
        return

    # ── text/attach: leggono il contenuto. Il backend rifiuta i file troppo grandi
    #    per la lettura in memoria (per quelli usa 'view' per lo streaming). ──
    res = file_op(source, {'op': 'read', 'path': path})
    rows = res.get('rows') or []
    if not rows:
        fail(f"Nessun contenuto restituito per '{path}'.")
    raw = base64.b64decode(rows[0].get('content') or '')
    size = rows[0].get('size', len(raw))

    if mode == 'text':
        try:
            text = raw.decode('utf-8')
        except UnicodeDecodeError:
            fail("Il file non è testo UTF-8: usa mode='attach' per scaricarlo o mode='view' per aprirlo.")
        truncated = len(text) > MAX_TEXT_CHARS
        ok(mode='text', source=source, path=path, size=size,
           truncated=truncated, content=text[:MAX_TEXT_CHARS])

    elif mode == 'attach':
        upload_dir = os.path.abspath(config.get('UPLOAD_DIR', '/app/uploads'))
        out_dir = os.environ.get('SKILLS_OUTPUT_DIR') or os.path.join(upload_dir, 'skills-output')
        os.makedirs(out_dir, exist_ok=True)
        fname = os.path.basename(path.rstrip('/')) or f"file_{int(time.time())}"
        out_path = os.path.join(out_dir, fname)
        with open(out_path, 'wb') as f:
            f.write(raw)
        # The file lives in SKILLS_OUTPUT_DIR, which /api/files/raw accepts as an
        # allowed root: the rel MUST be relative to out_dir, not upload_dir.
        # (SKILLS_OUTPUT_DIR may be a separate mount → relpath vs upload_dir would
        # produce an escaping "../../work/skills-output/..." that the backend rejects.)
        rel = os.path.relpath(out_path, out_dir)
        download_url = f"/api/files/raw?rel={quote(rel)}"
        ok(mode='attach', source=source, path=path, filename=fname, size=size,
           download_url=download_url, message=f"File pronto. Scarica: {download_url}")

    else:
        fail(f"mode non valido: '{mode}' (usa text | attach | view | embed).")


if __name__ == '__main__':
    try:
        main()
    except Exception as e:  # noqa: BLE001
        fail(e)
