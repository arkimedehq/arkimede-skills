# Files — gestione file unificata (locale + share di rete)

Skill per **personalAgent** che permette all'AI di operare sui file dell'utente in
**tutte** le sue posizioni con un'unica interfaccia: il filesystem **locale** del
backend (`Locale`, cartella `SKILLS_OUTPUT_DIR`) e le cartelle condivise di **rete**
(**SMB/CIFS-Samba, SFTP, WebDAV**) configurate come DataSource file-share.

La skill è **sottile e disaccoppiata**: non tocca mai direttamente né il filesystem né
la rete. Delega ogni operazione al backend tramite l'endpoint interno delle DataSource,
che esegue l'I/O. Per questo funziona anche con l'egress-proxy attivo.

---

## Modello: le "sorgenti" (source)

Ogni file vive in una **sorgente**:

| `source` | Cos'è |
|----------|-------|
| `local` | Filesystem del backend (`SKILLS_OUTPUT_DIR`). Sempre presente, è il default. |
| `<id DataSource>` | Una share di rete (SMB/SFTP/WebDAV) configurata in Impostazioni → DataSource. |

**`search` fa fan-out automatico su tutte le sorgenti**: "cerca il file X" lo trova
ovunque, locale o di rete. Ogni risultato riporta `source` e `source_name`: passa
quell'`id` a `read`/`write`/`delete` per agire sul file giusto. Se ometti `source`,
read/write/delete usano `local`.

## Prerequisiti

- Nessuno per la sorgente `local` (sempre disponibile).
- Per le share di rete: una **DataSource di famiglia file-share** già configurata
  (Impostazioni → DataSource → engine `SMB/CIFS`, `SFTP` o `WebDAV`), es.:
  - `smb://[DOMINIO;]user:pass@host/share[/cartella]`
  - `sftp://user:pass@host:22[/cartella]`
  - `webdavs://user:pass@host[/cartella]` (`webdav://` per http)
- (Opzionale) Una **collection vettoriale** per la lettura in modalità `embed`.

## Installazione

1. Impostazioni → Skills → **Carica ZIP** → `files-v1.0.0.zip`
2. Drawer della skill → **Configura** (opzionale):
   - `VECTOR_COLLECTION` → collection per la modalità `embed`.
3. **Assegna** la skill ai progetti desiderati.

Nessuna configurazione obbligatoria: la skill scopre da sola le sorgenti accessibili.

## Strumenti

| Tool | Azione |
|------|--------|
| `search` | Cerca file per nome (sottostringa o glob) su **tutte** le sorgenti (o una sola con `source`) |
| `read` | Legge un file: `text` (in chat) / `attach` (download) / `embed` (vector store) |
| `write` | Scrive/crea un file (testo UTF-8 o base64) |
| `delete` | Elimina un file/cartella (richiede `confirm: true`) |

Tutti i path sono **relativi alla base** della sorgente.

## Sicurezza

- **Identità & scope**: ogni operazione viaggia col token di run firmato
  (`x-internal-token`); per le share di rete il backend verifica che l'utente del run
  abbia accesso allo scope della DataSource (personal/team/org).
- **Path-traversal**: ogni percorso è confinato sotto la base della sorgente (lato backend),
  sia per le share di rete sia per `local`.
- **`local` condivisa**: la sorgente locale punta a `SKILLS_OUTPUT_DIR`, condivisa tra
  gli utenti (parità col comportamento attuale; l'isolamento per-tenant è una fase a parte).
- **Cancellazione**: `delete` richiede `confirm: true` esplicito.
- **Credenziali**: stanno cifrate nella DataSource; la skill non le vede mai.
- **Dimensione**: la lettura è limitata a 10 MB per file.

## Versione

1.0.0 — licenza AGPL-3.0-or-later. Unifica e sostituisce le skill `file-lookup`,
`file-manager` e `file-share`.
