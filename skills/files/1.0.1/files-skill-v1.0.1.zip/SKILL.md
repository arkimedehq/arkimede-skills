---
name: files
description: |
  Gestione file unificata su TUTTE le posizioni dell'utente: il filesystem locale ('Locale', SKILLS_OUTPUT_DIR) e le cartelle condivise di rete (SMB/CIFS-Samba, SFTP, WebDAV) configurate come DataSource file-share. Permette di cercare, leggere, scrivere ed eliminare file. La ricerca fa fan-out automatico su tutte le sorgenti: "cerca il file X" lo trova ovunque, locale o di rete. La lettura può estrarre il testo in chat, allegarlo come download o indicizzarlo nel vector store. L'I/O avviene sempre nel backend (endpoint interno): la skill non si connette mai direttamente.
version: 1.0.1
author: info@rstonline.it
license: AGPL-3.0-or-later
runtime:
  config:
    - key: VECTOR_COLLECTION
      description: Collection di DEFAULT per mode='embed' (opzionale). Se non impostata, la collection può essere passata a runtime nell'input di read.py; in mancanza di entrambe il backend usa la propria collection di default.
      required: false
      secret: false
      type: collection
  scripts:
    - filename: scripts/search.py
      language: python
      mode: task
      description: |
        Cerca file per nome (sottostringa o glob) in TUTTE le sorgenti accessibili (Locale + ogni share di rete), con opzione ricorsiva. È la scelta giusta quando l'utente dice "cerca/trova il file X" senza dire dove. Ogni risultato include 'source' (id della sorgente) e 'source_name': passali a read/write/delete. Usa 'source' in input per restringere a una sola sorgente.
      input_schema:
        type: object
        properties:
          query:
            type: string
            description: 'Filtro sul nome: sottostringa (case-insensitive) o glob (es. *.pdf).'
          path:
            type: string
            description: Cartella di partenza (relativa alla base della sorgente). Vuoto = radice.
          recursive:
            type: boolean
            description: Se true scende nelle sottocartelle (default false).
          source:
            type: string
            description: Restringe la ricerca a una sola sorgente (id). Omesso = tutte.
          max_results:
            type: number
            description: Numero massimo di risultati totali (default 200).
    - filename: scripts/read.py
      language: python
      mode: task
      description: |
        Legge un file da una sorgente. mode='text' restituisce il testo in chat; mode='attach' lo materializza e restituisce un 'download_url' (link cliccabile per SCARICARE il file) — usalo quando l'utente chiede "il link" o di scaricare; mode='view' restituisce un 'view_url' che APRE/RIPRODUCE il file inline nel browser (PDF, immagini, audio/video) — usalo quando l'utente vuole visionare, aprire o riprodurre il file; mode='embed' fa indicizzare il file dal backend (che ne estrae il testo: PDF, DOCX, XLSX, testo, immagini via OCR) nel vector store (serve VECTOR_COLLECTION).
      input_schema:
        type: object
        required:
          - path
        properties:
          path:
            type: string
            description: Percorso del file (relativo alla base della sorgente).
          source:
            type: string
            description: Sorgente del file (id da search). Default 'local'.
          mode:
            type: string
            enum:
              - text
              - attach
              - view
              - embed
            description: text (default) = testo in chat | attach = link di download | view = link di visione/streaming inline | embed = il backend estrae il testo (PDF/DOCX/XLSX/testo/immagini-OCR) e indicizza nel vector store.
          collection:
            type: string
            description: 'Solo mode=embed: nome della collection del vector store in cui indicizzare. Se omesso, usa VECTOR_COLLECTION (se configurata) o la collection di default del backend (creata se non esiste). Chiedi all''utente quale collection usare se non è ovvio.'
    - filename: scripts/write.py
      language: python
      mode: task
      description: |
        Scrive/crea un file in una sorgente. Fornire 'content' (testo UTF-8) oppure 'content_base64' (binario).
      input_schema:
        type: object
        required:
          - path
        properties:
          path:
            type: string
            description: Percorso del file da scrivere (relativo alla base della sorgente).
          source:
            type: string
            description: Sorgente di destinazione (id). Default 'local'.
          content:
            type: string
            description: Contenuto testuale UTF-8.
          content_base64:
            type: string
            description: Contenuto binario in base64 (alternativo a content).
    - filename: scripts/delete.py
      language: python
      mode: task
      description: |
        Elimina un file (o una cartella con recursive=true) da una sorgente. Operazione distruttiva: richiede confirm=true.
      input_schema:
        type: object
        required:
          - path
          - confirm
        properties:
          path:
            type: string
            description: Percorso da eliminare (relativo alla base della sorgente).
          source:
            type: string
            description: Sorgente (id). Default 'local'.
          confirm:
            type: boolean
            description: Deve essere true per procedere (guardia anti-cancellazione accidentale).
          recursive:
            type: boolean
            description: Se true elimina una cartella e il suo contenuto (default false).
---

# Files — gestione file unificata (locale + share di rete)

> ⚠️ **IMPORTANTE — Nomi tool esatti da usare nelle chiamate:**
>
> | Azione | **Nome tool da invocare** |
> |--------|--------------------------|
> | Cercare file (ovunque) | **`skill_files_search_py`** |
> | Leggere un file | **`skill_files_read_py`** |
> | Scrivere/creare un file | **`skill_files_write_py`** |
> | Eliminare un file/cartella | **`skill_files_delete_py`** |
>
> **NON chiamare mai** un tool con nomi come `files`, `search`, `read`, `write`, `delete` —
> usa sempre i nomi esatti della tabella.

## Quando usarla

Usa questa skill quando l'utente chiede di **cercare, leggere, scrivere o eliminare file**,
sia sul filesystem locale dell'app sia su cartelle condivise di rete (SMB/SFTP/WebDAV).

In particolare: quando dice "**cerca/trova il file X**" senza dire dove, usa
`skill_files_search_py` — cerca automaticamente in **tutte** le posizioni.

> 🔗 **Quando l'utente chiede un LINK per un file** NON limitarti a `search` (dà solo
> il percorso interno della sorgente, **non** cliccabile). Dopo aver trovato il file
> con `search`, chiama **`skill_files_read_py`** passando il `source` + `path` del
> risultato, scegliendo il `mode` in base all'intento:
>
> - **scaricare / avere il file** (*"dammi il link per scaricarlo"*, *"mandami il file"*)
>   → `mode: "attach"` → restituisce `download_url`. Presentalo come
>   `[Scarica report.pdf](/api/files/raw?rel=...)`.
> - **visionare / aprire / riprodurre nel browser** (*"fammelo vedere"*, *"aprilo"*,
>   *"riproducilo"*, PDF/immagini/audio/video, anche file ENORMI come i video) →
>   `mode: "view"` → restituisce `view_url`. Presentalo come
>   `[Apri report.pdf](/api/files/stream?source=...&path=...)`.
>
> Entrambi i link sono autenticati e cliccabili in chat. `view` usa lo streaming
> (Range): apre/riproduce anche video da molti GB senza scaricarli. Il percorso
> grezzo della share **non** è cliccabile: usa sempre `attach` o `view`.

**Non** usarla per generare contenuti testuali in chat o per file allegati dall'utente
nella conversazione (quelli sono già accessibili).

## Concetto chiave: le "sorgenti" (source)

Ogni file vive in una **sorgente**, identificata da un `source`:

- **`local`** → filesystem dell'app (default, sempre disponibile).
- **`<id>`** → una cartella condivisa di rete configurata come DataSource (l'`id` è
  quello restituito dalla ricerca).

**Workflow tipico:** prima `search` (fa fan-out su tutte le sorgenti e restituisce per
ogni risultato il campo `source`), poi passa quel `source` a `read`/`write`/`delete` per
agire sul file giusto. Se ometti `source`, le altre operazioni usano `local`.

> `_config` viene iniettato automaticamente — non includerlo mai nell'input.

---

<!-- @tool: search.py -->
## `search.py` — Cerca file ovunque

**Tool name (usa questo nome esatto):** `skill_files_search_py`

Cerca file per nome su **tutte** le sorgenti accessibili (locale + share di rete). È la
scelta giusta quando l'utente non specifica dove si trova il file.

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `query` | string | ❌ | Filtro sul nome: sottostringa (case-insensitive) o glob (es. `*.pdf`) |
| `path` | string | ❌ | Cartella di partenza (relativa alla base della sorgente). Vuoto = radice |
| `recursive` | boolean | ❌ | Scende nelle sottocartelle (default `false`) |
| `source` | string | ❌ | Restringe a una sola sorgente (id). Omesso = cerca in tutte |
| `max_results` | number | ❌ | Max risultati totali (default 200) |

### Output

```json
{
  "success": true,
  "count": 1,
  "files": [
    { "name": "report.pdf", "path": "docs/report.pdf", "size": 12345,
      "source": "local", "source_name": "Locale" }
  ],
  "searched": [{ "id": "local", "name": "Locale" }],
  "errors": []
}
```

Per ogni file usa `source` + `path` nelle chiamate successive. Una sorgente
irraggiungibile finisce in `errors[]` senza bloccare le altre.

<!-- @tool: read.py -->
## `read.py` — Leggi un file

**Tool name (usa questo nome esatto):** `skill_files_read_py`

Legge un file da una sorgente in tre modalità.

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `path` | string | ✅ | Percorso del file (relativo alla base della sorgente) |
| `source` | string | ❌ | Sorgente del file (id da `search`). Default `local` |
| `mode` | string | ❌ | `text` (default) = testo in chat · `attach` = link di **download** · `view` = link di **visione/streaming inline** nel browser · `embed` = il **backend** estrae il testo (PDF/DOCX/XLSX/testo/immagini-OCR) e indicizza nel vector store |
| `collection` | string | ❌ | Solo `mode=embed`: collection del vector store in cui indicizzare. Se omesso → `VECTOR_COLLECTION` (se configurata) → collection di default del backend (creata se non esiste) |

> 📌 **Embed — quale collection?** Per `mode=embed`, se l'utente non ha indicato una
> collection e non ne è configurata una di default ovvia, **chiedi all'utente in quale
> collection indicizzare** (può indicarne una esistente o un nome nuovo: il backend la
> crea). Poi passa quel nome in `collection`. Se l'utente dice "indicizza e basta" o non
> ha preferenze, ometti `collection` e verrà usata quella di default.
>
> ⏳ **Embed è ASINCRONO.** La chiamata ritorna subito con `status: "queued"`: il backend
> indicizza in background e **notifica l'utente al termine**. NON è un errore e NON va
> ritentato. Comunica all'utente che l'indicizzazione è stata avviata e riceverà una
> notifica a fine (può volerci qualche minuto per i file grandi).

### Output

`mode=text`:
```json
{ "success": true, "mode": "text", "source": "local", "path": "note.md",
  "size": 29, "truncated": false, "content": "..." }
```

`mode=attach` (restituisce un link di download):
```json
{ "success": true, "mode": "attach", "filename": "note.md",
  "download_url": "/api/files/raw?rel=note.md", "size": 29 }
```

`mode=view` (restituisce un link di visione/streaming inline nel browser — NON legge
il file: funziona anche con video enormi):
```json
{ "success": true, "mode": "view", "filename": "film.mkv",
  "view_url": "/api/files/stream?source=ab12&path=Film%2Ffilm.mkv" }
```

### ⚠️ Regola critica sull'URL (mode=attach / mode=view)

**Usa SEMPRE il campo `download_url` / `view_url` esattamente come restituito — non costruirlo a mano.**

- ✅ Download: `[Scarica note.md](/api/files/raw?rel=note.md)`
- ✅ Visione:  `[Apri film.mkv](/api/files/stream?source=ab12&path=Film%2Ffilm.mkv)`
- ❌ Sbagliato: derivare l'URL da `filename` o `path`

<!-- @tool: write.py -->
## `write.py` — Scrivi/crea un file

**Tool name (usa questo nome esatto):** `skill_files_write_py`

Crea o sovrascrive un file in una sorgente. Fornisci `content` (testo) **oppure**
`content_base64` (binario).

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `path` | string | ✅ | Percorso del file da scrivere (relativo alla base della sorgente) |
| `source` | string | ❌ | Sorgente di destinazione (id). Default `local` |
| `content` | string | ❌ | Contenuto testuale UTF-8 |
| `content_base64` | string | ❌ | Contenuto binario in base64 (alternativo a `content`) |

### Output

```json
{ "success": true, "op": "write", "source": "local", "path": "docs/nota.md",
  "size": 29, "message": "Scritto 'docs/nota.md'." }
```

<!-- @tool: delete.py -->
## `delete.py` — Elimina un file/cartella

**Tool name (usa questo nome esatto):** `skill_files_delete_py`

Operazione **distruttiva**: richiede `confirm: true`. Conferma con l'utente prima di
eliminare se non è già esplicito.

### Input

| Campo | Tipo | Obbligatorio | Descrizione |
|-------|------|:---:|-------------|
| `path` | string | ✅ | Percorso da eliminare (relativo alla base della sorgente) |
| `confirm` | boolean | ✅ | Deve essere `true` per procedere |
| `source` | string | ❌ | Sorgente (id). Default `local` |
| `recursive` | boolean | ❌ | Elimina una cartella e il suo contenuto (default `false`) |

### Output

```json
{ "success": true, "op": "delete", "source": "local", "path": "docs/vecchio",
  "recursive": true, "message": "Eliminato 'docs/vecchio'." }
```
