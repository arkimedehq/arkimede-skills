# 💬 Telegram Bot — Chat yesSir su Telegram

Collega yesSir a Telegram. Ogni utente yesSir può collegare il proprio account
al bot e chattare come se stesse usando l'interfaccia web — con accesso completo
a tutti i tool, MCP, RAG e skill configurati nel proprio profilo.

---

## ⚙️ Configurazione

### 1. Crea il bot su Telegram

1. Apri Telegram e cerca **@BotFather**
2. Invia `/newbot` e segui le istruzioni (nome + username)
3. BotFather ti restituirà un **token** nel formato `1234567890:AAF...`

### 2. Configura la skill in yesSir

1. Vai su **Impostazioni → Skills → telegram-bot → Configura**
2. Imposta `TELEGRAM_BOT_TOKEN` con il token ottenuto da BotFather
3. Torna alla skill e clicca **Avvia daemon**

Il bot è ora in ascolto. Ogni utente yesSir può collegare il proprio account
seguendo la sezione qui sotto.

---

## 🔗 Collegare un account utente

Ogni utente yesSir apre il bot su Telegram e invia:

```
/login email@esempio.com latuapassword
```

Il bot autentica le credenziali contro yesSir, salva la sessione e **cancella
automaticamente il messaggio con le credenziali** per sicurezza.

Da quel momento tutti i messaggi inviati al bot vengono processati come chat
yesSir, con accesso a tutti i tool e le impostazioni dell'utente.

---

## ✅ Comandi disponibili

| Comando | Azione |
|---------|--------|
| `/start` | Messaggio di benvenuto |
| `/login email password` | Collega il tuo account yesSir |
| `/new` | Inizia una nuova conversazione |
| `/help` | Mostra i comandi disponibili |

---

## 🤖 Come funziona

Il daemon gira in background come processo long-running. Quando un utente invia
un messaggio di testo:

1. Il daemon recupera (o crea) la chat yesSir associata alla conversazione Telegram
2. Invia il messaggio al backend via SSE streaming (`POST /api/chats/:id/messages/stream`)
3. Accumulato il testo della risposta, la invia su Telegram (suddivisa in chunk
   da 4000 caratteri se supera il limite di Telegram)
4. Se la risposta contiene file (PDF o altri documenti generati dai tool), li invia
   come allegati Telegram automaticamente

Ogni conversazione Telegram è una chat separata in yesSir, **visibile anche
dall'interfaccia web**. Il comando `/new` azzera il mapping e forza la creazione
di una nuova chat al messaggio successivo.

---

## 📎 Invio automatico di file allegati

Il daemon rileva automaticamente i file generati dai tool yesSir (PDF, Excel, ecc.)
e li invia come documenti Telegram allegati alla risposta testuale.

### Come vengono trovati i file

**Priorità 1 — Evento SSE `file`** (preferito): il backend emette un evento SSE
`{ type: "file", absPath: "/path/assoluto/file.pdf", name: "file.pdf" }` durante lo
streaming. Il daemon usa direttamente il path assoluto per leggere il file da disco.

**Priorità 2 — Parsing del testo** (fallback): il daemon analizza la risposta testuale
cercando pattern JSON tipici dell'output dei tool:
- `"download_url":"skills-output/pdfs/file.pdf"` → risolto rispetto a `FILES_BASE_DIR`
- `"file_path":"/path/assoluto/file.pdf"` → usato direttamente se dentro `FILES_BASE_DIR`
- URL `/api/files/raw?rel=…` o `/api/files/:uuid/download` → scaricati via HTTP con JWT

**Limite dimensione file Telegram:** 50 MB. File più grandi ricevono un avviso
che invita a scaricarli dal sito.

---

## 👥 Multi-utente

Un singolo bot può essere condiviso tra più utenti yesSir. Ogni utente si autentica
indipendentemente con `/login` e ha la propria sessione isolata — le conversazioni
e i tool sono sempre quelli del proprio account.

---

## 🔔 Sessioni e persistenza nel DB

Le sessioni (JWT, email, mapping chat) vengono salvate **nel database come config
var cifrata** (`TG_SESSIONS`, `secret: true`), **non** su file locale. Questo
garantisce che le sessioni sopravvivano al riavvio del daemon e siano sicure.

Al riavvio il daemon rilegge le sessioni da `_config.TG_SESSIONS` (iniettato
automaticamente dal backend).

Il contenuto di `TG_SESSIONS` è gestito automaticamente — non modificarlo manualmente.

---

## 🔄 Rinnovo token automatico

Se il JWT yesSir scade, il daemon esegue automaticamente il re-login usando le
credenziali salvate. Se il re-login fallisce (password cambiata, account disabilitato),
il bot risponde con un messaggio che invita a ripetere `/login`.

---

## Variabili di configurazione

| Chiave | Descrizione | Obbligatoria |
|--------|-------------|:---:|
| `TELEGRAM_BOT_TOKEN` | Token del bot Telegram (da @BotFather) | ✅ |
| `TG_SESSIONS` | Sessioni utente — gestito automaticamente, non modificare | ❌ |
| `FILES_BASE_DIR` | Directory base per i file generati dai tool. Default: `UPLOAD_DIR` di sistema | ❌ |

---

## Dipendenze

- `telegraf@4` (Node.js)

## Versione

`1.1.0` — maggio 2026 · Licenza MIT  
_Novità v1.1.0: sessioni persistite nel DB (TG_SESSIONS cifrata, non più file locale);
invio automatico file allegati su Telegram (PDF e altri documenti generati dai tool);
nuova config var `FILES_BASE_DIR`; supporto evento SSE `file` per path assoluti._

## Network

Questa skill effettua chiamate verso domini esterni. Sono dichiarati in `skill.yaml` (campo `network:`) e visibili all'admin in fase di review; con l'overlay **egress** i domini non elencati sono bloccati a livello di rete.

| Dominio | Uso |
|---|---|
| `api.telegram.org` | Bot API Telegram (getUpdates, sendMessage, invio file) |

> Bot API di Telegram (ricezione update, invio messaggi e file).
