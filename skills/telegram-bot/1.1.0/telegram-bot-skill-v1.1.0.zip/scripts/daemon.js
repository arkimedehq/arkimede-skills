'use strict';

/**
 * Telegram Bot Daemon per Arkimede.
 *
 * Protocollo avvio (standard skill daemon):
 *   - Legge _config da stdin JSON (contiene TELEGRAM_BOT_TOKEN)
 *   - Legge env vars iniettate dall'executor:
 *       BACKEND_INTERNAL_URL  — URL base del backend
 *       PUSH_URL              — per eventi push al backend
 *       DAEMON_ID / SKILL_ID / USER_ID
 *
 * Flusso utente:
 *   1. /login email password  → autentica contro /api/auth/login, salva sessione
 *   2. Messaggi di testo      → chiama /api/chats/:id/messages/stream, risponde
 *   3. /new                   → azzera la chat corrente, ne crea una nuova
 *   4. /help                  → mostra i comandi
 *
 * Sessioni persistite nel DB come config var cifrata (TG_SESSIONS, secret:true).
 * Formato: { [telegramUserId]: { jwt, userId, email, password, chats: { [telegramChatId]: chatId } } }
 */

const path = require('path');

// ── Variabili d'ambiente (iniettate dal daemon-manager) ───────────────────────

const BACKEND_URL  = (process.env.BACKEND_INTERNAL_URL ?? 'http://localhost:3000').replace(/\/$/, '');
const PUSH_URL     = process.env.PUSH_URL     ?? '';
const DAEMON_ID    = process.env.DAEMON_ID    ?? '';
const SKILL_ID     = process.env.SKILL_ID     ?? '';
const USER_ID      = process.env.USER_ID      ?? '';
const INTERNAL_KEY = process.env.INTERNAL_TOKEN ?? '';

// ── Sessioni (persistite nel DB via config var TG_SESSIONS) ──────────────────
//
// Le sessioni vivono in memoria durante il runtime del daemon e vengono
// sincronizzate nel DB tramite l'API interna save-config ogni volta che cambiano.
// Al riavvio il daemon le rilegge da _config.TG_SESSIONS (iniettato da resolveConfig).
//
// Formato: { [telegramUserId]: { jwt, userId, email, password, chats: { [tgChatId]: chatId } } }
// Cifrato in DB perché TG_SESSIONS è dichiarata secret:true in skill.yaml.

let _sessions = {};   // copia in memoria — fonte di verità durante il runtime

function loadSessions() {
  return _sessions;
}

function saveSessions(s) {
  _sessions = s;
  // Persisti in background senza bloccare il bot
  persistSessionsToDB(s).catch((err) =>
    process.stderr.write(`[telegram-bot] Errore salvataggio sessioni nel DB: ${err.message}\n`),
  );
}

async function persistSessionsToDB(s) {
  const skillId     = process.env.SKILL_ID             ?? SKILL_ID;
  const backendUrl  = (process.env.BACKEND_INTERNAL_URL ?? BACKEND_URL).replace(/\/$/, '');
  const internalKey = process.env.INTERNAL_TOKEN     ?? INTERNAL_KEY;

  if (!skillId || !internalKey) {
    process.stderr.write('[telegram-bot] SKILL_ID o INTERNAL_TOKEN mancanti — sessioni non salvate nel DB\n');
    return;
  }

  const res = await fetch(`${backendUrl}/internal/skills/${skillId}/save-config`, {
    method:  'POST',
    headers: {
      'Content-Type':       'application/json',
      'x-internal-token': internalKey,
    },
    body: JSON.stringify({ config: { TG_SESSIONS: JSON.stringify(s) } }),
  });

  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }
}

// ── Autenticazione Arkimede ─────────────────────────────────────────────────────

async function login(email, password) {
  const res = await fetch(`${BACKEND_URL}/api/auth/login`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify({ email, password }),
  });
  if (!res.ok) return null;
  const data = await res.json();
  return { jwt: data.access_token, userId: data.user?.id };
}

async function relogin(sessions, tgUserId) {
  const s = sessions[tgUserId];
  if (!s?.email || !s?.password) return false;
  const result = await login(s.email, s.password);
  if (!result) return false;
  s.jwt    = result.jwt;
  s.userId = result.userId;
  saveSessions(sessions);
  return true;
}

// ── API Arkimede ────────────────────────────────────────────────────────────────

async function apiGet(jwt, path_) {
  return fetch(`${BACKEND_URL}${path_}`, {
    headers: { 'Authorization': `Bearer ${jwt}` },
  });
}

async function apiPost(jwt, path_, body) {
  return fetch(`${BACKEND_URL}${path_}`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${jwt}` },
    body:    JSON.stringify(body),
  });
}

// ── Gestione chat ─────────────────────────────────────────────────────────────

async function getOrCreateChat(sessions, tgUserId, tgChatId) {
  const s   = sessions[tgUserId];
  const jwt = s.jwt;

  const existingId = s.chats?.[tgChatId];
  if (existingId) {
    const check = await apiGet(jwt, `/api/chats/${existingId}`);
    if (check.ok) return existingId;
    delete s.chats[tgChatId];
  }

  // Trova o crea progetto
  const projRes  = await apiGet(jwt, '/api/projects');
  const projects = await projRes.json();
  let   projectId = Array.isArray(projects) ? projects[0]?.id : null;

  if (!projectId) {
    const np = await apiPost(jwt, '/api/projects', { name: 'Default' });
    projectId = (await np.json()).id;
  }

  const chatRes = await apiPost(jwt, '/api/chats', { projectId, title: 'Telegram' });
  const chat    = await chatRes.json();

  if (!s.chats) s.chats = {};
  s.chats[tgChatId] = chat.id;
  return chat.id;
}

// ── Streaming SSE ─────────────────────────────────────────────────────────────

async function streamMessage(jwt, chatId, content) {
  const res = await apiPost(jwt, `/api/chats/${chatId}/messages/stream`, { content });
  if (res.status === 401) return { expired: true };
  if (!res.ok)            return { error: `HTTP ${res.status}` };

  const reader  = res.body.getReader();
  const decoder = new TextDecoder();
  let   buffer  = '';
  let   full    = '';
  const files = []; // { rel?, url?, name } — eventi file dal backend

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue;
      try {
        const evt = JSON.parse(line.slice(6));
        if (evt.type === 'chunk') full += evt.content ?? '';
        if (evt.type === 'file') {
          // B1: l'evento porta `rel` (download via /api/files/raw?rel=, col JWT).
          if (evt.rel)      files.push({ rel: evt.rel, name: evt.name ?? 'file' });
          else if (evt.url) files.push({ url: evt.url, name: evt.name ?? 'file' }); // compat
        }
        if (evt.type === 'done' || evt.type === 'error') return { text: full, files };
      } catch { /* ignora righe malformate */ }
    }
  }
  return { text: full, files };
}

// ── Estrae file dal testo della risposta — SOLO HTTP (C2/D2) ─────────────────
//
// Niente più accesso diretto al volume (il daemon non monta i file): ogni
// riferimento diventa un URL dell'API backend, scaricato col JWT dell'utente →
// il backend applica canAccess (access-aware). Riconosce:
//   "download_url":"skills-output/x.pdf"  → /api/files/raw?rel=skills-output/x.pdf
//   /api/files/raw?rel=...                → as-is
//   /api/files/:uuid/download             → as-is
//   "file_path":"/abs/.../skills-output/x"→ estrae da "skills-output/" (legacy)

function extractFiles(text) {
  const BK = BACKEND_URL.replace(/\/$/, '');
  const httpFiles = [];
  const seen = new Set();
  const add = (url, name) => { if (!seen.has(url)) { seen.add(url); httpFiles.push({ url, name }); } };
  const relUrl = (rel) => `${BK}/api/files/raw?rel=${encodeURIComponent(rel)}`;
  let m;

  // "download_url":"<rel>" (o un /api/... già pronto)
  const reDl = /"download_url"\s*:\s*"([^"]+)"/g;
  while ((m = reDl.exec(text)) !== null) {
    const v = m[1];
    const pathOnly = v.replace(/^https?:\/\/[^/]+/, '');
    if (/^\/api\/files\//.test(pathOnly)) add(`${BK}${pathOnly}`, path.basename(pathOnly) || 'file');
    else add(relUrl(v), path.basename(v) || 'file');
  }

  // /api/files/raw?rel=...
  const reRaw = /(?:https?:\/\/[^\s"'<>)]+)?\/api\/files\/raw\?(?:[^\s"'<>)]*&)?rel=([^\s"'<>)&]+)/g;
  while ((m = reRaw.exec(text)) !== null) {
    const rel = decodeURIComponent(m[1]);
    add(relUrl(rel), path.basename(rel) || 'file');
  }

  // /api/files/:uuid/download
  const reUuid = /(?:https?:\/\/[^\s"'<>)]+)?\/api\/files\/([0-9a-f-]{36})\/download/g;
  while ((m = reUuid.exec(text)) !== null) add(`${BK}/api/files/${m[1]}/download`, 'file');

  // "file_path":"/abs/.../skills-output/x" (legacy) → estrai il rel da skills-output/
  const reFp = /"file_path"\s*:\s*"([^"]+)"/g;
  while ((m = reFp.exec(text)) !== null) {
    const idx = m[1].indexOf('skills-output/');
    if (idx >= 0) { const rel = m[1].slice(idx); add(relUrl(rel), path.basename(rel) || 'file'); }
  }

  return { httpFiles };
}

// ── Scarica da HTTP e invia su Telegram (unica via: backend API + JWT) ────────

async function sendFileFromUrl(ctx, jwt, fileUrl, filename) {
  const res = await fetch(fileUrl, {
    headers: { 'Authorization': `Bearer ${jwt}` },
  });

  if (!res.ok) {
    process.stderr.write(`[telegram-bot] HTTP ${res.status} per file ${fileUrl}\n`);
    return false;
  }

  const contentLength = Number(res.headers.get('content-length') ?? 0);
  if (contentLength > 50 * 1024 * 1024) {
    await ctx.reply(
      `⚠️ File *${filename}* troppo grande per Telegram (max 50 MB). Scaricalo dal sito.`,
      { parse_mode: 'Markdown' },
    );
    return false;
  }

  try {
    const buffer = Buffer.from(await res.arrayBuffer());
    await ctx.replyWithDocument(
      { source: buffer, filename },
      { caption: `📎 ${filename}` },
    );
    return true;
  } catch (err) {
    process.stderr.write(`[telegram-bot] Errore invio file ${filename}: ${err.message}\n`);
    return false;
  }
}

// ── Invio messaggi lunghi (limite Telegram 4096 char) ────────────────────────

async function sendLong(ctx, text) {
  for (let i = 0; i < text.length; i += 4000) {
    const chunk = text.slice(i, i + 4000);
    try {
      await ctx.reply(chunk, { parse_mode: 'Markdown' });
    } catch {
      await ctx.reply(chunk);
    }
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────

let rawInput = '';
process.stdin.on('data', (d) => { rawInput += d; });
process.stdin.on('end', () => {
  const config = JSON.parse(rawInput || '{}')._config ?? {};
  main(config).catch((e) => {
    process.stderr.write(`[telegram-bot] Fatal: ${e.message}\n`);
    process.exit(1);
  });
});

async function main(config) {
  const botToken = config.TELEGRAM_BOT_TOKEN;
  if (!botToken) {
    process.stderr.write('[telegram-bot] TELEGRAM_BOT_TOKEN non configurato\n');
    process.exit(1);
  }

  // ── Carica sessioni dal DB (arrivano in _config.TG_SESSIONS, cifrate) ─────────
  try {
    const raw = config.TG_SESSIONS ?? '';
    _sessions = raw ? JSON.parse(raw) : {};
    const n = Object.keys(_sessions).length;
    process.stdout.write(`[telegram-bot] Sessioni caricate dal DB: ${n}\n`);
  } catch {
    _sessions = {};
    process.stdout.write('[telegram-bot] TG_SESSIONS non valido — partenza con sessioni vuote\n');
  }

  // I file non si leggono più dal volume: tutto via API backend (canAccess).

  const { Telegraf } = require('telegraf');
  const bot = new Telegraf(botToken);

  // ── /login email password ────────────────────────────────────────────────────
  bot.command('login', async (ctx) => {
    const parts = ctx.message.text.trim().split(/\s+/);
    if (parts.length < 3) {
      return ctx.reply('Uso: /login email password');
    }
    const [, email, password] = parts;

    const result = await login(email, password);
    if (!result) {
      return ctx.reply('Credenziali non valide. Riprova con /login email password');
    }

    const sessions   = loadSessions();
    const tgUserId   = String(ctx.from.id);
    sessions[tgUserId] = {
      userId:   result.userId,
      jwt:      result.jwt,
      email,
      password, // salvata cifrata nelle config vars → in chiaro solo in questo file locale
      chats:    {},
    };
    saveSessions(sessions);

    // Cancella il messaggio con le credenziali per sicurezza
    try { await ctx.deleteMessage(); } catch { /* permesso non disponibile in tutti i contesti */ }

    return ctx.reply(
      '✅ Account Arkimede collegato!\n\nPuoi iniziare a chattare.\n' +
      'Usa /new per iniziare una nuova conversazione, /help per i comandi.'
    );
  });

  // ── /new ──────────────────────────────────────────────────────────────────────
  bot.command('new', async (ctx) => {
    const sessions = loadSessions();
    const tgUserId = String(ctx.from.id);
    if (!sessions[tgUserId]) return ctx.reply('Prima collegati con /login email password');
    sessions[tgUserId].chats = {};
    saveSessions(sessions);
    return ctx.reply('Nuova conversazione avviata.');
  });

  // ── /help ─────────────────────────────────────────────────────────────────────
  bot.command('help', (ctx) => ctx.reply(
    '/login email password — collega il tuo account Arkimede\n' +
    '/new — inizia una nuova conversazione\n' +
    '/help — questo messaggio'
  ));

  // ── /start ────────────────────────────────────────────────────────────────────
  bot.command('start', (ctx) => ctx.reply(
    'Benvenuto nel bot Arkimede!\n\nCollegati con:\n/login email password'
  ));

  // ── Messaggi di testo ─────────────────────────────────────────────────────────
  bot.on('text', async (ctx) => {
    const tgUserId = String(ctx.from.id);
    const tgChatId = String(ctx.chat.id);
    const sessions = loadSessions();
    const userSess = sessions[tgUserId];

    if (!userSess) {
      return ctx.reply('Account non collegato. Usa /login email password');
    }

    await ctx.sendChatAction('typing');

    try {
      let chatId;
      try {
        chatId = await getOrCreateChat(sessions, tgUserId, tgChatId);
      } catch {
        const ok = await relogin(sessions, tgUserId);
        if (!ok) return ctx.reply('Sessione scaduta. Usa /login email password');
        chatId = await getOrCreateChat(sessions, tgUserId, tgChatId);
      }
      saveSessions(sessions);

      let result = await streamMessage(userSess.jwt, chatId, ctx.message.text);

      if (result.expired) {
        const ok = await relogin(sessions, tgUserId);
        if (!ok) return ctx.reply('Sessione scaduta. Usa /login email password');
        result = await streamMessage(sessions[tgUserId].jwt, chatId, ctx.message.text);
      }

      if (result.error || !result.text?.trim()) {
        return ctx.reply('Errore nella risposta. Riprova tra qualche istante.');
      }

      // Invia il testo della risposta
      await sendLong(ctx, result.text);

      // ── Raccoglie i file da mandare su Telegram — SOLO HTTP (C2/D2) ──────
      //
      // Il daemon non legge dal volume: ogni file passa dall'API backend col JWT
      // dell'utente → access-aware. Fonti: eventi SSE `file` (ora con `rel`, B1)
      // + parsing del testo della risposta.

      const activeJwt = sessions[tgUserId]?.jwt ?? userSess.jwt;
      const BK = BACKEND_URL.replace(/\/$/, '');
      const out = [];
      const seenUrls = new Set();
      const addOut = (url, name) => { if (!seenUrls.has(url)) { seenUrls.add(url); out.push({ url, name }); } };

      // SSE file events
      for (const f of (result.files ?? [])) {
        if (f.rel)      addOut(`${BK}/api/files/raw?rel=${encodeURIComponent(f.rel)}`, f.name || path.basename(f.rel));
        else if (f.url) addOut(f.url, f.name || 'file'); // compat con eventuali url diretti
      }
      // Parsing del testo (fonte aggiuntiva)
      for (const f of extractFiles(result.text).httpFiles) addOut(f.url, f.name);

      // Invia tutto via HTTP (JWT utente → canAccess lato backend)
      for (const { url, name } of out) {
        await sendFileFromUrl(ctx, activeJwt, url, name);
      }

    } catch (err) {
      process.stderr.write(`[telegram-bot] Errore: ${err.message}\n`);
      return ctx.reply('Errore imprevisto. Riprova.');
    }
  });

  bot.catch((err) => {
    process.stderr.write(`[telegram-bot] Errore bot: ${err.message}\n`);
  });

  process.once('SIGTERM', () => bot.stop('SIGTERM'));
  process.once('SIGINT',  () => bot.stop('SIGINT'));

  process.stdout.write('[telegram-bot] Avvio...\n');
  await bot.launch();
  process.stdout.write('[telegram-bot] In ascolto.\n');
}
