'use strict';

/**
 * Proactive Telegram sender (task script, LLM-callable).
 *
 * Lets the agent send a message — and optionally a file attachment — to the
 * Telegram account linked to the invoking Arkimede user, without the user
 * having to write on Telegram first. Complements the daemon (which only
 * handles the Telegram → Arkimede direction).
 *
 * Contract:
 *   stdin JSON: { text, file?, _config: { TELEGRAM_BOT_TOKEN, TG_SESSIONS } }
 *   env:        USER_ID — Arkimede user id the tool runs as (injected by the executor)
 *   stdout:     JSON { success, delivered_to?, error?, message? }
 *
 * Recipient resolution: TG_SESSIONS (maintained by the daemon) maps
 * telegramUserId → { userId, email, ... }. Every Telegram account whose
 * session belongs to USER_ID receives the message — for a private chat,
 * chat_id === telegramUserId. There is deliberately no arbitrary-recipient
 * support: the tool can only reach the invoking user's own linked account.
 */

const fs   = require('fs');
const path = require('path');

const API = 'https://api.telegram.org';

function out(obj) { console.log(JSON.stringify(obj)); }

async function tg(token, method, payload) {
  const res  = await fetch(`${API}/bot${token}/${method}`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  return { ok: Boolean(res.ok && data.ok), data };
}

async function sendText(token, chatId, text) {
  // Telegram hard limit is 4096 chars per message — chunk at 4000.
  for (let i = 0; i < text.length; i += 4000) {
    const chunk = text.slice(i, i + 4000);
    let r = await tg(token, 'sendMessage', { chat_id: chatId, text: chunk, parse_mode: 'Markdown' });
    // Markdown parse errors (unbalanced *_`) → retry as plain text
    if (!r.ok) r = await tg(token, 'sendMessage', { chat_id: chatId, text: chunk });
    if (!r.ok) throw new Error(r.data?.description || 'sendMessage failed');
  }
}

async function sendDocument(token, chatId, filePath) {
  const stat = fs.statSync(filePath);
  if (stat.size > 50 * 1024 * 1024) {
    throw new Error(`file too large for Telegram (${Math.round(stat.size / 1024 / 1024)} MB, max 50 MB)`);
  }
  const form = new FormData();
  form.append('chat_id', String(chatId));
  form.append('document', new Blob([fs.readFileSync(filePath)]), path.basename(filePath));
  const res  = await fetch(`${API}/bot${token}/sendDocument`, { method: 'POST', body: form });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.ok) throw new Error(data?.description || 'sendDocument failed');
}

async function main() {
  const data    = JSON.parse(fs.readFileSync(0, 'utf8') || '{}');
  const _config = data._config ?? {};
  const text    = String(data.text ?? '').trim();
  const file    = typeof data.file === 'string' ? data.file.trim() : '';

  const token  = _config.TELEGRAM_BOT_TOKEN;
  const userId = process.env.USER_ID ?? '';

  if (!token) {
    return out({ success: false, error: 'TELEGRAM_BOT_TOKEN is not configured for the telegram-bot skill.' });
  }
  if (!text) {
    return out({ success: false, error: 'Nothing to send: "text" is required.' });
  }
  if (!userId) {
    return out({ success: false, error: 'USER_ID missing: cannot resolve the Telegram recipient.' });
  }

  let sessions = {};
  try { sessions = JSON.parse(_config.TG_SESSIONS || '{}'); } catch { sessions = {}; }

  // All Telegram accounts linked to the invoking Arkimede user (normally one).
  const targets = Object.entries(sessions)
    .filter(([, s]) => s && s.userId === userId)
    .map(([tgUserId]) => ({ chatId: Number(tgUserId) }));

  if (!targets.length) {
    return out({
      success: false,
      error:   'No Telegram account is linked to this Arkimede user.',
      message: 'Ask the user to open the Telegram bot and link their account with: /login email password',
    });
  }

  const delivered = [];
  const failures  = [];
  for (const t of targets) {
    try {
      await sendText(token, t.chatId, text);
      if (file) await sendDocument(token, t.chatId, file);
      delivered.push(t.chatId);
    } catch (err) {
      failures.push(String(err.message));
    }
  }

  if (!delivered.length) {
    return out({ success: false, error: `Delivery failed — ${failures.join('; ')}` });
  }
  out({
    success:      true,
    delivered_to: delivered.length,
    ...(failures.length ? { partial_failures: failures } : {}),
    message: 'Message delivered on Telegram.',
  });
}

main().catch((err) => {
  out({ success: false, error: err.message });
  process.exit(1);
});
