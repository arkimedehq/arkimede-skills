---
name: telegram-bot
description: |
  Bot Telegram che permette a ogni utente Arkimede di chattare con il proprio account direttamente da Telegram. Supporta tool custom, MCP, RAG e skill configurati nel proprio profilo. Ogni utente si collega inviando /login email password al bot. Comandi: /login, /new, /help. Include il tool send_message per inviare messaggi Telegram proattivi (agente → utente) da qualsiasi chat, automazione o flow.
version: 1.2.0
author: Arkimede
license: MIT
runtime:
  dependencies:
    javascript:
      - telegraf@4
  network:
    - api.telegram.org
  config:
    - key: TELEGRAM_BOT_TOKEN
      description: Token del bot Telegram ottenuto da @BotFather
      required: true
      secret: true
    - key: TG_SESSIONS
      description: |
        Sessioni utente Telegram (gestito automaticamente dal daemon — non modificare). Contiene JWT, email e mapping chat per ogni utente collegato.
      required: false
      secret: true
      default: ''
    - key: FILES_BASE_DIR
      description: |
        Directory base da cui leggere i file generati dai tool (PDF, Excel, ecc.) prima di inviarli su Telegram. Lascia vuoto per usare il valore di sistema (UPLOAD_DIR, di solito uploads/).
      required: false
      default: ${UPLOAD_DIR}
  scripts:
    - filename: scripts/daemon.js
      language: node
      mode: daemon
      description: |
        Daemon long-running che gestisce il bot Telegram. Non viene invocato dal LLM: si avvia e gestisce dall'interfaccia daemon.
    - filename: scripts/send_message.js
      language: node
      description: |
        Sends a proactive Telegram message (and optionally a file attachment) to the Telegram account linked to the current Arkimede user. Use it whenever the user asks to send, forward or notify something via Telegram — from any chat, scheduled task or flow. The recipient is always the invoking user's own linked Telegram account (no arbitrary recipients). Requires the user to have linked their account by sending /login to the bot; if no account is linked, the tool returns an error explaining how to link it.
      input_schema:
        type: object
        required:
          - text
        properties:
          text:
            type: string
            description: The message text to send. Markdown is supported (falls back to plain text if parsing fails). Long texts are split automatically into 4000-character chunks.
          file:
            type: string
            format: file-ref
            description: "Optional file attachment: a file id (uuid) or a path relative to the uploads dir (e.g. skills-output/pdfs/report.pdf) — typically the download_url returned by another skill. Max 50 MB (Telegram limit)."
---

# Telegram Bot

Daemon che collega Arkimede a Telegram. Ogni utente Arkimede può collegare il proprio account al bot e chattare come se stesse usando la chat web — con accesso a tutti i tool, MCP, RAG e skill configurati nel proprio profilo.

## Invio proattivo di messaggi (tool `send_message`)

Oltre alla direzione Telegram → Arkimede gestita dal daemon, la skill espone il
tool `scripts/send_message.js` con cui l'agente può **inviare** messaggi Telegram
di propria iniziativa (agente → utente): da una chat web, da un task schedulato,
da un flow.

Regole per il LLM:

- Usa il tool quando l'utente chiede di inviare/inoltrare/notificare qualcosa su
  Telegram (es. "mandami un riepilogo su Telegram", "scrivimi un promemoria sul bot").
- Il destinatario è **sempre** l'account Telegram collegato dell'utente corrente:
  non è possibile scegliere destinatari arbitrari.
- `text` è obbligatorio; `file` è opzionale e accetta un file id o un path
  relativo alla dir uploads (es. il `download_url` restituito da un'altra skill).
- Se il tool risponde che nessun account è collegato, spiega all'utente che deve
  aprire il bot Telegram e inviare `/login email password`.

## Setup

1. Crea un bot su Telegram tramite **@BotFather** (`/newbot`) e copia il token
2. In Arkimede → Impostazioni → Skills → telegram-bot → **Configura**
3. Imposta `TELEGRAM_BOT_TOKEN` con il token del bot
4. Torna alla skill e clicca **Avvia daemon**

## Collegare un account utente

Ogni utente Arkimede manda al bot:

```
/login email@esempio.com latuapassword
```

Il bot autentica le credenziali contro Arkimede, salva la sessione e cancella il messaggio con le credenziali.

## Comandi disponibili

| Comando | Azione |
|---|---|
| `/start` | Messaggio di benvenuto |
| `/login email password` | Collega il tuo account Arkimede |
| `/new` | Inizia una nuova conversazione |
| `/help` | Mostra i comandi disponibili |

## Invio automatico di file allegati

Il daemon rileva automaticamente i file generati dai tool Arkimede (PDF, Excel, ecc.)
e li invia come documenti allegati su Telegram, subito dopo la risposta testuale.

I file vengono cercati in due modi:
1. **Evento SSE `file`** (preferito): il backend emette eventi SSE con `absPath` — il daemon
   legge il file direttamente da disco (più veloce, nessuna chiamata HTTP)
2. **Parsing del testo risposta** (fallback): il daemon analizza la risposta cercando
   pattern `download_url`, `file_path`, o URL `/api/files/raw?rel=…`

Limite Telegram: file fino a **50 MB**. File più grandi ricevono un messaggio di avviso.

## Sessioni nel DB

Le sessioni utente (JWT, email, mapping chat) sono salvate nel DB come config var
cifrata `TG_SESSIONS` (`secret: true`). Non sono più salvate su file locale.

Il valore viene gestito automaticamente dal daemon — non modificare manualmente.

## Variabili di configurazione

| Chiave | Descrizione | Obbligatoria |
|--------|-------------|:---:|
| `TELEGRAM_BOT_TOKEN` | Token del bot Telegram (da @BotFather) | ✅ |
| `TG_SESSIONS` | Sessioni utente cifrate — gestito automaticamente | ❌ |
| `FILES_BASE_DIR` | Directory base per i file dei tool. Default: `UPLOAD_DIR` di sistema | ❌ |

## Note

- Ogni conversazione Telegram è una chat separata in Arkimede (visibile anche dal sito)
- Per scollegarsi: usa `/login` con credenziali diverse, oppure elimina il daemon e ricrealo
- Il rinnovo del JWT Arkimede avviene automaticamente; se fallisce il bot chiede di ripetere `/login`

## Rete (network)

Richiede egress verso: `api.telegram.org`. I domini sono già dichiarati in `skill.yaml`.
